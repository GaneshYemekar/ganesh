
<?php
session_start();
//echo session_id();
include ("db/db_connect.php");
include ("includes/loginverify.php");
date_default_timezone_set('Asia/Calcutta');

$ipaddress = $_SERVER["REMOTE_ADDR"];
$updatedatetime = date('Y-m-d H:i:s');
$logintime = $_SESSION["logintime"];

$username = $_SESSION["username"];
$usercode = $_SESSION["usercode"];
$docno = $_SESSION["docno"];

$locationname = $_SESSION["locationname"];
$locationcode = $_SESSION["locationcode"];

$companyanum = $_SESSION["companyanum"];
$companyname = $_SESSION["companyname"];
$companycode = $_SESSION["companycode"];

if(isset($_REQUEST['form_action'])){$request = $_REQUEST['form_action']; }else{$request = "";}

if($request == "insert"){
	
	
	
	$employee_id = $_REQUEST['employee_id'];
	$employee_name = $_REQUEST['employee_name'];
	$username = $_REQUEST['username'];
	$password = $_REQUEST['password'];	
	$remember_token = $_REQUEST[''];
	$register_date = $_REQUEST['register_date'];
	$register_time = $_REQUEST['register_time'];
	$role_id = $_REQUEST['role_id'];
	$designation = $_REQUEST['designation'];
	$active_status = $_REQUEST['active_status'];
	$validity_date = $_REQUEST['validity_date'];
	$store_access = $_REQUEST['store_access'];
	$shift_access = $_REQUEST['shift_access'];
	
	$father_name = $_REQUEST['father_name'];	
	$nationality = $_REQUEST['nationality'];
	$gender = $_REQUEST['gender'];
	$dob = $_REQUEST['dob'];	
	$marital_status = $_REQUEST['marital_status'];
	$religion = $_REQUEST['religion'];
	$blood_group = $_REQUEST['blood_group'];
	$height = $_REQUEST['height'];
	$weight = $_REQUEST['weight'];
	$address = $_REQUEST['address'];
	$city = $_REQUEST['city'];
	$country = $_REQUEST['country'];
	$landline = $_REQUEST['landline'];	
	$mobile = $_REQUEST['mobile'];	
	$email = $_REQUEST['email'];
	$university_name = $_REQUEST['university_name'];
	$is_disbled = $_REQUEST['is_disbled'];	
	$employee_image = $_REQUEST['employee_image'];
	
	$doj = $_REQUEST['doj'];
	$employement_type = $_REQUEST['employement_type'];
	$department = $_REQUEST['department'];
	$category = $_REQUEST['category'];
	$superisor = $_REQUEST['superisor'];
	$first_job_in_country = $_REQUEST['first_job_in_country'];
	$overtime = $_REQUEST['overtime'];
	$is_user = $_REQUEST['is_user'];	
	
	
	
	
	
	
	
	
	
echo $sql = "INSERT INTO `esm_1`.`master_employee` (`employee_id`, `employee_name`, `username`, `password`, `remember_token`, `register_date`, `register_time`, `role_id`, `designation`, `active_status`, `validity_date`, `store_access`, `shift_access`, `doj`, `employement_type`, `department`, `category`, `superisor`, `first_job_in_country`, `overtime`, `is_user`, `prorata`, `prev_employer_name`, `prev_employer_address`, `promotion_due_on`, `increment_due_on`, `free_travel_allowance`, `company_car`, `vehicle_no`, `leaving_date`, `is_blacklisted`, `reason_leaving`, `last_job_kenya_expartriate`, `emp_status_on_hold`, `date_holding_vehigle_no`, `created_at`, `updated_at`, `record_status`, `user_id`, `ip_address`, `location_code`, `location_name`) VALUES ('$employee_id', '$employee_name', '$username', '$password', '$remember_token', '$register_date', '$register_time', '$role_id', '$designation', '$active_status', '$validity_date', '$store_access', '$is_disbled', '$doj', '$employement_type', '$department', '$category', '$superisor', '$first_job_in_country', '$overtime', '$is_user', '$prorata', '$prev_employer_name', '$prev_employer_address', '$promotion_due_on', '$increment_due_on', '$free_travel_allowance', '$company_car', '$vehicle_no', '$leaving_date', '$is_blacklisted', '$reason_leaving', '$last_job_kenya_expartriate', '$emp_status_on_hold', '$date_holding_vehigle_no', '$updatedatetime', '$updatedatetime', '$record_status', '$user_id', '$ipaddress', '$locationcode','$locationname' ";
$exec = mysql_query($sql);
if($exec){
	echo "success";
}else{
	echo "failed";
}	
exit;



}
?>