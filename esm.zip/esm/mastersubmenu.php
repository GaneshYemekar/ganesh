<?php
session_start();
//echo session_id();
include ("db/db_connect.php");
include ("includes/loginverify.php");
date_default_timezone_set('Asia/Calcutta');

$ipaddress = $_SERVER["REMOTE_ADDR"];
$updatedatetime = date('Y-m-d H:i:s');
$logintime = $_SESSION["logintime"];

$username = $_SESSION["username"];
$usercode = $_SESSION["usercode"];
$docno = $_SESSION["docno"];

$locationname = $_SESSION["locationname"];
$locationcode = $_SESSION["locationcode"];

$companyanum = $_SESSION["companyanum"];
$companyname = $_SESSION["companyname"];
$companycode = $_SESSION["companycode"];


if (isset($_REQUEST["frmflag1"])) { $frmflag1 = $_REQUEST["frmflag1"]; } else { $frmflag1 = ""; }
	if ($frmflag1 == 'frmflag1')
	{
		if (isset($_REQUEST["submit"])) { $submit = $_REQUEST["submit"]; } else { $submit = ""; }	
		if ($submit == 'Save')
		{		
			$menu_id = $_REQUEST["menu_id"];
			$submenuid = $_REQUEST["submenuid"];
			$submenuorder = $_REQUEST["submenuorder"];
			$menu_name = $_REQUEST['submenu_name'];
			$menu_url = $_REQUEST['submenu_url'];
			
			$Query = "insert into master_menusub(mainmenuid,submenuid,submenuorder,submenutext,submenulink,username,ipaddress,entrydate,locationname,locationcode) 
			values ('".$menu_id."','".$submenuid."','".$submenuorder."','".$menu_name."', '".$menu_url."','$username','$ipaddress',now(),'$locationname','$locationcode')";
			
			$exec1 = mysql_query($Query) or die ("Error in Query".mysql_error());
			$errmsg = "Success. New Sub Menu Created";
			//exit;
			$bgcolorcode = 'success';
            if($exec1){
				header ("Location:mastersubmenu.php");
			}
			
	    } 
	}

	
	
	if (isset($_REQUEST["st"])) { $st = $_REQUEST["st"]; } else { $st = ""; }
	if ($st == 'del')
	{
		$delanum = $_REQUEST["anum"];
		$Query = "update master_menusub set status = 'deleted' where auto_number = '".$delanum."'";
		$exec3 = mysql_query($Query) or die ("Error in Query".mysql_error());
		if($exec3){
			header("location:mastersubmenu.php");
		}
		}
	if ($st == 'activate')
	{
		$delanum = $_REQUEST["anum"];
		$Query = "update master_menusub set status = '' where auto_number = '".$delanum."'";
		$exec3 = mysql_query($Query) or die ("Error in Query".mysql_error());
		if($exec3){
			header("location:mastersubmenu.php");
		}		
	}

	
	$paynowbillprefix = 'SM00';
	$paynowbillprefix1=strlen($paynowbillprefix);

	$query2 = "select * from master_menusub order by auto_number desc limit 0, 1";
	$exec2 = mysql_query($query2) or die ("Error in Query2".mysql_error());
	$res2 = mysql_fetch_array($exec2);
	$billnumber = $res2["submenuid"];
	$billdigit=strlen($billnumber);

	if ($billnumber == '')
	{
		$billnumbercode =$paynowbillprefix.'1';
	}
	else
	{
		$billnumber = $res2["submenuid"];
		$billnumbercode = substr($billnumber,$paynowbillprefix1, $billdigit);
		$billnumbercode = intval($billnumbercode);
		$billnumbercode = $billnumbercode + 1;
		$maxanum = $billnumbercode;
		$billnumbercode = $paynowbillprefix.$maxanum;  
	}
?>
<?php include ("includes/header.php");  ?>

  
<script language="javascript">
	function process1()
	{
		//alert ("Inside Funtion");
		if (document.form1.menu_id.value == "")
		{
			alert ("Please Select the Menu ID");
			document.form1.menu_id.focus();
			return false;
		}
		if (document.form1.submenu_name.value == "")
		{
			alert ("Please Enter Sub Menu Name");
			document.form1.submenu_name.focus();
			return false;
		}
		
		if (document.form1.submenu_url.value == "")
		{
			alert ("Please Enter Sub Menu URL");
			document.form1.submenu_url.focus();
			return false;
		}

	}

</script>

<script>
function funcDeletesurgery(submenuname){
	
	var confirm1=confirm("Are you sure want to delete ' "+submenuname+" ' sub menu?");
	if(confirm1 == false) 
	{ 
		return false; 
	}   
	
}	

function funcActivatesurgery(submenuname){
	
	var confirm2=confirm("Are you sure want to activate ' "+submenuname+" ' sub menu?");
	if(confirm2 == false) 
	{ 
		return false; 
	}   
	
}	
	
</script>

    <section class="content">
		<div class="row">
        <div class="col-md-12">
		<div class="box box-info">
			
			<div class="box-header with-border">
				<h3 class="box-title">Add New Sub-Menu</h3>

				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				<!--	<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button> -->
				</div>
			</div>
        <!-- /.box-header -->
		<!-- form start -->
		<form class="form-horizontal" name="form1" id="form1" method="post" action="mastersubmenu.php" onSubmit="return process1()" >		
			<div class="box-body">
				<div class="row">
					<div class="box-body">
					
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Main Menu ID </label>
									
							<div class="col-sm-6">
								<select name="menu_id" id="menu_id" class="form-control select2" vertical-align="top" style="width: 100%;">
									<option value="" selected="selected">Select</option>
									<?php
									$query5 = "select * from master_menumain where status <> 'deleted' order by mainmenuid";
									$exec5 = mysql_query($query5) or die ("Error in Query5".mysql_error());
										while ($res5 = mysql_fetch_array($exec5))
										{
											$res5anum = $res5["auto_number"];
											$res5accountsmain = $res5["mainmenuid"];
											$res5mainmenutext = $res5["mainmenutext"];
									?>
								   <option value="<?php echo  $res5accountsmain;  ?>"><?php echo $res5mainmenutext; ?></option>
									<?php	 
										}
									?>
								</select>
							</div>
						</div>	
							
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Sub Menu ID </label>

							<div class="col-sm-6">
								<input type="text" name="submenuid" id="submenuid" class="form-control" value="<?php echo $billnumbercode;?>" readonly>
							</div>
						</div>
							
						<div class="form-group">
							<label for="inputPassword3" class="col-sm-2 control-label">Sub Menu Order </label>

							<div class="col-sm-6">
								<input type="text" name="submenuorder" id="submenuorder" class="form-control" placeholder="Submenu Order">
							</div>
						</div>
							
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Sub Menu Name</label>

							<div class="col-sm-6">
								<input type="text" name="submenu_name" id="submenu_name" class="form-control" placeholder="Submenu Name">
							</div>
						</div>
							
						<div class="form-group">
							<label for="inputPassword3" class="col-sm-2 control-label">Sub Menu Url</label>

							<div class="col-sm-6">
								<input type="text" name="submenu_url" id="submenu_url" class="form-control" placeholder="Submenu URL">
							</div>
						</div>

						<div class="form-group">
							<label for="inputPassword3" class="col-sm-2 control-label"> &nbsp;</label>
 						    <div class="col-sm-2">
							 
								<input type="hidden" name="frmflag1" id="frmflag1" class="form-control" value="frmflag1">
								<input type="submit" name="submit" id="submit" class="btn btn-info " value="Save">
								<button type="reset" name="reset" id="reset" class="btn btn-default pull-right">Cancel</button>
							 
							</div>
						</div>
						
					</div>  <!-- /.box-body -->
					  
				</div>	 <!-- /.row -->
				
			</div><!-- /.box-body -->

		</form>  <!-- /.body form -->
			
		</div> <!-- /.box-info -->
		
		</div> <!-- /.col-md-6 -->
		</div> <!-- /.row -->
		
    </section>  <!-- /.section -->

    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> Master Sub-Menu - Existing List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
					<th> Sr.No</th>
					<th>Mainmenu Name</th>
					<th>Submenu Name</th>
					<th>Sub Order No</th>
					<th>Submenu Url</th>
					<th>Action</th>
                </tr>
                </thead>
                <tbody>
				<?php
				    $srno = 0;
					$colorloopcount = "";
					$Query = "select * from master_menusub where status <> 'deleted' order by auto_number ";
					$exec1 = mysql_query($Query) or die ("Error in Query".mysql_error());
					while ($res1 = mysql_fetch_array($exec1))
					{
						$srno = $srno + 1;
						
						$mainmenuid=$res1['mainmenuid'];
						$submenu_id=$res1['submenuid'];
						$submenutext=$res1['submenutext'];
						$submenuorder=$res1['submenuorder'];
						
						$submenulink=$res1['submenulink'];
						$auto_number = $res1['auto_number'];
						
						$resq= mysql_query("SELECT mainmenutext FROM `master_menumain` WHERE mainmenuid = '$mainmenuid' AND status =''");
						$resq1 = mysql_fetch_array($resq);
						$mainmenuname=$resq1['mainmenutext'];
						
						$colorloopcount = $colorloopcount + 1;
				?>
		
                <tr>
					<td> <?php echo $srno; ?> </td>
					<td> <?php echo $mainmenuname; ?> </td>
					<td> <?php echo $submenutext; ?> </td>
					<td> <?php echo $submenuorder; ?> </td>
					<td> <?php echo $submenulink; ?> </td>
					<td>
						<a href="mastersubmenuedit1.php?st=edit&&anum=<?php echo $auto_number; ?>" >
							<div class="col-sm-5 btn btn-success btn-xs">Update</div>
						</a> <div class="col-sm-1 btn-xs"></div>
						<a href="mastersubmenu.php?st=del&&anum=<?php echo $auto_number; ?>" > 
							<div class="col-sm-5 btn btn-danger  btn-xs" onclick="return funcDeletesurgery('<?php echo $submenutext; ?>')" >Delete</div> 
						</a> 
					</td>
                </tr>
				<?php 
					}
				?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
	  
	        <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> Master Sub-Menu- Deleted List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped">
                <thead>
                <tr>
					<th> Sr.No</th>
					<th>Mainmenu Name</th>
					<th>Submenu Name</th>
					<th>Sub Order No</th>
					<th>Submenu Url</th>
					<th>Action</th>
                </tr>
                </thead>
                <tbody>
				<?php
				    $srno = 0;
					$Query = "select * from master_menusub where status = 'deleted' order by auto_number ";
					$exec1 = mysql_query($Query) or die ("Error in Query".mysql_error());
					while ($res1 = mysql_fetch_array($exec1))
					{
						$srno = $srno + 1;
						
						$mainmenuid=$res1['mainmenuid'];
						$submenu_id=$res1['submenuid'];
						$submenutext=$res1['submenutext'];
						$submenuorder=$res1['submenuorder'];
						
						$submenulink=$res1['submenulink'];
						$auto_number = $res1['auto_number'];
						
						$resq= mysql_query("SELECT mainmenutext FROM `master_menumain` WHERE mainmenuid = '$mainmenuid' AND status =''");
						$resq1 = mysql_fetch_array($resq);
						$mainmenuname=$resq1['mainmenutext'];
						
						$colorloopcount = $colorloopcount + 1;
				?>
		
                <tr>
					<td> <?php echo $srno; ?> </td>
					<td> <?php echo $mainmenuname; ?> </td>
					<td> <?php echo $submenutext; ?> </td>
					<td> <?php echo $submenuorder; ?> </td>
					<td> <?php echo $submenulink; ?> </td>
					<td>
						<a href="mastersubmenu.php?st=activate&&anum=<?php echo $auto_number; ?>" > 
							<div class="col-sm-6 btn btn-success  btn-xs" onclick="return funcActivatesurgery('<?php echo $submenutext; ?>')" > Activate</div> 
						</a> 
					</td>
                </tr>
				<?php 
					}
				?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->


<?php include ("includes/footer.php"); ?>