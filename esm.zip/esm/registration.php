
<?php
session_start();
//echo session_id();
include ("db/db_connect.php");
include ("includes/loginverify.php");
date_default_timezone_set('Asia/Calcutta');

$ipaddress = $_SERVER["REMOTE_ADDR"];
$updatedatetime = date('Y-m-d H:i:s');
$logintime = $_SESSION["logintime"];

$username = $_SESSION["username"];
$usercode = $_SESSION["usercode"];
$docno = $_SESSION["docno"];

$locationname = $_SESSION["locationname"];
$locationcode = $_SESSION["locationcode"];

$companyanum = $_SESSION["companyanum"];
$companyname = $_SESSION["companyname"];
$companycode = $_SESSION["companycode"];

if(isset($_REQUEST['form_action'])){$request = $_REQUEST['form_action']; }else{$request = "";}

if($request == "insert"){

//echo "INSERT INTO `esm_1`.`master_employee` (`employee_id`, `employee_name`, `username`, `password`, `remember_token`, `register_date`, `register_time`, `role_id`, `designation`, `active_status`, `validity_date`, `store_access`, `shift_access`, `doj`, `employement_type`, `department`, `category`, `superisor`, `first_job_in_country`, `overtime`, `is_user`, `prorata`, `prev_employer_name`, `prev_employer_address`, `promotion_due_on`, `increment_due_on`, `free_travel_allowance`, `company_car`, `vehicle_no`, `leaving_date`, `is_blacklisted`, `reason_leaving`, `last_job_kenya_expartriate`, `emp_status_on_hold`, `date_holding_vehigle_no`, `created_at`, `updated_at`, `record_status`, `user_id`, `ip_address`, `location_code`) VALUES ('EMP01', 'ADMINISTRATOR', 'admin', 'YWRtaW4=', '', '2017-12-01', '23:45:23', '', 'admin', '1', '2018-12-31', '', '', '2017-12-01', 'admin', '', '', 'YES', '', '', 'YES', '', '', '', '', '', '', '', '', '', '', '', '', '', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, '1', '', '127.0.0.1', 'HYD')";
	
	$prorata = "";
	$first_job_in_country  = "";
	$overtime  = "";
	$prev_employer_name  = "";	
	$prev_employer_address  = "";
	$promotion_due_on  = "";
	$increment_due_on  = "";
	$free_travel_allowance  = "";
	$company_car  = "";
	$vehicle_no  = "";
	$leaving_date  = "";
	$is_blacklisted  = "";
	$reason_leaving  = "";
	
	$last_job_kenya_expartriate  = "";	
	$emp_status_on_hold  = "";
	$date_holding_vehigle_no  = "";
	$record_status  = "";

	$employee_id = $_REQUEST['employee_id'];
	$employee_name = $_REQUEST['employee_name'];
	$username = $_REQUEST['username'];
	$password = $_REQUEST['password'];	
	$remember_token = $_REQUEST[''];
	$register_date = $_REQUEST['register_date'];
	$register_time = $_REQUEST['register_time'];
	$role_id = $_REQUEST['role_id'];
	$designation = $_REQUEST['designation'];
	$active_status = $_REQUEST['active_status'];
	$validity_date = $_REQUEST['validity_date'];
	$store_access = $_REQUEST['store_access'];
	$shift_access = $_REQUEST['shift_access'];
	
	$father_name = $_REQUEST['father_name'];	
	$nationality = $_REQUEST['nationality'];
	$gender = $_REQUEST['gender'];
	$dob = $_REQUEST['dob'];	
	$marital_status = $_REQUEST['marital_status'];
	$religion = $_REQUEST['religion'];
	$blood_group = $_REQUEST['blood_group'];
	$height = $_REQUEST['height'];
	$weight = $_REQUEST['weight'];
	$address = $_REQUEST['address'];
	$city = $_REQUEST['city'];
	$country = $_REQUEST['country'];
	$landline = $_REQUEST['landline'];	
	$mobile = $_REQUEST['mobile'];	
	$email = $_REQUEST['email'];
	$university_name = $_REQUEST['university_name'];
	$is_disbled = $_REQUEST['is_disbled'];	
//	$employee_image = $_REQUEST['employee_image'];
	
	$doj = $_REQUEST['doj'];
	$employement_type = $_REQUEST['employement_type'];
	$department = $_REQUEST['department'];
	$category = $_REQUEST['category'];
	$superisor = $_REQUEST['superisor'];
	//$first_job_in_country = $_REQUEST['first_job_in_country'];
	$overtime = $_REQUEST['overtime'];
	$is_user = $_REQUEST['is_user'];	
	

	
echo $sql = "INSERT INTO `esm_1`.`master_employee` (`employee_id`, `employee_name`, `username`, `password`, `remember_token`, `register_date`, `register_time`, `role_id`, `designation`, `active_status`, `validity_date`, `store_access`, `shift_access`, `doj`, `employement_type`, `department`, `category`, `superisor`, `first_job_in_country`, `overtime`, `is_user`, `prorata`, `prev_employer_name`, `prev_employer_address`, `promotion_due_on`, `increment_due_on`, `free_travel_allowance`, `company_car`, `vehicle_no`, `leaving_date`, `is_blacklisted`, `reason_leaving`, `last_job_kenya_expartriate`, `emp_status_on_hold`, `date_holding_vehigle_no`, `created_at`, `updated_at`, `record_status`, `user_id`, `ip_address`, `location_code`, `location_name`) VALUES ('$employee_id', '$employee_name', '$username', '$password', '$remember_token', '$register_date', '$register_time', '$role_id', '$designation', '$active_status', '$validity_date', '$store_access', '$is_disbled', '$doj', '$employement_type', '$department', '$category', '$superisor', '$first_job_in_country', '$overtime', '$is_user', '$prorata', '$prev_employer_name', '$prev_employer_address', '$promotion_due_on', '$increment_due_on', '$free_travel_allowance', '$company_car', '$vehicle_no', '$leaving_date', '$is_blacklisted', '$reason_leaving', '$last_job_kenya_expartriate', '$emp_status_on_hold', '$date_holding_vehigle_no', '$updatedatetime', '$updatedatetime', '$record_status', '$user_id', '$ipaddress', '$locationcode','$locationname')";
$exec = mysql_query($sql);
if($exec){
	echo "success";
}else{
	echo "failed";
}	
exit;
exit;



}
?>
<?php include ("includes/header.php");  ?>

   <!-- Main content -->
  <section class="content">
    <div class="row">
        <!-- left column -->
    <div class="col-md-12">

      <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Employee Master</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
 
         <form class="form-horizontal" name="master_form_id" id="master_form_id" action="registration.php" method="post" onSubmit="return process1()" >
         <div class="box-body">

            <div class="form-group">
				<div class="col-sm-6 col-md-3 col-lg-3">
					<label for="register_date" class="header" ><i class="fa fa-calendar"></i> &nbsp; Date </label>
					<input class="form-control input-sm" id="register_date" name="register_date" value="<?= date('d/m/Y'); ?>" type="text" placeholder="dd/mm/yyyy">
					<!--<div class="input-group date">
						<div class="input-group-addon">
							<i class="fa fa-calendar"></i>
						</div>
					</div>-->					
					
				</div>
           
				<div class="col-sm-6 col-md-3 col-lg-3">
					<label for="register_time" class="header "  ><i class="fa fa-clock-o"></i> &nbsp; Time </label>
					<input class="form-control input-sm currenttime pull-right" id="register_time" name="register_time" type="text" >
					<!--<div class="input-group">
						<div class="input-group-addon">
							<i class="fa fa-clock-o"></i>
						</div>
					</div>-->
				</div>
				
              <div class="col-sm-6 col-md-3 col-lg-3">
                <label for="employee_id" class="header ">Employee ID</label>
                <input class="form-control input-sm"  id="employee_id" name="employee_id" type="text" value="<?= "01"; ?>" readonly="readonly" >
              </div>
              <?php
			  ?>
              <div class="col-sm-6 col-md-3 col-lg-3">
                <label for="role_id" class="fill-this text-red">Role *</label>
                <select class="form-control input-sm" id="role_id" name="role_id">
                	<option value="">--Select--</option>
					<option value="	ROL-1"> Super Admin </option>
					<option value="	ROL-2"> Admin </option>
					<option value="	ROL-3"> Manager </option>
					<option value="	ROL-4"> Employee / Staff </option>	
					<option value="	ROL-5"> Student </option>						
              <?php
			  /*	foreach($this_roles as $roles)
				{
				?>
                    <option value="{{ $roles->role_id }}">{{ $roles->role }}</option>
               <?php
				}*/
				?>
              
                </select>
              </div>
               <div class="col-sm-6 col-md-3 col-lg-3">
                <label for="designation">Designation</label>
                <input class="form-control input-sm"  id="designation" name="designation" type="text" value="" >
              </div>
              <div class="col-sm-6 col-md-3 col-lg-3">
                <label for="employee_name" class="fill-this text-red">Employee Name *</label>
                <input class="form-control input-sm"  id="employee_name" name="employee_name" type="text" value="" >
              </div>
              <div class="col-sm-6 col-md-3 col-lg-3">
                <label for="username" class="fill-this text-red">User Access Name *</label>
                <input class="form-control input-sm"  id="username" name="username" type="text" value="" onfocusout="return usernameValidation()" autocomplete="off" >
              </div>

              <div class="col-sm-6 col-md-3 col-lg-3">
                <label for="password" class="fill-this text-red">Password *</label>
                <input class="form-control input-sm"  id="password" name="password" type="password" value="" >
              </div>
               <div class="col-sm-6 col-md-3 col-lg-3">
             	<label for="active_status" class="fill-this text-red" >Status *</label>
                <select  class="form-control input-sm"  id="active_status" name="active_status">
                  <option value="">--Select--</option>
                  <option value="1">Active</option>
                  <option value="0">Inactive	</option>
                </select>
                </div> 
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="validity_date" class="fill-this text-red">Validity*</label>
                	<input class="form-control input-sm"  id="validity_date" name="validity_date" type="text" value="<?= date('d/m/Y'); ?>" placeholder="dd/mm/yyyy" >
              	</div>
               <div class="col-sm-6 col-md-3 col-lg-3">
                <label for="store_access">Location &Store access</label>
                <input class="form-control input-sm"  id="store_access" name="store_access" type="text" value="" >
              </div>
             <div class="col-sm-6 col-md-3 col-lg-3">
             	<label for="shift_access" >Shift Access</label>
                <select  class="form-control input-sm"  id="shift_access" name="shift_access">
                  <option value="">--Select--</option>
                  <option value="1">Yes</option>
                  <option value="0">No</option>
                </select>
                </div>
           </div>
        </div>
          
          <div class="box-header with-border">
              		<h3 class="box-title">Personal Details</h3>
            	</div>
             <div class="box-body">

             	<div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="father_name">Father</label>
                	<input class="form-control input-sm"  id="father_name" name="father_name" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="nationality">Nationality</label>
                	<input class="form-control input-sm"  id="nationality" name="nationality" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
             	<label for="gender">Gender</label>
                <select  class="form-control input-sm"  id="gender" name="gender">
                  <option value="">--Select--</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </select>
                </div> 
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="dob">Date Of Birth</label>
                	<input class="form-control input-sm"  id="dob" name="dob" type="text" value="<?= date('d/m/Y'); ?>" placeholder="dd/mm/yyyy" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
             	<label for="marital_status">Marital Status</label>
                <select  class="form-control input-sm"  id="marital_status" name="marital_status">
                  <option value="">--Select--</option>
                  <option value="married">Married</option>
                  <option value="unmarried">Unmarried</option>
                  <option value="widow">widow/widower</option>
                  <option value="divorce">Divorcee</option>
                </select>
                </div> 
                
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="religion">Religion</label>
                	<input class="form-control input-sm"  id="religion" name="religion" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
             	<label for="blood_group">Blood Group</label>
                <select  class="form-control input-sm"  id="blood_group" name="blood_group">
                  <option value="">--Select--</option>
                  <option value="a_positive">A+ve</option>
                  <option value="a_nagetive">A-ve</option>
                  <option value="b_positive">B+ve</option>
                  <option value="b_nagetive">B-ve</option>
                  <option value="ab_positive">AB+ve</option>
                  <option value="ab_nagetive">AB-ve</option>
                  <option value="o_positive">O+ve</option>
                  <option value="o_nagetive">O-ve</option>
                </select>
                </div>
                 
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="height">Height</label>
                	<input class="form-control input-sm"  id="height" name="height" type="text" value="" >
              	</div>
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="weight">Weight</label>
                	<input class="form-control input-sm"  id="weight" name="weight" type="text" value="" >
              	</div>
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="address">Address</label>
                	<input class="form-control input-sm"  id="address" name="address" type="text" value="" >
              	</div>
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="city">City</label>
                	<input class="form-control input-sm"  id="city" name="city" type="text" value="" >
              	</div>
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="country">Country</label>
                	<input class="form-control input-sm"  id="country" name="country" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="landline">Landline</label>
                	<input class="form-control input-sm"  id="landline" name="landline" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="mobile">Mobile</label>
                	<input class="form-control input-sm"  id="mobile" name="mobile" type="text" value="" >
              	</div>
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="email">Email</label>
                	<input class="form-control input-sm"  id="email" name="email" type="text" value="" >
              	</div>
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="university_name">University Name</label>
                	<input class="form-control input-sm"  id="university_name" name="university_name" type="text" value="" >
              	</div>
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="university_reg_number">University Reg No</label>
                	<input class="form-control input-sm"  id="university_reg_number" name="university_reg_number" type="text" value="" >
              	</div>
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label  class="checkbox" for="is_disbled" >Is Disabled</label>
                	<input  id="is_disbled" name="is_disbled" type="checkbox" value="" >
              	</div>
                
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="employee_image"  >Emp. Photo</label>
                    <img src=""  id="employee_image" name="employee_image" /><br />No image
              	</div>
                
            </div>
            
             <div class="box-header with-border">
              <h3 class="box-title">Job Profile</h3>
            </div>
            <div class="box-body">
            
             	<div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="doj">Date of Joining</label>
                	<input class="form-control input-sm"  id="doj" name="doj" type="text" value="" placeholder="dd/mm/yyyy" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
             	<label for="employement_type">Employment Type</label>
                <select  class="form-control input-sm"  id="employement_type" name="employement_type">
					<option value="">--Select--</option>
					<option value="0">Regular</option>
					<option value="1">Casual</option>
                </select>
                </div> 
            
            
            	<div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="department">Department</label>
                	<input class="form-control input-sm"  id="department" name="department" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
             	<label for="category">Category</label>
                <select  class="form-control input-sm"  id="category" name="category">
                  <option value="">--Select--</option>
                  <option value="0">Director</option>
                  <option value="1">Employee</option>
                  <option value="1">Locum</option>
                </select>
                </div> 
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="superisor">Supervisor</label>
                	<input class="form-control input-sm"  id="superisor" name="superisor" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label  class="checkbox" for="first_job_in_country" >First Job in Country</label>
                	<input  id="first_job_in_country" name="first_job_in_country" type="checkbox" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label  class="checkbox" for="overtime" >overtime</label>
                	<input  id="overtime" name="overtime" type="checkbox" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label  class="checkbox" for="is_user" >Is User</label>
                	<input  id="is_user" name="is_user" type="checkbox" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label  class="checkbox" for="prorata" >Prorata</label>
                	<input  id="prorata" name="prorata" type="checkbox" value="" >
              	</div>
                </div>
               
               <div class="box-header with-border">
              		<h3 class="box-title">Reference</h3>
            	</div>
            	<div class="box-body">

             	<div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="next_kin">Next of Kin</label>
                	<input class="form-control input-sm"  id="next_kin" name="next_kin" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="kin_email">Kin Email</label>
                	<input class="form-control input-sm"  id="kin_email" name="kin_email" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="kin_mobile">Kin Mobile</label>
                	<input class="form-control input-sm"  id="kin_mobile" name="kin_mobile" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="pin">PIN</label>
                	<input class="form-control input-sm"  id="pin" name="pin" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="spouse_name">Name of Spouse</label>
                	<input class="form-control input-sm"  id="spouse_name" name="spouse_name" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="spouse_email">Spouse Email</label>
                	<input class="form-control input-sm"  id="spouse_email" name="spouse_email" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="spouse_mobile">Spouse Mobile</label>
                	<input class="form-control input-sm"  id="spouse_mobile" name="spouse_mobile" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="hosp_no">Hosp No</label>
                	<input class="form-control input-sm"  id="hosp_no" name="hosp_no" type="text" value="" >
              	</div>
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="nssf_no">NSSF No.</label>
                	<input class="form-control input-sm"  id="nssf_no" name="nssf_no" type="text" value="" >
              	</div>
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="nhif_no">NHIF No</label>
                	<input class="form-control input-sm"  id="nhif_no" name="nhif_no" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="passport_id">National ID/ Passport</label>
                	<input class="form-control input-sm"  id="passport_id" name="passport_id" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="passport_country">National ID/ Passport Country </label>
                	<input class="form-control input-sm"  id="passport_country" name="passport_country" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="sascco_no">SACCO No</label>
                	<input class="form-control input-sm"  id="sascco_no" name="sascco_no" type="text" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label for="cost_center_name">Cost Center Name</label>
                	<input class="form-control input-sm"  id="cost_center_name" name="cost_center_name" type="text" value="" >
              	</div>
                
                </div>
                 
               <div class="box-header with-border">
              		<h3 class="box-title">Bank Details</h3>
            	</div>
            	 <div class="box-body">

                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="bank_name">Bank Name</label>
                        <input class="form-control input-sm"  id="bank_name" name="bank_name" type="text" value="" >
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="branch">Branch</label>
                        <input class="form-control input-sm"  id="branch" name="branch" type="text" value="" >
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="bank_account_no">Account No</label>
                        <input class="form-control input-sm"  id="bank_account_no" name="bank_account_no" type="text" value="" >
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="bank_code">Bank Code</label>
                        <input class="form-control input-sm"  id="bank_code" name="bank_code" type="text" value="" >
                    </div>
                </div>
                
                <div class="box-header with-border">
              		<h3 class="box-title">Insurance</h3>
            	</div>
            	 <div class="box-body">

                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="insurance_company">Company Name</label>
                        <input class="form-control input-sm"  id="insurance_company" name="insurance_company" type="text" value="" >
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="insurance_city">City</label>
                        <input class="form-control input-sm"  id="insurance_city" name="insurance_city" type="text" value="" >
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="policy_type">Policy Type</label>
                        <input class="form-control input-sm"  id="policy_type" name="policy_type" type="text" value="" >
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="policy_number">Policy No</label>
                        <input class="form-control input-sm"  id="policy_number" name="policy_number" type="text" value="" >
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="valid_from">Valid From</label>
                        <input class="form-control input-sm"  id="valid_from" name="valid_from" type="text" value="" placeholder="dd/mm/yyyy" >
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="valid_till">Valid Till</label>
                        <input class="form-control input-sm"  id="valid_till" name="valid_till" type="text" value="" placeholder="dd/mm/yyyy" >
                    </div>
                </div>
                
                
                
                <div class="box-header with-border">
              		<h3 class="box-title">Qualification</h3>
            	</div>
            	 <div class="box-body">

                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="basic_qualification">Basic</label>
                        <input class="form-control input-sm"  id="basic_qualification" name="basic_qualification" type="text" value="" >
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="additional_qualification">Additional </label>
                        <input class="form-control input-sm"  id="additional_qualification" name="additional_qualification" type="text" value="" >
                    </div>
            
           		 </div>
            
             <div class="box-header with-border">
              		<h3 class="box-title">Previous Employer</h3>
            	</div>
            	 	<div class="box-body">

                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="prev_employer_name">Name</label>
                        <input class="form-control input-sm"  id="prev_employer_name" name="prev_employer_name" type="text" value="" >
                    </div>
                     <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="prev_employer_address">Address</label>
                        <input class="form-control input-sm"  id="prev_employer_address" name="prev_employer_address" type="text" value="" >
                    </div>
                    
             </div>
             
             <div class="box-header with-border">
              		<h3 class="box-title">Others</h3>
            	</div>
            	 	<div class="box-body">

                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="promotion_due_on">Promotion Due On</label>
                        <input class="form-control input-sm"  id="promotion_due_on" name="promotion_due_on" type="text" value="" placeholder="dd/mm/yyyy" >
                    </div>
                     <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="increment_due_on">Increment Due on</label>
                        <input class="form-control input-sm"  id="increment_due_on" name="increment_due_on" type="text" value="" placeholder="dd/mm/yyyy" >
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3">
                	<label  class="checkbox" for="free_travel_allowance" >Free Travel Allowance</label>
                	<input  id="free_travel_allowance" name="free_travel_allowance" type="checkbox" value="" >
              	</div>
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label  class="checkbox" for="company_car" >Company Car</label>
                	<input  id="company_car" name="company_car" type="checkbox" value="" >
              	</div>
                   
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="vehicle_no">Vehicle No</label>
                        <input class="form-control input-sm"  id="vehicle_no" name="vehicle_no" type="text" value="" >
                    </div>
                    
             </div>
              <div class="box-header with-border">
              		<h3 class="box-title">Leaving</h3>
            	</div>
            	 	<div class="box-body">

                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="leaving_date">Date of Leaving</label>
                        <input class="form-control input-sm"  id="leaving_date" name="leaving_date" type="text" value="" placeholder="dd/mm/yyyy" >
                    </div>
                     
                    <div class="col-sm-6 col-md-3 col-lg-3">
                	<label  class="checkbox" for="is_blacklisted" >Is Blacklisted</label>
                	<input  id="is_blacklisted" name="is_blacklisted" type="checkbox" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="reason_leaving">Reason for Leaving</label>
                        <input class="form-control input-sm"  id="reason_leaving" name="reason_leaving" type="text" value="" >
                    </div>
                 <div class="col-sm-6 col-md-3 col-lg-3">
                	<label  class="checkbox" for="last_job_kenya_expartriate" >Last job in Kenya for Expartriate</label>
                	<input  id="last_job_kenya_expartriate" name="last_job_kenya_expartriate" type="checkbox" value="" >
              	</div>
                <div class="col-sm-6 col-md-3 col-lg-3">
                	<label  class="checkbox" for="emp_status_on_hold" >Employee Status on Hold</label>
                	<input  id="emp_status_on_hold" name="emp_status_on_hold" type="checkbox" value="" >
              	</div>
                   
                    <div class="col-sm-6 col-md-3 col-lg-3">
                        <label for="date_holding_vehigle_no">Date of HoldingVehicle No</label>
                        <input class="form-control input-sm"  id="date_holding_vehigle_no" name="date_holding_vehigle_no" type="text" value="" placeholder="dd/mm/yyyy" >
                    </div>

                    
             </div>
			
          
          
              <div class="box-footer">
                <div class="form btn pull-right">
                 
                <input type="hidden" name="_token" value="">
                <input type="hidden" name="table_name" id="table_name" value="master_employee">
                <input type="hidden" name="table_auto_id" id="table_auto_id" value="">
                <input type="hidden" name="form_action" id="form_action" value="insert">
				
                <input type="submit" accesskey="s" class="btn btn-info btn-flat btn-md pull-right ajax" id="save_data" value="Save (ALT+S)" />

      <span class="no-access-big"></span>  

                </div>
             </div>
  </form>
 </div>     
</div>
    </div> 
 
  </section>
<script>
    $('#register_date').datepicker({
      autoclose: true
    })
    $('#validity_date').datepicker({
      autoclose: true
    })
     $('#dob').datepicker({
      autoclose: true
    })
    $('#doj').datepicker({
      autoclose: true
    })

    $('#valid_from').datepicker({
      autoclose: true
    })
    $('#valid_till').datepicker({
      autoclose: true
    })

    $('#promotion_due_on').datepicker({
      autoclose: true
    })
    $('#increment_due_on').datepicker({
      autoclose: true
    })	
    $('#leaving_date').datepicker({
      autoclose: true
    })
    $('#date_holding_vehigle_no').datepicker({
      autoclose: true
    })	






	
</script>
<?php include ("includes/footer.php"); ?>