
1) On login form we need "master_employee" table And we are checking the user is activated and Expiry date.
	(Don't Delete this "master_employee" Table)
	
2) On login form we need "details_login" table. We are getting the login details for that perticular user.

3) How many times he is login into system, details will gets in "login_restriction.auto_number" column.

4) To check the user login limitation Free / Paid details in "master_edition" tbale.

5) Using "master_company" we are setting company autono , name and code into session.
	(Don't Delete this "master_company" Table)
	
6) Using "master_employeelocation" we are checking the login user have permission for how many different location access.
	IF there is only one location then it will continue to go dashboard page. ELSE we need to select the Location first.
	(Don't Delete this "master_employeelocation" Table)
	
7)

