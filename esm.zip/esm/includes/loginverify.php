<?php
include ("db/db_connect.php");
date_default_timezone_set('Asia/Calcutta'); 
$pagename = '';

if (!isset($_SESSION["username"])) header ("location:index.php");

if (isset($_SESSION['username'])) { $username1 = $_SESSION['username']; } else { $username1 = ""; }

$query1 = "select * from login_restriction where username = '$username1'";
$exec1 = mysql_query($query1) or die ("Error in Query1".mysql_error());
$res1 = mysql_fetch_array($exec1);
$rowcount1 = mysql_num_rows($exec1);

$res1sessionid = $res1['sessionid'];

if ($res1sessionid != session_id())
{
	//echo 'inside if';
	//header ("location:login1restricted1.php");
	//exit;
}

if (!isset($_SESSION["companyanum"])) 
{
	header ("location:setactivecompany.php"); 
}
$ipaddress = $_SERVER["REMOTE_ADDR"];
$username = $_SESSION["username"];

$pagename = basename($_SERVER['REQUEST_URI'], ".php");

$query881 = "select * from master_menumain where mainmenulink='$pagename'";
$exec881 = mysql_query($query881) or die(mysql_error());
$res881 = mysql_fetch_array($exec881);
$menumainid = $res881['mainmenuid'];

$query882 = "select * from master_employeerights where mainmenuid='$menumainid' and username='$username'";
$exec882 = mysql_query($query882) or die(mysql_error());
$num882 = mysql_num_rows($exec882);

$_SESSION['timeout'] = time();

?>
