<?php
session_start();
include ("db/db_connect.php");
error_reporting(0);
$ipaddress = $_SERVER['REMOTE_ADDR'];
$updatedatetime = date('Y-m-d H:i:s');

if (isset($_SESSION["username"]))
{
	$logintime = trim($_SESSION["logintime"]);
	$username = trim($_SESSION['username']);	
	$query1 = "update details_login set logouttime = '$updatedatetime', status = 'Deactive' where username = '$username' and logintime = '$logintime'";
	$exec1 = mysql_query($query1) or die ("Error in query1".mysql_error());
	
	$query11 = "update login_restriction set logouttime = '$updatedatetime' where username = '$username' and logintime = '$logintime'";
	$exec11 = mysql_query($query11) or die ("Error in query11".mysql_error());
	
}
else
{
	$logintime = trim($_COOKIE["logintime"]);
	$username = trim($_COOKIE['username']);	
	$query1 = "update details_login set logouttime = '$updatedatetime' , status = 'Deactive' where username = '$username' and logintime = '$logintime'";
	$exec1 = mysql_query($query1) or die ("Error in query1".mysql_error());
	
	$query11 = "update login_restriction set logouttime = '$updatedatetime' where username = '$username' and logintime = '$logintime'";
	$exec11 = mysql_query($query11) or die ("Error in query11".mysql_error());
	
}
setcookie('logout','logout', time() + (86400 * 1));
unset($_COOKIE['username']);
unset($_COOKIE['logintime']);
session_destroy();
session_start();
//header ("location:index.php");


?><html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Exite School Management | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="css/blue.css">
  </head>
<body class="hold-transition login-page"  onLoad="return setFocus()">
<div class="login-box">
  <div class="login-logo">
     User Logout  
  </div>
  <!-- /.login-logo -->
	<div class="login-box-body">
		
		<div class="form-group has-feedback">
			<p class="login-box-msg"> <b> Logout Completed. </b> </p>
			<p class="login-box-msg"> <b >To Login Again <a href="index.php">Click Here.</a> </b> </p>
		</div>
 
	</div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="js/jquery.min1.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="js/icheck.min.js"></script>
    <script>
      $(function () {
        $('input').iCheck({
          checkboxClass: 'icheckbox_square-blue',
          radioClass: 'iradio_square-blue',
          increaseArea: '20%' // optional
        });
      });
    </script>
</body>
</html>
