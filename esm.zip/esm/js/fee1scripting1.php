<script type="text/javascript">

function studentsearch1(varCallFrom)
{
	var varCallFrom = varCallFrom;
	if(varCallFrom == 'application')
	{
		window.open("popup_studentsearch2.php?callfrom="+varCallFrom,"Window2",'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=900,height=350,left=100,top=100');
	}
	if(varCallFrom == 'admission')
	{
		window.open("popup_studentsearch1.php?callfrom="+varCallFrom,"Window2",'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=1200,height=350,left=100,top=100');
	}		
}

function btnDeleteClick(delID)
{
	//alert ("Inside btnDeleteClick.");
	
	var varDeleteID = delID;
	//alert (varDeleteID);
	var fRet3; 
	//fRet3 = confirm('Are You Sure Want To Remove This Entry?'); 
	//alert(fRet); 
	//if (fRet3 == false)
	//{
		//alert ("Item Entry Not Deleted.");
		//return false;
	//}

	var child = document.getElementById('idTR'+varDeleteID);  //tr name
    var parent = document.getElementById('tblrowinsert'); // tbody name.
	document.getElementById ('tblrowinsert').removeChild(child);
	
	var child = document.getElementById('idTRaddtxt'+varDeleteID);  //tr name
    var parent = document.getElementById('tblrowinsert'); // tbody name.
	//alert (child);
	if (child != null) 
	{
		//alert ("Row Exsits.");
		document.getElementById ('tblrowinsert').removeChild(child);
	}
	
	//alert ("Entry Removed Successfully.");
	
	//funcSubTotalCalc();
	
	AssignfeeCalc(varDeleteID);
}

function funcSubTotalCalc()
{
	var varSerialNumberUpdate = 0;
	var varTotalAmount = 0;
	var varTotalAmountLoop = 0;
	for (m=1;m<20;m++)
	{
		
		if (document.getElementById('serialnumber'+m) != null) 
		{
			var varSerialNumberUpdate = varSerialNumberUpdate + 1;
			document.getElementById('serialnumber'+m).value = varSerialNumberUpdate;
			
			var varTotalAmountLoop = document.getElementById('totalamount'+m).value;
			if (varTotalAmountLoop != null) 
			{
				//alert (varTotalAmountLoop);
				var varTotalAmount = parseFloat(varTotalAmount) + parseFloat(varTotalAmountLoop);
			}
		}
	}
	//var varSerialNumberUpdate = varSerialNumberUpdate + 1;
	//document.getElementById('itemserialnumber').value = varSerialNumberUpdate;
	document.getElementById('subtotal').value = varTotalAmount.toFixed(2);
	document.getElementById('nettotal').value = varTotalAmount.toFixed(2);
	document.getElementById('totalafterdiscount').value = varTotalAmount.toFixed(2);
	
	var varSubTotalAmount = document.getElementById("subtotal").value;
	
	var varTotalAfterDiscount = document.getElementById("subtotal").value;
	var varTotalAfterDiscount = parseFloat(varTotalAfterDiscount);
	//alert (varTotalAfterDiscount);
	var varTotalAmountLoop = document.getElementById('subtotal').value;
	if (varTotalAmountLoop != '') 
	{
		if(document.getElementById('subtotaldiscountamount').value == '0.00' && document.getElementById('subtotaldiscountpercent').value != '0.00')
		{	
			var DiscPercent = document.getElementById('subtotaldiscountpercent').value;
			var varDiscAmountCalc1 = parseFloat(DiscPercent);
			var varDiscAmountCalc1 = varDiscAmountCalc1 * 1;
			var varDiscAmountCalc2 = parseFloat(varDiscAmountCalc1) / 100;
			var varDiscAmountCalc3 = parseFloat(varDiscAmountCalc2) * parseFloat(varTotalAmountLoop);
			//alert(varDiscAmountCalc3);
			document.getElementById('subtotaldisamount').value = varDiscAmountCalc3.toFixed(2);
			document.getElementById('discount').value = varDiscAmountCalc3.toFixed(2);
			document.getElementById('subtotaldispercent').value = '0.00';
			var Amount1 = parseFloat(varTotalAmountLoop) - parseFloat(varDiscAmountCalc3);
			document.getElementById('totalafterdiscount').value = Amount1.toFixed(2);
			document.getElementById('nettotal').value = Amount1.toFixed(2);
		}
		else if(document.getElementById('subtotaldiscountpercent').value == '0.00' && document.getElementById('subtotaldiscountamount').value != '0.00')
		{	
			var DiscAmount = document.getElementById('subtotaldiscountamount').value;
			var varDiscpercentCalc1 = parseFloat(DiscAmount);
			var varDiscpercentCalc1 = varDiscpercentCalc1 * 1;
			var varDiscpercentCalc2 = parseFloat(varDiscpercentCalc1);
			var varDiscpercentCalc3 = parseFloat(varDiscpercentCalc2) / parseFloat(varTotalAmountLoop);
			var varDiscpercentCalc4 = parseFloat(varDiscpercentCalc3) * 100;
			//alert(varDiscAmountCalc3);
			document.getElementById('subtotaldispercent').value = varDiscpercentCalc4.toFixed(2);
			document.getElementById('subtotaldisamount').value = '0.00';
			document.getElementById('discount').value = varDiscpercentCalc2.toFixed(2);
			var Amount1 = parseFloat(varTotalAmountLoop) - parseFloat(varDiscpercentCalc1);
			document.getElementById('totalafterdiscount').value = Amount1.toFixed(2);
			document.getElementById('nettotal').value = Amount1.toFixed(2);
		}
		
	}
	
	funcNetAmountCalc1();
}

function funcDiscCalc(m)
{
	var varSerialNumberUpdate = 0;
	var varTotalAmount = 0;
	var varTotalAmountLoop = 0;
	//for (m=1;m<20;m++)
	//{
		
		if (document.getElementById('serialnumber'+m) != null) 
		{
			var varSerialNumberUpdate = varSerialNumberUpdate + 1;
			document.getElementById('serialnumber'+m).value = varSerialNumberUpdate;
			
			var varTotalAmountLoop = document.getElementById('totalamount'+m).value;
			if (varTotalAmountLoop != null) 
			{
				if(document.getElementById('discountrupees'+m).value == '0.00' && document.getElementById('discountpercent'+m).value != '0.00')
				{	
					var DiscPercent = document.getElementById('discountpercent'+m).value;
					var varDiscAmountCalc1 = parseFloat(DiscPercent);
					var varDiscAmountCalc1 = varDiscAmountCalc1 * 1;
					var varDiscAmountCalc2 = parseFloat(varDiscAmountCalc1) / 100;
					var varDiscAmountCalc3 = parseFloat(varDiscAmountCalc2) * parseFloat(varTotalAmountLoop);
					//alert(varDiscAmountCalc3);
					document.getElementById('discountrupees'+m).value = varDiscAmountCalc3.toFixed(2);
					var Amount1 = parseFloat(varTotalAmountLoop) - parseFloat(varDiscAmountCalc3);
					document.getElementById('totalamount'+m).value = Amount1.toFixed(2);
				}
				else if(document.getElementById('discountpercent'+m).value == '0.00' && document.getElementById('discountrupees'+m).value != '0.00')
				{	
					var DiscAmount = document.getElementById('discountrupees'+m).value;
					var varDiscpercentCalc1 = parseFloat(DiscAmount);
					var varDiscpercentCalc1 = varDiscpercentCalc1 * 1;
					var varDiscpercentCalc2 = parseFloat(varDiscpercentCalc1);
					var varDiscpercentCalc3 = parseFloat(varDiscpercentCalc2) / parseFloat(varTotalAmountLoop);
					var varDiscpercentCalc4 = parseFloat(varDiscpercentCalc3) * 100;
					//alert(varDiscAmountCalc3);
					document.getElementById('discountpercent'+m).value = varDiscpercentCalc4.toFixed(2);
					var Amount1 = parseFloat(varTotalAmountLoop) - parseFloat(varDiscpercentCalc1);
					document.getElementById('totalamount'+m).value = Amount1.toFixed(2);
				}
				
			}
		}
	//}
	funcSubTotalCalc();

}

function paymentinfo()
{
	document.getElementById("cashamount").value = "0.00";
	document.getElementById("cashgivenbycustomer").value = "0.00";
	document.getElementById("cashgiventocustomer").value = "0.00";
	document.getElementById("chequeamount").value = "0.00";
	document.getElementById("chequedate").value = "";
	document.getElementById("chequenumber").value = "";
	document.getElementById("chequebank").value = "";
	//document.getElementById("nettamount").value = "0.00";

	document.getElementById("cashamount").readOnly = true;
	document.getElementById("chequeamount").readOnly = true;

	if (document.getElementById("billtype").value == "")
	{
		document.getElementById("cashamounttr").style.display = 'none';
		document.getElementById("cashamounttr2").style.display = 'none';
		document.getElementById("cashamounttr3").style.display = 'none';
		document.getElementById("chequeamounttr").style.display = 'none';
		document.getElementById("ddamounttr").style.display = 'none';
		
		document.getElementById("cashamount").value = "0.00";
		document.getElementById("cashgivenbycustomer").value = "0.00";
		document.getElementById("cashgiventocustomer").value = "0.00";
		document.getElementById("creditamount").value = "0.00";
		document.getElementById("chequeamount").value = "0.00";
		document.getElementById("chequedate").value = "";
		document.getElementById("chequenumber").value = "";
		document.getElementById("chequebank").value = "";
		document.getElementById("ddamount").value = "0.00";
		document.getElementById("dddate").value = "";
		document.getElementById("ddnumber").value = "";
		document.getElementById("ddbank").value = "";
		document.getElementById("onlineamount").value = "0.00";
		document.getElementById("nettamount").value = "0.00";
	}
	if (document.getElementById("billtype").value == "CASH")
	{
		document.getElementById("cashamounttr").style.display = '';
		document.getElementById("cashamounttr2").style.display = '';
		document.getElementById("cashamounttr3").style.display = '';
		document.getElementById("chequeamounttr").style.display = 'none';
		document.getElementById("creditamounttr").style.display = 'none';
		document.getElementById("cardamounttr").style.display = 'none';
		document.getElementById("onlineamounttr").style.display = 'none';
		document.getElementById("ddamounttr").style.display = 'none';
		
		document.getElementById("cashamount").value = document.getElementById("nettotal").value
		document.getElementById("cashgivenbycustomer").value = "0.00";
		document.getElementById("cashgiventocustomer").value = "0.00";
		document.getElementById("creditamount").value = "0.00";
		document.getElementById("chequeamount").value = "0.00";
		document.getElementById("chequedate").value = "";
		document.getElementById("chequenumber").value = "";
		document.getElementById("chequebank").value = "";
		document.getElementById("onlineamount").value = "0.00";
		//document.getElementById("nettamount").value = "0.00";
		///*
		document.getElementById("cashgivenbycustomer").value = "";
		document.getElementById("cashgivenbycustomer").focus();
		//document.getElementById("cashgivenbycustomer").select();
		//*/
		document.getElementById("nettotal").value = document.getElementById("cashamount").value

	}
	
	if (document.getElementById("billtype").value == "CHEQUE")
	{
		document.getElementById("cashamounttr").style.display = 'none';
		document.getElementById("cashamounttr2").style.display = 'none';
		document.getElementById("cashamounttr3").style.display = 'none';
		document.getElementById("chequeamounttr").style.display = '';
		document.getElementById("creditamounttr").style.display = 'none';
		document.getElementById("cardamounttr").style.display = 'none';
		document.getElementById("onlineamounttr").style.display = 'none';
		document.getElementById("ddamounttr").style.display = 'none';
		
		document.getElementById("cashamount").value = "0.00";
		document.getElementById("cashgivenbycustomer").value = "0.00";
		document.getElementById("cashgiventocustomer").value = "0.00";
		document.getElementById("creditamount").value = "0.00";
		document.getElementById("ddamount").value = "0.00";
		document.getElementById("chequeamount").value = document.getElementById("nettotal").value
		document.getElementById("chequedate").value = "";
		document.getElementById("chequenumber").value = "";
		document.getElementById("chequebank").value = "";
		document.getElementById("ddamount").value = "0.00";
		document.getElementById("ddnumber").value = "";
		document.getElementById("dddate").value = "";
		document.getElementById("ddbank").value = "";
		document.getElementById("onlineamount").value = "0.00";
		document.getElementById("nettamount").value = "0.00";

		document.getElementById("chequeamount").focus();
	}
	if (document.getElementById("billtype").value == "CREDIT CARD")
	{
		document.getElementById("cashamounttr").style.display = 'none';
		document.getElementById("cashamounttr2").style.display = 'none';
		document.getElementById("cashamounttr3").style.display = 'none';
		document.getElementById("chequeamounttr").style.display = 'none';
		document.getElementById("creditamounttr").style.display = 'none';
		document.getElementById("cardamounttr").style.display = '';
		document.getElementById("onlineamounttr").style.display = 'none';
		//document.getElementById("nettamounttr").style.display = 'none';
		
		document.getElementById("cashamount").value = "0.00";
		document.getElementById("cashgivenbycustomer").value = "0.00";
		document.getElementById("cashgiventocustomer").value = "0.00";
		document.getElementById("creditamount").value = "0.00";
		document.getElementById("chequeamount").value = "0.00";
		document.getElementById("chequedate").value = "";
		document.getElementById("chequenumber").value = "";
		document.getElementById("chequebank").value = "";
		document.getElementById("cardname").value = "";
		document.getElementById("cardnumber").value = "";
		document.getElementById("bankname").value = "";
		document.getElementById("cardamount").value = document.getElementById("nettotal").value
		document.getElementById("onlineamount").value = "0.00";
		document.getElementById("nettamount").value = "0.00";

		document.getElementById("cardamount").focus();
	}
	if (document.getElementById("billtype").value == "ONLINE")
	{
		document.getElementById("cashamounttr").style.display = 'none';
		document.getElementById("cashamounttr2").style.display = 'none';
		document.getElementById("cashamounttr3").style.display = 'none';
		document.getElementById("chequeamounttr").style.display = 'none';
		document.getElementById("creditamounttr").style.display = 'none';
		document.getElementById("cardamounttr").style.display = 'none';
		document.getElementById("onlineamounttr").style.display = '';
		//document.getElementById("nettamounttr").style.display = 'none';
		
		document.getElementById("cashamount").value = "0.00";
		document.getElementById("cashgivenbycustomer").value = "0.00";
		document.getElementById("cashgiventocustomer").value = "0.00";
		document.getElementById("creditamount").value = "0.00";
		document.getElementById("chequeamount").value = "0.00";
		document.getElementById("chequedate").value = "";
		document.getElementById("chequenumber").value = "";
		document.getElementById("chequebank").value = "";
		document.getElementById("cardname").value = "";
		document.getElementById("cardnumber").value = "";
		document.getElementById("bankname").value = "";
		document.getElementById("cardamount").value = "0.00";
		document.getElementById("onlineamount").value = document.getElementById("totalamount").value
		document.getElementById("nettamount").value = "0.00";

		document.getElementById("onlineamount").focus();
	}
	if (document.getElementById("billtype").value == "DD")
	{
		document.getElementById("cashamounttr").style.display = 'none';
		document.getElementById("cashamounttr2").style.display = 'none';
		document.getElementById("cashamounttr3").style.display = 'none';
		document.getElementById("chequeamounttr").style.display = 'none';
		document.getElementById("creditamounttr").style.display = 'none';
		document.getElementById("cardamounttr").style.display = 'none';
		document.getElementById("onlineamounttr").style.display = 'none';
		document.getElementById("ddamounttr").style.display = '';
		
		document.getElementById("cashamount").value = "0.00";
		document.getElementById("cashgivenbycustomer").value = "0.00";
		document.getElementById("cashgiventocustomer").value = "0.00";
		document.getElementById("creditamount").value = "0.00";
		document.getElementById("chequeamount").value = "0.00";
		document.getElementById("chequedate").value = "";
		document.getElementById("chequenumber").value = "";
		document.getElementById("chequebank").value = "";
		document.getElementById("onlineamount").value = "0.00";
		document.getElementById("ddamount").value = document.getElementById("nettotal").value
		
	}

}

function funcBodyOnLoad()
{
	document.getElementById("cashamounttr").style.display = 'none';
	document.getElementById("cashamounttr2").style.display = 'none';
	document.getElementById("cashamounttr3").style.display = 'none';
	document.getElementById("chequeamounttr").style.display = 'none';
	document.getElementById("creditamounttr").style.display = 'none';
	document.getElementById("cardamounttr").style.display = 'none';
	document.getElementById("onlineamounttr").style.display = 'none';
	document.getElementById("ddamounttr").style.display = 'none';

}

function funcbillamountcalc1()
{
	///*
	if (document.getElementById("cashgivenbycustomer").value == "")
	{
		document.getElementById("cashgivenbycustomer").value = "0.00"
		return false;
	}
	//*/
	
	funcPaymentInfoCalculation1()
}

function funcPaymentInfoCalculation1()
{
	if (isNaN(document.getElementById("cashamount").value))
	{
		alert ("Cash Amount Can Only Be Numbers.");
		document.getElementById("cashamount").value = "0.00"
		document.getElementById("cashamount").focus();
		return false;
	}
	document.getElementById("cashamount").value = parseFloat(document.getElementById("cashamount").value).toFixed(2);
	///*
	if (isNaN(document.getElementById("cashgivenbycustomer").value))
	{
		alert ("Cash Given By Customer Can Only Be Numbers.");
		document.getElementById("cashgivenbycustomer").value = "0.00"
		document.getElementById("cashgivenbycustomer").focus();
		return false;
	}
	document.getElementById("cashgivenbycustomer").value = parseFloat(document.getElementById("cashgivenbycustomer").value).toFixed(2);
	//*/
	
	if (isNaN(document.getElementById("chequeamount").value))
	{
		alert ("Cheque Amount Can Only Be Numbers.");
		document.getElementById("chequeamount").value = "0.00"
		document.getElementById("chequeamount").focus();
		return false;
	}
	document.getElementById("chequeamount").value = parseFloat(document.getElementById("chequeamount").value).toFixed(2);
	
	if (document.getElementById("billtype").value == "CASH")
	{	
		document.getElementById("nettamount").value = document.getElementById("cashamount").value;
		//to calculate the cash to be return to customer
		///*
		var varCashGivenByCustomer1 = document.getElementById("cashgivenbycustomer").value;
		var varCashGivenToCustomer1 = document.getElementById("cashgiventocustomer").value;
		var varActualCashAmount = document.getElementById("cashamount").value;
		var varCashGivenToCustomer1 = parseFloat(varCashGivenByCustomer1).toFixed(2) - parseFloat(varActualCashAmount).toFixed(2);
		var varVarFinalCashGivenToCustomer1 = parseFloat(varCashGivenToCustomer1).toFixed(2);
		document.getElementById("cashgiventocustomer").value = varVarFinalCashGivenToCustomer1;
		//*/
	}
	if (document.getElementById("billtype").value == "CREDIT")
	{	
		document.getElementById("nettotal").value = document.getElementById("creditamount").value;
	}
	if (document.getElementById("billtype").value == "ONLINE")
	{	
		document.getElementById("nettotal").value = document.getElementById("onlineamount").value;
	}
	if (document.getElementById("billtype").value == "CHEQUE")
	{	
		document.getElementById("nettotal").value = document.getElementById("chequeamount").value;
	}
	if (document.getElementById("billtype").value == "CREDIT CARD")
	{	
		document.getElementById("nettotal").value = document.getElementById("cardamount").value;
	}
	if (document.getElementById("billtype").value == "SPLIT")
	{	
		var varCashAmount = document.getElementById("cashamount").value;
		var varCreditAmount = document.getElementById("creditamount").value;
		var varChequeAmount = document.getElementById("chequeamount").value;
		var varCardAmount = document.getElementById("cardamount").value;
		var varOnlineAmount = document.getElementById("onlineamount").value;
		var varTotalNettAmount = parseFloat(varCashAmount) + parseFloat(varCreditAmount) + parseFloat(varChequeAmount) + parseFloat(varCardAmount) + parseFloat(varOnlineAmount);
		var varTotalNettAmount = varTotalNettAmount.toFixed(2);
		document.getElementById("nettotal").value = varTotalNettAmount;
	}
}

function funcNetAmountCalc1()
{
	var varNetAmount = document.getElementById('totalafterdiscount').value;	
	//alert(varNetAmount);
<?php

$roundoffvalue = 'NEAREST ONE RUPEE';

if ($roundoffvalue == 'NO ROUND OFF')
{
?>
	//no round off apply.
	//alert ("NO ROUND OFF");
	var varNetAmount2 = varNetAmount;
	var varNetAmount2 = varNetAmount2 * 1;
	var varNetAmount2 = varNetAmount2.toFixed(2);
	//document.getElementById('netamount').value = varNetAmount2;
<?php
}
if ($roundoffvalue == 'NEAREST TEN PAISE')
{
?>
	//to round off to nearest ten paise.
	//alert ("NEAREST TEN PAISE");
	var varNetAmount2 = varNetAmount;
	var varNetAmount2 = varNetAmount2 * 1;
	var varNetAmount2 = varNetAmount2.toFixed(1);
	var varNetAmount2 = varNetAmount2 * 1;
	var varNetAmount2 = varNetAmount2.toFixed(2);
	//document.getElementById('netamount').value = varNetAmount2;
<?php
}
if ($roundoffvalue == 'NEAREST FIFTY PAISE')
{
?>
	//to round off to nearest fifty paise.
	//alert ("NEAREST FIFTY PAISE");
	var varNetAmount2 = varNetAmount;
	var varNetAmount2 = varNetAmount2 * 1;
	var varNetAmount2 = roundToHalf(varNetAmount2); //function given below 
	var varNetAmount2 = varNetAmount2 * 1;
	var varNetAmount2 = varNetAmount2.toFixed(2);
	//document.getElementById('netamount').value = varNetAmount2;
<?php
}
if ($roundoffvalue == 'NEAREST ONE RUPEE')
{
?>
	//to round off to nearest rupee.
	//alert ("NEAREST ONE RUPEE");
	var varNetAmount2 = varNetAmount;
	var varNetAmount2 = varNetAmount2 * 1;
	var varNetAmount2 = varNetAmount2.toFixed(0);
	var varNetAmount2 = varNetAmount2 * 1;
	var varNetAmount2 = varNetAmount2.toFixed(2);
	//document.getElementById('netamount').value = varNetAmount2;
<?php
}
if ($roundoffvalue == 'NEAREST FIVE RUPEES')
{
?>
	//to round off to nearest five rupees.
	//alert ("NEAREST FIVE RUPEES");
	var varNetAmount2 = varNetAmount;
	var varNetAmount2 = varNetAmount2 * 1;
	var varNetAmount2 = round5(varNetAmount2); //function given below 
	var varNetAmount2 = varNetAmount2 * 1;
	var varNetAmount2 = varNetAmount2.toFixed(2);
	//document.getElementById('netamount').value = varNetAmount2;
<?php
}
if ($roundoffvalue == 'NEAREST TEN RUPEES')
{
?>
	//to round off to nearest ten rupees.
	//alert ("NEAREST TEN RUPEES");
	var varNetAmount2 = varNetAmount;
	var varNetAmount2 = varNetAmount2 * 1;
	var varNetAmount2 = round10(varNetAmount2); //function given below 
	var varNetAmount2 = varNetAmount2 * 1;
	var varNetAmount2 = varNetAmount2.toFixed(2);
	//document.getElementById('netamount').value = varNetAmount2;
<?php
}
?>


	var varBeforeRoundOff = varNetAmount;
	var varBeforeRoundOff = parseFloat(varBeforeRoundOff);
	//var varAfterRoundOff = Math.round(varBeforeRoundOff);
	var varAfterRoundOff = varNetAmount2;
	var varAfterRoundOff = parseFloat(varAfterRoundOff);
	var varRoundOffAmount = parseFloat(varAfterRoundOff) - parseFloat(varBeforeRoundOff);
	//alert (varRoundOffAmount);
	
	//document.getElementById("totalamount").value = varNetAmount.toFixed(2);
	document.getElementById("roundoff").value = varRoundOffAmount.toFixed(2);
	document.getElementById("nettotal").value = varAfterRoundOff.toFixed(2);
	
	/*var varTDShowTotalAmount1 = document.getElementById("totalamount").value;
	//var varTDShowTotalAmount1 = "Total: "+varTDShowTotalAmount1;
	document.getElementById("tdShowTotalAmount1").innerHTML = varTDShowTotalAmount1;
	
	var varAdvanceAmountPaid1 = document.getElementById('advanceamountpaid').value;
	//alert (varAdvanceAmountPaid1);
	var varTotalBillAmount1 = document.getElementById('totalamount').value;
	//alert (varTotalBillAmount1);
	var varPendingBalanceAmount1 = parseFloat (varTotalBillAmount1) - parseFloat(varAdvanceAmountPaid1); 
	//alert (varPendingBalanceAmount1);
	document.getElementById('balanceafteradvance').value = parseFloat(varPendingBalanceAmount1).toFixed(2);
	*/
}

function round5(x) 
{     
	return (x % 5) >= 2.5 ? parseInt(x / 5) * 5 + 5 : parseInt(x / 5) * 5; 
}  
function round10(x) 
{     
	return (x % 10) >= 5 ? parseInt(x / 10) * 10 + 10 : parseInt(x / 10) * 10; 
}  
function roundToHalf(value) 
{ 
   var converted = parseFloat(value); // Make sure we have a number 
   var decimal = (converted - parseInt(converted, 10)); 
   decimal = Math.round(decimal * 10); 
   if (decimal == 5) 
   { 
	   return (parseInt(converted, 10)+0.5); 
   } 
   if ( (decimal < 3) || (decimal > 7) ) 
   { 
      return Math.round(converted); 
   } 
   else 
   {
      return (parseInt(converted, 10)+0.5); 
   } 
} 

</script>