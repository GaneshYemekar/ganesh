<?php
session_start();
//echo session_id();
include ("db/db_connect.php");
include ("includes/loginverify.php");
date_default_timezone_set('Asia/Calcutta');

$usercode = '';
$academicyear = '';
$academicyearfrom = '';
$academicyearto = '';
$srno = "";
$errmsg = "";
$bgcolorcode = "";
$colorloopcount = "";

$ipaddress = $_SERVER["REMOTE_ADDR"];
$updatedatetime = date('Y-m-d H:i:s');
$logintime = $_SESSION["logintime"];

$username = $_SESSION["username"];
$usercode = $_SESSION["usercode"];
$docno = $_SESSION["docno"];

$locationname = $_SESSION["locationname"];
$locationcode = $_SESSION["locationcode"];

$companyanum = $_SESSION["companyanum"];
$companyname = $_SESSION["companyname"];
$companycode = $_SESSION["companycode"];


if (isset($_REQUEST["frmflag1"])) { $frmflag1 = $_REQUEST["frmflag1"]; } else { $frmflag1 = ""; }
	if ($frmflag1 == 'frmflag1')
	{
		if (isset($_REQUEST["submit"])) { $submit = $_REQUEST["submit"]; } else { $submit = ""; }	
		if ($submit == 'Save')
		{		
			$menu_id = $_REQUEST["mainmenuid"];
			$mainmenuorder = $_REQUEST["mainmenuorder"];
			$menu_name = $_REQUEST['mainmenu_name'];
			$menu_url = $_REQUEST['mainmenu_url'];
			$editanum = $_REQUEST['editanum'];
			$menu_icon = $_REQUEST['menu_icon'];
			
			
			$Query = "update master_menumain set mainmenuorder = '".$mainmenuorder."', mainmenutext = '".$menu_name."', mainmenulink = '".$menu_url."',menuiconclass='$menu_icon', username = '$username', ipaddress = '$ipaddress', entrydate = now(), locationname = '$locationname', locationcode = '$locationcode' where auto_number = '$editanum' and mainmenuid = '$menu_id' ";
			
			$exec1 = mysql_query($Query) or die ("Error in Query".mysql_error());
			$errmsg = "Success. Main Menu Edited";
			//exit;
			$bgcolorcode = 'success';
            if($exec1){
				header ("Location:mastermainmenu.php");
			}
			
	    } 
	}

	
	
	if (isset($_REQUEST["st"])) { $st = $_REQUEST["st"]; } else { $st = ""; }
	if ($st == 'edit')
	{
	$postanum = $_REQUEST["anum"];
		$Query = "select * from master_menumain where auto_number = '".$postanum."'";
		$exec3 = mysql_query($Query) or die ("Error in Query".mysql_error());	
		$res3 = mysql_fetch_array($exec3);
		$editanum = $res3['auto_number'];
		$editname = $res3['mainmenutext'];
		$editid = $res3['mainmenuid'];
		$editurl = $res3['mainmenulink'];
		$editorder = $res3['mainmenuorder'];
	}

	
	
?>
<?php include ("includes/header.php");  ?>
  
  
<script language="javascript">
	function process1()
	{
		//alert ("Inside Funtion");
		if (document.form1.menu_id.value == "")
		{
			alert ("Please Select the Menu ID");
			document.form1.menu_id.focus();
			return false;
		}
		if (document.form1.mainmenu_name.value == "")
		{
			alert ("Please Enter Sub Menu Name");
			document.form1.mainmenu_name.focus();
			return false;
		}
		
		if (document.form1.mainmenu_url.value == "")
		{
			alert ("Please Enter Sub Menu URL");
			document.form1.mainmenu_url.focus();
			return false;
		}

	}

</script>

<script>
function funchgico(clsid)
{
if(clsid == '')
{
document.getElementById('icon_div').innerHTML='';
}
else
{
document.getElementById('icon_div').innerHTML="<i class='fa "+clsid+"' style='font-size:28;' aria-hidden='true'></i>";
}
}
function funcDeletesurgery(submenuname){
	

	var confirm1=confirm("Are you sure want to delete ' "+submenuname+" ' Main menu?");
	if(confirm1 == false) 
	{ 
		return false; 
	}   
	
}	

function funcActivatesurgery(submenuname){
	
	var confirm2=confirm("Are you sure want to activate ' "+submenuname+" ' sub menu?");
	if(confirm2 == false) 
	{ 
		return false; 
	}   
	
}	
$(function () {
    $("#menu_icon").live("change", function () {

    // do whatever you need to do
	alert($("#menu_icon"));
    // you want the element to lose focus immediately
    // this is key to get this working.
    $('#selected').blur();
    });
});	
</script>

	
    <section class="content">
		<div class="row">
        <div class="col-md-12">
		<div class="box box-info">
			
			<div class="box-header with-border">
				<h3 class="box-title">Edit New Sub-Menu</h3>

				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				<!--	<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button> -->
				</div>
			</div>
        <!-- /.box-header -->
		<!-- form start -->
		<form class="form-horizontal" name="form1" id="form1" method="post" action="mastermainmenuedit1.php" onSubmit="return process1()" >		
			<div class="box-body">
				<div class="row">
					<div class="box-body">
					
													
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Main Menu ID </label>

							<div class="col-sm-6">
								<input type="text" name="mainmenuid" id="mainmenuid" class="form-control" value="<?php echo $editid;?>" readonly>
							</div>
						</div>
							
						<div class="form-group">
							<label for="inputPassword3" class="col-sm-2 control-label">Main Menu Order </label>

							<div class="col-sm-6">
								<input type="text" name="mainmenuorder" id="mainmenuorder" class="form-control" placeholder="Mainmenu Order" value="<?php echo $editorder;?>">
							</div>
						</div>
							
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Sub Menu Name</label>

							<div class="col-sm-6">
								<input type="text" name="mainmenu_name" id="mainmenu_name" class="form-control" placeholder="Mainmenu Name" value="<?php echo $editname;?>">
							</div>
						</div>
							
						<div class="form-group">
							<label for="inputPassword3" class="col-sm-2 control-label">Main Menu Url</label>

							<div class="col-sm-6">
								<input type="text" name="mainmenu_url" id="mainmenu_url" class="form-control" placeholder="Mainmenu URL" value="<?php echo $editurl;?>">
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Main Menu Icon </label>
									
							<div class="col-sm-6">
								<select name="menu_icon" id="menu_icon" class="form-control select2" vertical-align="top" style="width: 100%;" onChange="funchgico(this.value)">
									<option value="" >Select</option>
									<?php
									$query5 = "select * from falist order by faname";
									$exec5 = mysql_query($query5) or die ("Error in Query5".mysql_error());
										while ($res5 = mysql_fetch_array($exec5))
										{
											$res5anum = $res5["auto_number"];
											$faname = $res5["faname"];
									?>
								   <option value="<?=  $faname;  ?>" onFocus="funchgico(this.value)"><?= $faname; ?></option>
									<?php	 
										}
									?>
								</select>
							</div>
							<div class="col-sm-2" id="icon_div">
							</div>
						</div>
						<div class="form-group">
							<label for="inputPassword3" class="col-sm-2 control-label"> &nbsp;</label>
 						    <div class="col-sm-2">
							 <input type="hidden" name="editanum" id="editanum" class="form-control" value="<?php echo $editanum;?>">
								<input type="hidden" name="frmflag1" id="frmflag1" class="form-control" value="frmflag1">
								<input type="submit" name="submit" id="submit" class="btn btn-info " value="Save">
								<button type="reset" name="reset" id="reset" class="btn btn-default pull-right">Cancel</button>
							 
							</div>
						</div>
						
					</div>  <!-- /.box-body -->
					  
				</div>	 <!-- /.row -->
				
			</div><!-- /.box-body -->

		</form>  <!-- /.body form -->
			
		</div> <!-- /.box-info -->
		
		</div> <!-- /.col-md-6 -->
		</div> <!-- /.row -->
		
    </section>  <!-- /.section -->


<?php include ("includes/footer.php"); ?>