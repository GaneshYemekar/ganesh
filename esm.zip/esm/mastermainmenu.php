<?php
session_start();
//echo session_id();
include ("db/db_connect.php");
include ("includes/loginverify.php");
date_default_timezone_set('Asia/Calcutta');

$usercode = '';
$academicyear = '';
$academicyearfrom = '';
$academicyearto = '';
$srno = "";
$errmsg = "";
$bgcolorcode = "";
$colorloopcount = "";

$ipaddress = $_SERVER["REMOTE_ADDR"];
$updatedatetime = date('Y-m-d H:i:s');
$logintime = $_SESSION["logintime"];

$username = $_SESSION["username"];
$usercode = $_SESSION["usercode"];
$docno = $_SESSION["docno"];

$locationname = $_SESSION["locationname"];
$locationcode = $_SESSION["locationcode"];

$companyanum = $_SESSION["companyanum"];
$companyname = $_SESSION["companyname"];
$companycode = $_SESSION["companycode"];


if (isset($_REQUEST["frmflag1"])) { $frmflag1 = $_REQUEST["frmflag1"]; } else { $frmflag1 = ""; }
	if ($frmflag1 == 'frmflag1')
	{
		if (isset($_REQUEST["submit"])) { $submit = $_REQUEST["submit"]; } else { $submit = ""; }	
		if ($submit == 'Save')
		{		
			$menu_id = $_REQUEST["mainmenuid"];
			$mainmenuorder = $_REQUEST["mainmenuorder"];
			$menu_name = $_REQUEST['mainmenu_name'];
			$menu_url = $_REQUEST['mainmenu_url'];
			
			$Query = "insert into master_menumain(mainmenuid,mainmenuorder,mainmenutext,mainmenulink,username,ipaddress,entrydate,locationname,locationcode) 
			values ('".$menu_id."','".$mainmenuorder."','".$menu_name."', '".$menu_url."','$username','$ipaddress',now(),'$locationname','$locationcode')";
			
			$exec1 = mysql_query($Query) or die ("Error in Query".mysql_error());
			$errmsg = "Success. New Sub Menu Created";
			//exit;
			$bgcolorcode = 'success';
            if($exec1){
				header ("Location:mastermainmenu.php");
			}
			
	    } 
	}

	
	
	if (isset($_REQUEST["st"])) { $st = $_REQUEST["st"]; } else { $st = ""; }
	if ($st == 'del')
	{
		$delanum = $_REQUEST["anum"];
		$Query = "update master_menumain set status = 'deleted' where auto_number = '".$delanum."'";
		$exec3 = mysql_query($Query) or die ("Error in Query".mysql_error());
		if($exec3){
			header("location:mastermainmenu.php");
		}
		}
	if ($st == 'activate')
	{
		$delanum = $_REQUEST["anum"];
		$Query = "update master_menumain set status = '' where auto_number = '".$delanum."'";
		$exec3 = mysql_query($Query) or die ("Error in Query".mysql_error());
		if($exec3){
			header("location:mastermainmenu.php");
		}		
	}

	
	$paynowbillprefix = 'MM00';
	$paynowbillprefix1=strlen($paynowbillprefix);
	$query2 = "select * from master_menumain order by auto_number desc limit 0, 1";
	$exec2 = mysql_query($query2) or die ("Error in Query2".mysql_error());
	$res2 = mysql_fetch_array($exec2);
	$billnumber = $res2["mainmenuid"];
	$billdigit=strlen($billnumber);
	if ($billnumber == '')
	{
		$billnumbercode =$paynowbillprefix.'1';
	}
	else
	{
		$billnumber = $res2["mainmenuid"];
		$billnumbercode = substr($billnumber,$paynowbillprefix1, $billdigit);

		$billnumbercode = intval($billnumbercode);
		$billnumbercode = $billnumbercode + 1;
		$maxanum = $billnumbercode;
		$billnumbercode = $paynowbillprefix.$maxanum;
	  
	} 
?>
<?php include ("includes/header.php");  ?>
  <!-- DataTables -->
  <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
<!-- DataTables -->
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
  
<script language="javascript">
	function process1()
	{
		//alert ("Inside Funtion");
		if (document.form1.menu_id.value == "")
		{
			alert ("Please Select the Menu ID");
			document.form1.menu_id.focus();
			return false;
		}
		if (document.form1.submenu_name.value == "")
		{
			alert ("Please Enter Sub Menu Name");
			document.form1.submenu_name.focus();
			return false;
		}
		
		if (document.form1.submenu_url.value == "")
		{
			alert ("Please Enter Sub Menu URL");
			document.form1.submenu_url.focus();
			return false;
		}

	}

</script>

<script>
function funcDeletesurgery(submenuname){
	
	var confirm1=confirm("Are you sure want to delete ' "+submenuname+" ' Main menu?");
	if(confirm1 == false) 
	{ 
		return false; 
	}   
	
}	

function funcActivatesurgery(submenuname){
	
	var confirm2=confirm("Are you sure want to activate ' "+submenuname+" ' sub menu?");
	if(confirm2 == false) 
	{ 
		return false; 
	}   
	
}	
	
</script>

    <section class="content">
		<div class="row">
        <div class="col-md-12">
		<div class="box box-info">
			
			<div class="box-header with-border">
				<h3 class="box-title">Add New Sub-Menu</h3>

				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				<!--	<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button> -->
				</div>
			</div>
        <!-- /.box-header -->
		<!-- form start -->
		<form class="form-horizontal" name="form1" id="form1" method="post" action="mastermainmenu.php" onSubmit="return process1()" >		
			<div class="box-body">
				<div class="row">
					<div class="box-body">
					
													
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Main Menu ID </label>

							<div class="col-sm-6">
								<input type="text" name="mainmenuid" id="mainmenuid" class="form-control" value="<?php echo $billnumbercode;?>" readonly>
							</div>
						</div>
							
						<div class="form-group">
							<label for="inputPassword3" class="col-sm-2 control-label">Main Menu Order </label>

							<div class="col-sm-6">
								<input type="text" name="mainmenuorder" id="mainmenuorder" class="form-control" placeholder="Mainmenu Order">
							</div>
						</div>
							
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Sub Menu Name</label>

							<div class="col-sm-6">
								<input type="text" name="mainmenu_name" id="mainmenu_name" class="form-control" placeholder="Mainmenu Name">
							</div>
						</div>
							
						<div class="form-group">
							<label for="inputPassword3" class="col-sm-2 control-label"><!-- Main Menu Url --></label>

							<div class="col-sm-6">
								<input type="hidden" name="mainmenu_url" id="mainmenu_url" class="form-control" placeholder="Mainmenu URL" value="<?= 'menupage1.php?mainmenuid='.$billnumbercode; ?>" readonly>
							</div>
						</div>

						<div class="form-group">
							<label for="inputPassword3" class="col-sm-2 control-label"> &nbsp;</label>
 						    <div class="col-sm-2">
							 
								<input type="hidden" name="frmflag1" id="frmflag1" class="form-control" value="frmflag1">
								<input type="submit" name="submit" id="submit" class="btn btn-info " value="Save">
								<button type="reset" name="reset" id="reset" class="btn btn-default pull-right">Cancel</button>
							 
							</div>
						</div>
						
					</div>  <!-- /.box-body -->
					  
				</div>	 <!-- /.row -->
				
			</div><!-- /.box-body -->

		</form>  <!-- /.body form -->
			
		</div> <!-- /.box-info -->
		
		</div> <!-- /.col-md-6 -->
		</div> <!-- /.row -->
		
    </section>  <!-- /.section -->

    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> Master Main-Menu - Existing List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
					<th> Sr.No</th>
					<th>Mainmenu Name</th>
					<th>Main Order No</th>
					<th>Mainmenu Url</th>
					<th>Action</th>
                </tr>
                </thead>
                <tbody>
				<?php
				    $srno = 0;
					$Query = "select * from master_menumain where status <> 'deleted' order by auto_number ";
					$exec1 = mysql_query($Query) or die ("Error in Query".mysql_error());
					while ($res1 = mysql_fetch_array($exec1))
					{
						$srno = $srno + 1;
						
						$mainmenuid=$res1['mainmenuid'];
						$mainmenutext=$res1['mainmenutext'];
						$mainmenuorder=$res1['mainmenuorder'];
						
						$mainmenulink=$res1['mainmenulink'];
						$auto_number = $res1['auto_number'];
											
						$colorloopcount = $colorloopcount + 1;
				?>
		
                <tr>
					<td> <?php echo $srno; ?> </td>
					<td> <?php echo $mainmenutext; ?> </td>
					<td> <?php echo $mainmenuorder; ?> </td>
					<td> <?php echo $mainmenulink; ?> </td>
					<td>
						<a href="mastermainmenuedit1.php?st=edit&&anum=<?php echo $auto_number; ?>" >
							<div class="col-sm-3 btn btn-success btn-xs">Update</div>
						</a> <div class="col-sm-1 btn-xs"></div>
						<a href="mastermainmenu.php?st=del&&anum=<?php echo $auto_number; ?>" > 
							<div class="col-sm-3 btn btn-danger  btn-xs" onclick="return funcDeletesurgery('<?php echo $mainmenutext; ?>')" >Delete</div> 
						</a> 
					</td>
                </tr>
				<?php 
					}
				?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
	  
	        <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> Master Main-Menu- Deleted List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped">
                <thead>
                <tr>
					<th> Sr.No</th>
					<th>Mainmenu Name</th>
					<th>Main Order No</th>
					<th>Mainmenu Url</th>
					<th>Action</th>
                </tr>
                </thead>
                <tbody>
				<?php
				    $srno = 0;
					$Query = "select * from master_menumain where status = 'deleted' order by auto_number ";
					$exec1 = mysql_query($Query) or die ("Error in Query".mysql_error());
					while ($res1 = mysql_fetch_array($exec1))
					{
						$srno = $srno + 1;
						
						$mainmenuid=$res1['mainmenuid'];
						$mainmenuname=$res1['mainmenutext'];
						$mainmenuorder=$res1['mainmenuorder'];
						
						$mainmenulink=$res1['mainmenulink'];
						$auto_number = $res1['auto_number'];
											
						$colorloopcount = $colorloopcount + 1;
				?>
		
                <tr>
					<td> <?php echo $srno; ?> </td>
					<td> <?php echo $mainmenuname; ?> </td>
					<td> <?php echo $mainmenuorder; ?> </td>
					<td> <?php echo $mainmenulink; ?> </td>
					<td>
						<a href="mastermainmenu.php?st=activate&&anum=<?php echo $auto_number; ?>" > 
							<div class="col-sm-6 btn btn-success  btn-xs" onclick="return funcActivatesurgery('<?php echo $mainmenuname; ?>')" > Activate</div> 
						</a> 
					</td>
                </tr>
				<?php 
					}
				?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  

<?php include ("includes/footer.php"); ?>