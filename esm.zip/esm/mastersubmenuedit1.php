<?php
session_start();
//echo session_id();
include ("db/db_connect.php");
include ("includes/loginverify.php");
date_default_timezone_set('Asia/Calcutta');

$usercode = '';
$academicyear = '';
$academicyearfrom = '';
$academicyearto = '';
$srno = "";
$errmsg = "";
$bgcolorcode = "";
$colorloopcount = "";

$ipaddress = $_SERVER["REMOTE_ADDR"];
$updatedatetime = date('Y-m-d H:i:s');
$logintime = $_SESSION["logintime"];

$username = $_SESSION["username"];
$usercode = $_SESSION["usercode"];
$docno = $_SESSION["docno"];

$locationname = $_SESSION["locationname"];
$locationcode = $_SESSION["locationcode"];

$companyanum = $_SESSION["companyanum"];
$companyname = $_SESSION["companyname"];
$companycode = $_SESSION["companycode"];


if (isset($_REQUEST["frmflag1"])) { $frmflag1 = $_REQUEST["frmflag1"]; } else { $frmflag1 = ""; }
	if ($frmflag1 == 'frmflag1')
	{
		if (isset($_REQUEST["submit"])) { $submit = $_REQUEST["submit"]; } else { $submit = ""; }	
		if ($submit == 'Update')
		{		
			$menu_id = $_REQUEST["menu_id"];
			$submenuid = $_REQUEST["submenuid"];
			$submenuorder = $_REQUEST["submenuorder"];
			$submenutext = $_REQUEST['submenu_name'];
			$submenulink = $_REQUEST['submenu_url'];
			
			$editanum = $_REQUEST['editanum'];
			
			
			$Query = "update master_menusub set mainmenuid = '".$menu_id."', submenuid = '".$submenuid."', submenuorder = '".$submenuorder."',submenutext='$submenutext',submenulink='$submenulink', username = '$username', ipaddress = '$ipaddress', entrydate = now(), locationname = '$locationname', locationcode = '$locationcode' where auto_number = '$editanum'";
			
			$exec1 = mysql_query($Query) or die ("Error in Query".mysql_error());
			$errmsg = "Success. Main Menu Edited";
			//exit;
			$bgcolorcode = 'success';
            if($exec1){
				header ("Location:mastersubmenu.php");
			}
			
	    } 
	}

	
	
	if (isset($_REQUEST["st"])) { $st = $_REQUEST["st"]; } else { $st = ""; }
	if ($st == 'edit')
	{
	$postanum = $_REQUEST["anum"];
		$Query = "select * from master_menusub where auto_number = '".$postanum."'";
		$exec3 = mysql_query($Query) or die ("Error in Query".mysql_error());	
		$res3 = mysql_fetch_array($exec3);
		$editanum = $res3['auto_number'];
		$editsubmenuid = $res3['submenuid'];
		$editmainmenuid = $res3['mainmenuid'];
		$editsubmenuname = $res3['submenutext'];		
		$editurl = $res3['submenulink'];
		$editsubmenuorder = $res3['submenuorder'];
	}

	
?>
<?php include ("includes/header.php");  ?>
  
  
<script language="javascript">
	function process1()
	{
		//alert ("Inside Funtion");
		if (document.form1.menu_id.value == "")
		{
			alert ("Please Select the Menu ID");
			document.form1.menu_id.focus();
			return false;
		}
		if (document.form1.submenu_name.value == "")
		{
			alert ("Please Enter Sub Menu Name");
			document.form1.submenu_name.focus();
			return false;
		}
		
		if (document.form1.submenu_url.value == "")
		{
			alert ("Please Enter Sub Menu URL");
			document.form1.submenu_url.focus();
			return false;
		}

	}

</script>

    <section class="content">
		<div class="row">
        <div class="col-md-12">
		<div class="box box-info">
			
			<div class="box-header with-border">
				<h3 class="box-title">Edit Sub-Menu</h3>

				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				<!--	<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button> -->
				</div>
			</div>
        <!-- /.box-header -->
		<!-- form start -->
		<form class="form-horizontal" name="form1" id="form1" method="post" action="mastersubmenuedit1.php" onSubmit="return process1()" >		
			<div class="box-body">
				<div class="row">
					<div class="box-body">
					
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Main Menu ID </label>
									
							<div class="col-sm-6">
								<select name="menu_id" id="menu_id" class="form-control select2" vertical-align="top" style="width: 100%;" >
									<option value="" selected="selected">Select</option>
									<?php
									$query5 = "select * from master_menumain where status <> 'deleted' order by mainmenuid";
									$exec5 = mysql_query($query5) or die ("Error in Query5".mysql_error());
										while ($res5 = mysql_fetch_array($exec5))
										{
											$res5anum = $res5["auto_number"];
											$res5accountsmain = $res5["mainmenuid"];
											$res5mainmenutext = $res5["mainmenutext"];
											if($res5accountsmain == $editmainmenuid){
												$chk ="selected";
											}else{
												$chk ="";
											}
									?>
								   <option value="<?= $res5accountsmain; ?>" <?= $chk; ?>><?= $res5mainmenutext; ?></option>
									<?php	 
										}
									?>
								</select>
							</div>
						</div>	
							
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Sub Menu ID </label>

							<div class="col-sm-6">
								<input type="text" name="submenuid" id="submenuid" class="form-control" value="<?=$editsubmenuid;?>" readonly>
							</div>
						</div>
							
						<div class="form-group">
							<label for="inputPassword3" class="col-sm-2 control-label">Sub Menu Order </label>

							<div class="col-sm-6">
								<input type="text" name="submenuorder" id="submenuorder" class="form-control" placeholder="Submenu Order" value="<?= $editsubmenuorder;?>" >
							</div>
						</div>
							
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Sub Menu Name</label>

							<div class="col-sm-6">
								<input type="text" name="submenu_name" id="submenu_name" class="form-control" placeholder="Submenu Name" value="<?= $editsubmenuname;?>" >
							</div>
						</div>
							
						<div class="form-group">
							<label for="inputPassword3" class="col-sm-2 control-label">Sub Menu Url</label>

							<div class="col-sm-6">
								<input type="text" name="submenu_url" id="submenu_url" class="form-control" placeholder="Submenu URL" value="<?= $editurl;?>" >
							</div>
						</div>

						<div class="form-group">
							<label for="inputPassword3" class="col-sm-2 control-label"> &nbsp;</label>
 						    <div class="col-sm-2">
								<input type="hidden" name="editanum" id="editanum" class="form-control" value="<?= $editanum;?>">
								<input type="hidden" name="frmflag1" id="frmflag1" class="form-control" value="frmflag1">
								<input type="submit" name="submit" id="submit" class="btn btn-info " value="Update">
								<button type="reset" name="reset" id="reset" class="btn btn-default pull-right">Cancel</button>
							 
							</div>
						</div>
						
					</div>  <!-- /.box-body -->
					  
				</div>	 <!-- /.row -->
				
			</div><!-- /.box-body -->

		</form>  <!-- /.body form -->
			
		</div> <!-- /.box-info -->
		
		</div> <!-- /.col-md-6 -->
		</div> <!-- /.row -->
		
    </section>  <!-- /.section -->

<?php include ("includes/footer.php"); ?>