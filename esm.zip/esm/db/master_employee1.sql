-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2017 at 01:43 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;



-- --------------------------------------------------------

--
-- Table structure for table `master_employee`
--

CREATE TABLE `master_employee` (
  `auto_number` int(11) NOT NULL,
  `id` int(11) DEFAULT NULL,
  `employee_id` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `employee_name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `remember_token` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `register_date` date NOT NULL,
  `register_time` time NOT NULL,
  `role_id` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `designation` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `active_status` enum('0','1') COLLATE latin1_general_ci NOT NULL DEFAULT '1',
  `validity_date` date NOT NULL,
  `store_access` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `shift_access` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `doj` date NOT NULL,
  `employement_type` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `department` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `category` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `superisor` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `first_job_in_country` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `overtime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `is_user` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `prorata` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `prev_employer_name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `prev_employer_address` text COLLATE latin1_general_ci NOT NULL,
  `promotion_due_on` date NOT NULL,
  `increment_due_on` date NOT NULL,
  `free_travel_allowance` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `company_car` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `vehicle_no` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `leaving_date` date NOT NULL,
  `is_blacklisted` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `reason_leaving` text COLLATE latin1_general_ci NOT NULL,
  `last_job_kenya_expartriate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `emp_status_on_hold` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `date_holding_vehigle_no` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `record_status` enum('0','1') COLLATE latin1_general_ci NOT NULL DEFAULT '1',
  `user_id` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `ip_address` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `location_code` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `master_employee`
--
ALTER TABLE `master_employee`
  ADD PRIMARY KEY (`auto_number`),
  ADD UNIQUE KEY `auto_number` (`auto_number`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `master_employee`
--
ALTER TABLE `master_employee`
  MODIFY `auto_number` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
