-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2017 at 01:44 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esm_1`
--

-- --------------------------------------------------------

--
-- Table structure for table `details_login`
--

CREATE TABLE `details_login` (
  `auto_number` int(255) NOT NULL,
  `docno` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `logintime` datetime NOT NULL,
  `logouttime` datetime NOT NULL,
  `sessionid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdate` datetime NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdateipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdateusername` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `recorddate` date NOT NULL,
  `ipaddress` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(100) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `details_login`
--

INSERT INTO `details_login` (`auto_number`, `docno`, `username`, `logintime`, `logouttime`, `sessionid`, `lastupdate`, `locationname`, `locationcode`, `lastupdateipaddress`, `lastupdateusername`, `updatedatetime`, `recorddate`, `ipaddress`, `status`) VALUES
(1, '1', 'admin', '2017-12-14 11:06:41', '0000-00-00 00:00:00', 'm1f73she02or0apjbahsh0im45', '2017-12-14 11:06:41', 'Hyderabad', 'LTC-1', '::1', 'EMP00000001', '2017-12-14 15:36:41', '0000-00-00', '::1', 'Active'),
(2, '2', 'admin', '2017-12-14 11:09:34', '2017-12-14 12:20:41', 'akvmo8da1tv3s0a7q6gp624en6', '2017-12-14 11:09:34', 'Pune', 'LTC-2', '::1', 'EMP00000001', '2017-12-14 15:39:34', '0000-00-00', '::1', 'Deactive'),
(3, '3', 'admin', '2017-12-14 12:20:50', '0000-00-00 00:00:00', 'c4qa6ao53p2hg6ehscni0njuf0', '2017-12-14 12:20:50', 'Pune', 'LTC-2', '::1', 'EMP00000001', '2017-12-14 16:50:50', '0000-00-00', '::1', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `falist`
--

CREATE TABLE `falist` (
  `auto_number` int(11) NOT NULL,
  `faname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `falist`
--

INSERT INTO `falist` (`auto_number`, `faname`) VALUES
(1, 'fa-500px'),
(2, 'fa-address-book'),
(3, 'fa-address-book-o'),
(4, 'fa-address-card'),
(5, 'fa-address-card-o'),
(6, 'fa-adjust'),
(7, 'fa-adn'),
(8, 'fa-align-center'),
(9, 'fa-align-justify'),
(10, 'fa-align-left'),
(11, 'fa-align-right'),
(12, 'fa-amazon'),
(13, 'fa-ambulance'),
(14, 'fa-american-sign-language-interpreting'),
(15, 'fa-anchor'),
(16, 'fa-android'),
(17, 'fa-angellist'),
(18, 'fa-angle-double-down'),
(19, 'fa-angle-double-left'),
(20, 'fa-angle-double-right'),
(21, 'fa-angle-double-up'),
(22, 'fa-angle-down'),
(23, 'fa-angle-left'),
(24, 'fa-angle-right'),
(25, 'fa-angle-up'),
(26, 'fa-apple'),
(27, 'fa-archive'),
(28, 'fa-area-chart'),
(29, 'fa-arrow-circle-down'),
(30, 'fa-arrow-circle-left'),
(31, 'fa-arrow-circle-o-down'),
(32, 'fa-arrow-circle-o-left'),
(33, 'fa-arrow-circle-o-right'),
(34, 'fa-arrow-circle-o-up'),
(35, 'fa-arrow-circle-right'),
(36, 'fa-arrow-circle-up'),
(37, 'fa-arrow-down'),
(38, 'fa-arrow-left'),
(39, 'fa-arrow-right'),
(40, 'fa-arrow-up'),
(41, 'fa-arrows'),
(42, 'fa-arrows-alt'),
(43, 'fa-arrows-h'),
(44, 'fa-arrows-v'),
(45, 'fa-assistive-listening-systems'),
(46, 'fa-asterisk'),
(47, 'fa-at'),
(48, 'fa-audio-description'),
(49, 'fa-backward'),
(50, 'fa-balance-scale'),
(51, 'fa-ban'),
(52, 'fa-bandcamp'),
(53, 'fa-bar-chart'),
(54, 'fa-barcode'),
(55, 'fa-bars'),
(56, 'fa-bath'),
(57, 'fa-battery-empty'),
(58, 'fa-battery-full'),
(59, 'fa-battery-half'),
(60, 'fa-battery-quarter'),
(61, 'fa-battery-three-quarters'),
(62, 'fa-bed'),
(63, 'fa-beer'),
(64, 'fa-behance'),
(65, 'fa-behance-square'),
(66, 'fa-bell'),
(67, 'fa-bell-o'),
(68, 'fa-bell-slash'),
(69, 'fa-bell-slash-o'),
(70, 'fa-bicycle'),
(71, 'fa-binoculars'),
(72, 'fa-birthday-cake'),
(73, 'fa-bitbucket'),
(74, 'fa-bitbucket-square'),
(75, 'fa-black-tie'),
(76, 'fa-blind'),
(77, 'fa-bluetooth'),
(78, 'fa-bluetooth-b'),
(79, 'fa-bold'),
(80, 'fa-bolt'),
(81, 'fa-bomb'),
(82, 'fa-book'),
(83, 'fa-bookmark'),
(84, 'fa-bookmark-o'),
(85, 'fa-braille'),
(86, 'fa-briefcase'),
(87, 'fa-btc'),
(88, 'fa-bug'),
(89, 'fa-building'),
(90, 'fa-building-o'),
(91, 'fa-bullhorn'),
(92, 'fa-bullseye'),
(93, 'fa-bus'),
(94, 'fa-buysellads'),
(95, 'fa-calculator'),
(96, 'fa-calendar'),
(97, 'fa-calendar-check-o'),
(98, 'fa-calendar-minus-o'),
(99, 'fa-calendar-o'),
(100, 'fa-calendar-plus-o'),
(101, 'fa-calendar-times-o'),
(102, 'fa-camera'),
(103, 'fa-camera-retro'),
(104, 'fa-car'),
(105, 'fa-caret-down'),
(106, 'fa-caret-left'),
(107, 'fa-caret-right'),
(108, 'fa-caret-square-o-down'),
(109, 'fa-caret-square-o-left'),
(110, 'fa-caret-square-o-right'),
(111, 'fa-caret-square-o-up'),
(112, 'fa-caret-up'),
(113, 'fa-cart-arrow-down'),
(114, 'fa-cart-plus'),
(115, 'fa-cc'),
(116, 'fa-cc-amex'),
(117, 'fa-cc-diners-club'),
(118, 'fa-cc-discover'),
(119, 'fa-cc-jcb'),
(120, 'fa-cc-mastercard'),
(121, 'fa-cc-paypal'),
(122, 'fa-cc-stripe'),
(123, 'fa-cc-visa'),
(124, 'fa-certificate'),
(125, 'fa-chain-broken'),
(126, 'fa-check'),
(127, 'fa-check-circle'),
(128, 'fa-check-circle-o'),
(129, 'fa-check-square'),
(130, 'fa-check-square-o'),
(131, 'fa-chevron-circle-down'),
(132, 'fa-chevron-circle-left'),
(133, 'fa-chevron-circle-right'),
(134, 'fa-chevron-circle-up'),
(135, 'fa-chevron-down'),
(136, 'fa-chevron-left'),
(137, 'fa-chevron-right'),
(138, 'fa-chevron-up'),
(139, 'fa-child'),
(140, 'fa-chrome'),
(141, 'fa-circle'),
(142, 'fa-circle-o'),
(143, 'fa-circle-o-notch'),
(144, 'fa-circle-thin'),
(145, 'fa-clipboard'),
(146, 'fa-clock-o'),
(147, 'fa-clone'),
(148, 'fa-cloud'),
(149, 'fa-cloud-download'),
(150, 'fa-cloud-upload'),
(151, 'fa-code'),
(152, 'fa-code-fork'),
(153, 'fa-codepen'),
(154, 'fa-codiepie'),
(155, 'fa-coffee'),
(156, 'fa-cog'),
(157, 'fa-cogs'),
(158, 'fa-columns'),
(159, 'fa-comment'),
(160, 'fa-comment-o'),
(161, 'fa-commenting'),
(162, 'fa-commenting-o'),
(163, 'fa-comments'),
(164, 'fa-comments-o'),
(165, 'fa-compass'),
(166, 'fa-compress'),
(167, 'fa-connectdevelop'),
(168, 'fa-contao'),
(169, 'fa-copyright'),
(170, 'fa-creative-commons'),
(171, 'fa-credit-card'),
(172, 'fa-credit-card-alt'),
(173, 'fa-crop'),
(174, 'fa-crosshairs'),
(175, 'fa-css3'),
(176, 'fa-cube'),
(177, 'fa-cubes'),
(178, 'fa-cutlery'),
(179, 'fa-dashcube'),
(180, 'fa-database'),
(181, 'fa-deaf'),
(182, 'fa-delicious'),
(183, 'fa-desktop'),
(184, 'fa-deviantart'),
(185, 'fa-diamond'),
(186, 'fa-digg'),
(187, 'fa-dot-circle-o'),
(188, 'fa-download'),
(189, 'fa-dribbble'),
(190, 'fa-dropbox'),
(191, 'fa-drupal'),
(192, 'fa-edge'),
(193, 'fa-eercast'),
(194, 'fa-eject'),
(195, 'fa-ellipsis-h'),
(196, 'fa-ellipsis-v'),
(197, 'fa-empire'),
(198, 'fa-envelope'),
(199, 'fa-envelope-o'),
(200, 'fa-envelope-open'),
(201, 'fa-envelope-open-o'),
(202, 'fa-envelope-square'),
(203, 'fa-envira'),
(204, 'fa-eraser'),
(205, 'fa-etsy'),
(206, 'fa-eur'),
(207, 'fa-exchange'),
(208, 'fa-exclamation'),
(209, 'fa-exclamation-circle'),
(210, 'fa-exclamation-triangle'),
(211, 'fa-expand'),
(212, 'fa-expeditedssl'),
(213, 'fa-external-link'),
(214, 'fa-external-link-square'),
(215, 'fa-eye'),
(216, 'fa-eye-slash'),
(217, 'fa-eyedropper'),
(218, 'fa-facebook'),
(219, 'fa-facebook-official'),
(220, 'fa-facebook-square'),
(221, 'fa-fast-backward'),
(222, 'fa-fast-forward'),
(223, 'fa-fax'),
(224, 'fa-female'),
(225, 'fa-fighter-jet'),
(226, 'fa-file'),
(227, 'fa-file-archive-o'),
(228, 'fa-file-audio-o'),
(229, 'fa-file-code-o'),
(230, 'fa-file-excel-o'),
(231, 'fa-file-image-o'),
(232, 'fa-file-o'),
(233, 'fa-file-pdf-o'),
(234, 'fa-file-powerpoint-o'),
(235, 'fa-file-text'),
(236, 'fa-file-text-o'),
(237, 'fa-file-video-o'),
(238, 'fa-file-word-o'),
(239, 'fa-files-o'),
(240, 'fa-film'),
(241, 'fa-filter'),
(242, 'fa-fire'),
(243, 'fa-fire-extinguisher'),
(244, 'fa-firefox'),
(245, 'fa-first-order'),
(246, 'fa-flag'),
(247, 'fa-flag-checkered'),
(248, 'fa-flag-o'),
(249, 'fa-flask'),
(250, 'fa-flickr'),
(251, 'fa-floppy-o'),
(252, 'fa-folder'),
(253, 'fa-folder-o'),
(254, 'fa-folder-open'),
(255, 'fa-folder-open-o'),
(256, 'fa-font'),
(257, 'fa-font-awesome'),
(258, 'fa-fonticons'),
(259, 'fa-fort-awesome'),
(260, 'fa-forumbee'),
(261, 'fa-forward'),
(262, 'fa-foursquare'),
(263, 'fa-free-code-camp'),
(264, 'fa-frown-o'),
(265, 'fa-futbol-o'),
(266, 'fa-gamepad'),
(267, 'fa-gavel'),
(268, 'fa-gbp'),
(269, 'fa-genderless'),
(270, 'fa-get-pocket'),
(271, 'fa-gg'),
(272, 'fa-gg-circle'),
(273, 'fa-gift'),
(274, 'fa-git'),
(275, 'fa-git-square'),
(276, 'fa-github'),
(277, 'fa-github-alt'),
(278, 'fa-github-square'),
(279, 'fa-gitlab'),
(280, 'fa-glass'),
(281, 'fa-glide'),
(282, 'fa-glide-g'),
(283, 'fa-globe'),
(284, 'fa-google'),
(285, 'fa-google-plus'),
(286, 'fa-google-plus-official'),
(287, 'fa-google-plus-square'),
(288, 'fa-google-wallet'),
(289, 'fa-graduation-cap'),
(290, 'fa-gratipay'),
(291, 'fa-grav'),
(292, 'fa-h-square'),
(293, 'fa-hacker-news'),
(294, 'fa-hand-lizard-o'),
(295, 'fa-hand-o-down'),
(296, 'fa-hand-o-left'),
(297, 'fa-hand-o-right'),
(298, 'fa-hand-o-up'),
(299, 'fa-hand-paper-o'),
(300, 'fa-hand-peace-o'),
(301, 'fa-hand-pointer-o'),
(302, 'fa-hand-rock-o'),
(303, 'fa-hand-scissors-o'),
(304, 'fa-hand-spock-o'),
(305, 'fa-handshake-o'),
(306, 'fa-hashtag'),
(307, 'fa-hdd-o'),
(308, 'fa-header'),
(309, 'fa-headphones'),
(310, 'fa-heart'),
(311, 'fa-heart-o'),
(312, 'fa-heartbeat'),
(313, 'fa-history'),
(314, 'fa-home'),
(315, 'fa-hospital-o'),
(316, 'fa-hourglass'),
(317, 'fa-hourglass-end'),
(318, 'fa-hourglass-half'),
(319, 'fa-hourglass-o'),
(320, 'fa-hourglass-start'),
(321, 'fa-houzz'),
(322, 'fa-html5'),
(323, 'fa-i-cursor'),
(324, 'fa-id-badge'),
(325, 'fa-id-card'),
(326, 'fa-id-card-o'),
(327, 'fa-ils'),
(328, 'fa-imdb'),
(329, 'fa-inbox'),
(330, 'fa-indent'),
(331, 'fa-industry'),
(332, 'fa-info'),
(333, 'fa-info-circle'),
(334, 'fa-inr'),
(335, 'fa-instagram'),
(336, 'fa-internet-explorer'),
(337, 'fa-ioxhost'),
(338, 'fa-italic'),
(339, 'fa-joomla'),
(340, 'fa-jpy'),
(341, 'fa-jsfiddle'),
(342, 'fa-key'),
(343, 'fa-keyboard-o'),
(344, 'fa-krw'),
(345, 'fa-language'),
(346, 'fa-laptop'),
(347, 'fa-lastfm'),
(348, 'fa-lastfm-square'),
(349, 'fa-leaf'),
(350, 'fa-leanpub'),
(351, 'fa-lemon-o'),
(352, 'fa-level-down'),
(353, 'fa-level-up'),
(354, 'fa-life-ring'),
(355, 'fa-lightbulb-o'),
(356, 'fa-line-chart'),
(357, 'fa-link'),
(358, 'fa-linkedin'),
(359, 'fa-linkedin-square'),
(360, 'fa-linode'),
(361, 'fa-linux'),
(362, 'fa-list'),
(363, 'fa-list-alt'),
(364, 'fa-list-ol'),
(365, 'fa-list-ul'),
(366, 'fa-location-arrow'),
(367, 'fa-lock'),
(368, 'fa-long-arrow-down'),
(369, 'fa-long-arrow-left'),
(370, 'fa-long-arrow-right'),
(371, 'fa-long-arrow-up'),
(372, 'fa-low-vision'),
(373, 'fa-magic'),
(374, 'fa-magnet'),
(375, 'fa-male'),
(376, 'fa-map'),
(377, 'fa-map-marker'),
(378, 'fa-map-o'),
(379, 'fa-map-pin'),
(380, 'fa-map-signs'),
(381, 'fa-mars'),
(382, 'fa-mars-double'),
(383, 'fa-mars-stroke'),
(384, 'fa-mars-stroke-h'),
(385, 'fa-mars-stroke-v'),
(386, 'fa-maxcdn'),
(387, 'fa-meanpath'),
(388, 'fa-medium'),
(389, 'fa-medkit'),
(390, 'fa-meetup'),
(391, 'fa-meh-o'),
(392, 'fa-mercury'),
(393, 'fa-microchip'),
(394, 'fa-microphone'),
(395, 'fa-microphone-slash'),
(396, 'fa-minus'),
(397, 'fa-minus-circle'),
(398, 'fa-minus-square'),
(399, 'fa-minus-square-o'),
(400, 'fa-mixcloud'),
(401, 'fa-mobile'),
(402, 'fa-modx'),
(403, 'fa-money'),
(404, 'fa-moon-o'),
(405, 'fa-motorcycle'),
(406, 'fa-mouse-pointer'),
(407, 'fa-music'),
(408, 'fa-neuter'),
(409, 'fa-newspaper-o'),
(410, 'fa-object-group'),
(411, 'fa-object-ungroup'),
(412, 'fa-odnoklassniki'),
(413, 'fa-odnoklassniki-square'),
(414, 'fa-opencart'),
(415, 'fa-openid'),
(416, 'fa-opera'),
(417, 'fa-optin-monster'),
(418, 'fa-outdent'),
(419, 'fa-pagelines'),
(420, 'fa-paint-brush'),
(421, 'fa-paper-plane'),
(422, 'fa-paper-plane-o'),
(423, 'fa-paperclip'),
(424, 'fa-paragraph'),
(425, 'fa-pause'),
(426, 'fa-pause-circle'),
(427, 'fa-pause-circle-o'),
(428, 'fa-paw'),
(429, 'fa-paypal'),
(430, 'fa-pencil'),
(431, 'fa-pencil-square'),
(432, 'fa-pencil-square-o'),
(433, 'fa-percent'),
(434, 'fa-phone'),
(435, 'fa-phone-square'),
(436, 'fa-picture-o'),
(437, 'fa-pie-chart'),
(438, 'fa-pied-piper'),
(439, 'fa-pied-piper-alt'),
(440, 'fa-pied-piper-pp'),
(441, 'fa-pinterest'),
(442, 'fa-pinterest-p'),
(443, 'fa-pinterest-square'),
(444, 'fa-plane'),
(445, 'fa-play'),
(446, 'fa-play-circle'),
(447, 'fa-play-circle-o'),
(448, 'fa-plug'),
(449, 'fa-plus'),
(450, 'fa-plus-circle'),
(451, 'fa-plus-square'),
(452, 'fa-plus-square-o'),
(453, 'fa-podcast'),
(454, 'fa-power-off'),
(455, 'fa-print'),
(456, 'fa-product-hunt'),
(457, 'fa-puzzle-piece'),
(458, 'fa-qq'),
(459, 'fa-qrcode'),
(460, 'fa-question'),
(461, 'fa-question-circle'),
(462, 'fa-question-circle-o'),
(463, 'fa-quora'),
(464, 'fa-quote-left'),
(465, 'fa-quote-right'),
(466, 'fa-random'),
(467, 'fa-ravelry'),
(468, 'fa-rebel'),
(469, 'fa-recycle'),
(470, 'fa-reddit'),
(471, 'fa-reddit-alien'),
(472, 'fa-reddit-square'),
(473, 'fa-refresh'),
(474, 'fa-registered'),
(475, 'fa-renren'),
(476, 'fa-repeat'),
(477, 'fa-reply'),
(478, 'fa-reply-all'),
(479, 'fa-retweet'),
(480, 'fa-road'),
(481, 'fa-rocket'),
(482, 'fa-rss'),
(483, 'fa-rss-square'),
(484, 'fa-rub'),
(485, 'fa-safari'),
(486, 'fa-scissors'),
(487, 'fa-scribd'),
(488, 'fa-search'),
(489, 'fa-search-minus'),
(490, 'fa-search-plus'),
(491, 'fa-sellsy'),
(492, 'fa-server'),
(493, 'fa-share'),
(494, 'fa-share-alt'),
(495, 'fa-share-alt-square'),
(496, 'fa-share-square'),
(497, 'fa-share-square-o'),
(498, 'fa-shield'),
(499, 'fa-ship'),
(500, 'fa-shirtsinbulk'),
(501, 'fa-shopping-bag'),
(502, 'fa-shopping-basket'),
(503, 'fa-shopping-cart'),
(504, 'fa-shower'),
(505, 'fa-sign-in'),
(506, 'fa-sign-language'),
(507, 'fa-sign-out'),
(508, 'fa-signal'),
(509, 'fa-simplybuilt'),
(510, 'fa-sitemap'),
(511, 'fa-skyatlas'),
(512, 'fa-skype'),
(513, 'fa-slack'),
(514, 'fa-sliders'),
(515, 'fa-slideshare'),
(516, 'fa-smile-o'),
(517, 'fa-snapchat'),
(518, 'fa-snapchat-ghost'),
(519, 'fa-snapchat-square'),
(520, 'fa-snowflake-o'),
(521, 'fa-sort'),
(522, 'fa-sort-alpha-asc'),
(523, 'fa-sort-alpha-desc'),
(524, 'fa-sort-amount-asc'),
(525, 'fa-sort-amount-desc'),
(526, 'fa-sort-asc'),
(527, 'fa-sort-desc'),
(528, 'fa-sort-numeric-asc'),
(529, 'fa-sort-numeric-desc'),
(530, 'fa-soundcloud'),
(531, 'fa-space-shuttle'),
(532, 'fa-spinner'),
(533, 'fa-spoon'),
(534, 'fa-spotify'),
(535, 'fa-square'),
(536, 'fa-square-o'),
(537, 'fa-stack-exchange'),
(538, 'fa-stack-overflow'),
(539, 'fa-star'),
(540, 'fa-star-half'),
(541, 'fa-star-half-o'),
(542, 'fa-star-o'),
(543, 'fa-steam'),
(544, 'fa-steam-square'),
(545, 'fa-step-backward'),
(546, 'fa-step-forward'),
(547, 'fa-stethoscope'),
(548, 'fa-sticky-note'),
(549, 'fa-sticky-note-o'),
(550, 'fa-stop'),
(551, 'fa-stop-circle'),
(552, 'fa-stop-circle-o'),
(553, 'fa-street-view'),
(554, 'fa-strikethrough'),
(555, 'fa-stumbleupon'),
(556, 'fa-stumbleupon-circle'),
(557, 'fa-subscript'),
(558, 'fa-subway'),
(559, 'fa-suitcase'),
(560, 'fa-sun-o'),
(561, 'fa-superpowers'),
(562, 'fa-superscript'),
(563, 'fa-table'),
(564, 'fa-tablet'),
(565, 'fa-tachometer'),
(566, 'fa-tag'),
(567, 'fa-tags'),
(568, 'fa-tasks'),
(569, 'fa-taxi'),
(570, 'fa-telegram'),
(571, 'fa-television'),
(572, 'fa-tencent-weibo'),
(573, 'fa-terminal'),
(574, 'fa-text-height'),
(575, 'fa-text-width'),
(576, 'fa-th'),
(577, 'fa-th-large'),
(578, 'fa-th-list'),
(579, 'fa-themeisle'),
(580, 'fa-thermometer-empty'),
(581, 'fa-thermometer-full'),
(582, 'fa-thermometer-half'),
(583, 'fa-thermometer-quarter'),
(584, 'fa-thermometer-three-quarters'),
(585, 'fa-thumb-tack'),
(586, 'fa-thumbs-down'),
(587, 'fa-thumbs-o-down'),
(588, 'fa-thumbs-o-up'),
(589, 'fa-thumbs-up'),
(590, 'fa-ticket'),
(591, 'fa-times'),
(592, 'fa-times-circle'),
(593, 'fa-times-circle-o'),
(594, 'fa-tint'),
(595, 'fa-toggle-off'),
(596, 'fa-toggle-on'),
(597, 'fa-trademark'),
(598, 'fa-train'),
(599, 'fa-transgender'),
(600, 'fa-transgender-alt'),
(601, 'fa-trash'),
(602, 'fa-trash-o'),
(603, 'fa-tree'),
(604, 'fa-trello'),
(605, 'fa-tripadvisor'),
(606, 'fa-trophy'),
(607, 'fa-truck'),
(608, 'fa-try'),
(609, 'fa-tty'),
(610, 'fa-tumblr'),
(611, 'fa-tumblr-square'),
(612, 'fa-twitch'),
(613, 'fa-twitter'),
(614, 'fa-twitter-square'),
(615, 'fa-umbrella'),
(616, 'fa-underline'),
(617, 'fa-undo'),
(618, 'fa-universal-access'),
(619, 'fa-university'),
(620, 'fa-unlock'),
(621, 'fa-unlock-alt'),
(622, 'fa-upload'),
(623, 'fa-usb'),
(624, 'fa-usd'),
(625, 'fa-user'),
(626, 'fa-user-circle'),
(627, 'fa-user-circle-o'),
(628, 'fa-user-md'),
(629, 'fa-user-o'),
(630, 'fa-user-plus'),
(631, 'fa-user-secret'),
(632, 'fa-user-times'),
(633, 'fa-users'),
(634, 'fa-venus'),
(635, 'fa-venus-double'),
(636, 'fa-venus-mars'),
(637, 'fa-viacoin'),
(638, 'fa-viadeo'),
(639, 'fa-viadeo-square'),
(640, 'fa-video-camera'),
(641, 'fa-vimeo'),
(642, 'fa-vimeo-square'),
(643, 'fa-vine'),
(644, 'fa-vk'),
(645, 'fa-volume-control-phone'),
(646, 'fa-volume-down'),
(647, 'fa-volume-off'),
(648, 'fa-volume-up'),
(649, 'fa-weibo'),
(650, 'fa-weixin'),
(651, 'fa-whatsapp'),
(652, 'fa-wheelchair'),
(653, 'fa-wheelchair-alt'),
(654, 'fa-wifi'),
(655, 'fa-wikipedia-w'),
(656, 'fa-window-close'),
(657, 'fa-window-close-o'),
(658, 'fa-window-maximize'),
(659, 'fa-window-minimize'),
(660, 'fa-window-restore'),
(661, 'fa-windows'),
(662, 'fa-wordpress'),
(663, 'fa-wpbeginner'),
(664, 'fa-wpexplorer'),
(665, 'fa-wpforms'),
(666, 'fa-wrench'),
(667, 'fa-xing'),
(668, 'fa-xing-square'),
(669, 'fa-y-combinator'),
(670, 'fa-yahoo'),
(671, 'fa-yelp'),
(672, 'fa-yoast'),
(673, 'fa-youtube'),
(674, 'fa-youtube-play'),
(675, 'fa-youtube-square');

-- --------------------------------------------------------

--
-- Table structure for table `login_locationdetails`
--

CREATE TABLE `login_locationdetails` (
  `auto_number` int(255) NOT NULL,
  `docno` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `login_locationdetails`
--

INSERT INTO `login_locationdetails` (`auto_number`, `docno`, `username`, `locationname`, `locationcode`) VALUES
(1, '', 'EMP00000001', 'Hyderabad', 'LTC-1'),
(2, '', 'EMP00000001', 'Pune', 'LTC-2'),
(3, '', 'EMP00000001', 'Pune', 'LTC-2');

-- --------------------------------------------------------

--
-- Table structure for table `login_restriction`
--

CREATE TABLE `login_restriction` (
  `auto_number` int(255) NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `logintime` datetime NOT NULL,
  `logouttime` datetime NOT NULL,
  `sessionid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdate` datetime NOT NULL,
  `lastupdateipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdateusername` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `login_restriction`
--

INSERT INTO `login_restriction` (`auto_number`, `username`, `logintime`, `logouttime`, `sessionid`, `lastupdate`, `lastupdateipaddress`, `lastupdateusername`, `locationname`, `locationcode`) VALUES
(3, 'admin', '2017-12-14 12:20:50', '0000-00-00 00:00:00', 'c4qa6ao53p2hg6ehscni0njuf0', '2017-12-14 12:20:50', '::1', 'EMP00000001', 'Pune', 'LTC-2');

-- --------------------------------------------------------

--
-- Table structure for table `master_company`
--

CREATE TABLE `master_company` (
  `auto_number` int(13) NOT NULL,
  `companycode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `companyname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `address1` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `address2` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `area` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `city` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `state` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `country` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `pincode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `phonenumber1` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `phonenumber2` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `faxnumber1` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `faxnumber2` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `emailid1` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `emailid2` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `tinnumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `cstnumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `dateposted` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `companystatus` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `currencyname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `currencydecimalname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `currencycode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `pharefnoprefix` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `paynowbillnoprefix` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `paynowrefundprefix` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `showlogo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_company`
--

INSERT INTO `master_company` (`auto_number`, `companycode`, `companyname`, `address1`, `address2`, `area`, `city`, `state`, `country`, `pincode`, `phonenumber1`, `phonenumber2`, `faxnumber1`, `faxnumber2`, `emailid1`, `emailid2`, `tinnumber`, `cstnumber`, `dateposted`, `companystatus`, `currencyname`, `currencydecimalname`, `currencycode`, `pharefnoprefix`, `paynowbillnoprefix`, `paynowrefundprefix`, `showlogo`, `locationname`, `locationcode`) VALUES
(1, 'ESM0001', 'EXITE SCHOOL', 'Nampally', 'Abidas Road', ' Hyderabad M.C', 'Hyderabad', 'Telangana', 'Kenya', '500001', '', '', '', '', '', 'admin@exitesoftware.com', '', '', '2017-11-01 16:31:53', 'Active', 'Shillings', 'Cent', 'KSH', 'PR', 'OPC-', 'RE-', 'SHOW LOGO', 'HYD', 'LTC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_edition`
--

CREATE TABLE `master_edition` (
  `auto_number` int(255) NOT NULL,
  `productcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `edition` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `allowed` int(255) NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `users` int(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_edition`
--

INSERT INTO `master_edition` (`auto_number`, `productcode`, `edition`, `allowed`, `locationname`, `locationcode`, `status`, `updatedate`, `users`) VALUES
(3, '', 'FREE', 30, 'HYD', 'LTC-1', '', '2017-12-13 10:02:57', 200),
(4, '', 'PAID', 30000, 'HYD', 'LTC-1', 'ACTIVE', '2017-12-13 10:01:07', 10000);

-- --------------------------------------------------------

--
-- Table structure for table `master_employee`
--

CREATE TABLE `master_employee` (
  `auto_number` int(255) NOT NULL,
  `employeecode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `employeename` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `location` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `jobdescription` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdate` datetime NOT NULL,
  `lastupdateusername` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdateipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `reports_daterange_option` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `option_edit_delete` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `validitydate` date NOT NULL,
  `dateofjoining` date NOT NULL,
  `firstjob` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `overtime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `is_user` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `employmenttype` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `departmentanum` int(255) NOT NULL,
  `departmentname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `category` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `designation` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `supervisor` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_employee`
--

INSERT INTO `master_employee` (`auto_number`, `employeecode`, `employeename`, `username`, `password`, `location`, `jobdescription`, `status`, `lastupdate`, `lastupdateusername`, `lastupdateipaddress`, `reports_daterange_option`, `option_edit_delete`, `validitydate`, `dateofjoining`, `firstjob`, `overtime`, `is_user`, `employmenttype`, `departmentanum`, `departmentname`, `category`, `designation`, `supervisor`, `locationname`, `locationcode`) VALUES
(1, 'EMP00000001', 'ADMINISTRATOR', 'admin', 'YWRtaW4=', '', 'admin', 'Active', '2016-01-11 10:42:58', 'admin', '127.0.0.1', 'Show Date Range Option', 'Edit Delete Option Available', '2022-07-31', '2017-11-01', '', '', 'Yes', '', 0, '', '', '', '', 'HYD', 'LTC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_employeelocation`
--

CREATE TABLE `master_employeelocation` (
  `auto_number` int(255) NOT NULL,
  `employeecode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationanum` int(10) NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lastupdateipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdateusername` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_employeelocation`
--

INSERT INTO `master_employeelocation` (`auto_number`, `employeecode`, `username`, `locationanum`, `locationname`, `locationcode`, `lastupdate`, `lastupdateipaddress`, `lastupdateusername`) VALUES
(1, 'EMP00000001', 'admin', 1, 'Hyderabad', 'LTC-1', '2017-11-04 11:39:28', '::1', 'EMP00000001'),
(2, 'EMP00000001', 'admin', 2, 'Pune', 'LTC-2', '2017-12-13 10:21:12', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_employeerights`
--

CREATE TABLE `master_employeerights` (
  `auto_number` int(255) NOT NULL,
  `employeecode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `mainmenuid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `submenuid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lastupdateipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdateusername` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_employeerights`
--

INSERT INTO `master_employeerights` (`auto_number`, `employeecode`, `username`, `mainmenuid`, `submenuid`, `lastupdate`, `lastupdateipaddress`, `lastupdateusername`, `status`, `locationcode`, `locationname`) VALUES
(14, 'EMP00000001', 'admin', 'MM002', 'SM005', '2017-12-14 08:26:09', '::1', 'admin', '', 'LTC-1', 'HYD'),
(13, 'EMP00000001', 'admin', 'MM002', 'SM004', '2017-12-14 08:26:09', '::1', 'admin', '', 'LTC-1', 'HYD'),
(12, 'EMP00000001', 'admin', 'MM002', 'SM003', '2017-12-14 08:26:09', '::1', 'admin', '', 'LTC-1', 'HYD'),
(11, 'EMP00000001', 'admin', 'MM002', 'SM002', '2017-12-14 08:26:09', '::1', 'admin', '', 'LTC-1', 'HYD'),
(10, 'EMP00000001', 'admin', 'MM001', 'SM001', '2017-12-14 08:26:09', '::1', 'admin', '', 'LTC-1', 'HYD');

-- --------------------------------------------------------

--
-- Table structure for table `master_menumain`
--

CREATE TABLE `master_menumain` (
  `auto_number` int(255) NOT NULL,
  `mainmenuid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `mainmenuorder` decimal(13,2) NOT NULL,
  `mainmenutext` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `mainmenulink` text COLLATE latin1_general_ci NOT NULL,
  `menuiconclass` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `entrydate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_menumain`
--

INSERT INTO `master_menumain` (`auto_number`, `mainmenuid`, `mainmenuorder`, `mainmenutext`, `mainmenulink`, `menuiconclass`, `status`, `entrydate`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, 'MM001', '1.00', 'Home', 'mainmenu1.php?mainmenuid=MM001', 'fa-home', '', '2017-12-14 08:48:34', 'admin', '::1', 'HYD', 'LTC-1'),
(2, 'MM002', '2.00', 'Master', 'mainmenu1.php?mainmenuid=MM002', 'fa-cogs', '', '2017-12-14 08:37:43', 'admin', '::1', 'HYD', 'LTC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_menusub`
--

CREATE TABLE `master_menusub` (
  `auto_number` int(255) NOT NULL,
  `mainmenuid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `submenuid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `submenuorder` decimal(13,2) NOT NULL,
  `submenutext` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `submenulink` text COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `entrydate` date NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(100) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_menusub`
--

INSERT INTO `master_menusub` (`auto_number`, `mainmenuid`, `submenuid`, `submenuorder`, `submenutext`, `submenulink`, `status`, `updatedatetime`, `username`, `ipaddress`, `entrydate`, `locationname`, `locationcode`) VALUES
(1, 'MM001', 'SM001', '1.00', 'Dashboard', 'mainmenu1.php', '', '2017-12-14 08:46:40', 'admin', '::1', '2017-12-13', 'HYD', 'LTC-1'),
(2, 'MM002', 'SM002', '1.00', 'Main Menu', 'mastermainmenu.php', '', '2017-12-14 09:28:56', 'admin', '::1', '2017-12-14', 'HYD', 'LTC-1'),
(3, 'MM002', 'SM003', '2.00', 'Sub Menu', 'mastersubmenu.php', '', '2017-12-14 10:09:09', 'admin', '::1', '2017-12-14', 'Hyderabad', 'LTC-1'),
(4, 'MM002', 'SM004', '3.00', ' Usersrights', 'masteruserrights.php', '', '2017-12-14 10:09:50', 'admin', '::1', '2017-12-14', 'Pune', 'LTC-2'),
(5, 'MM002', 'SM005', '4.00', 'Registration', 'registration.php', '', '2017-12-14 04:49:07', 'admin', '::1', '2017-12-14', 'HYD', 'LTC-1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `details_login`
--
ALTER TABLE `details_login`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `falist`
--
ALTER TABLE `falist`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `login_locationdetails`
--
ALTER TABLE `login_locationdetails`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `login_restriction`
--
ALTER TABLE `login_restriction`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_company`
--
ALTER TABLE `master_company`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_edition`
--
ALTER TABLE `master_edition`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_employee`
--
ALTER TABLE `master_employee`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_employeelocation`
--
ALTER TABLE `master_employeelocation`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_employeerights`
--
ALTER TABLE `master_employeerights`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_menumain`
--
ALTER TABLE `master_menumain`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_menusub`
--
ALTER TABLE `master_menusub`
  ADD PRIMARY KEY (`auto_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `details_login`
--
ALTER TABLE `details_login`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `falist`
--
ALTER TABLE `falist`
  MODIFY `auto_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=676;
--
-- AUTO_INCREMENT for table `login_locationdetails`
--
ALTER TABLE `login_locationdetails`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `login_restriction`
--
ALTER TABLE `login_restriction`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `master_company`
--
ALTER TABLE `master_company`
  MODIFY `auto_number` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `master_edition`
--
ALTER TABLE `master_edition`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `master_employee`
--
ALTER TABLE `master_employee`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1103;
--
-- AUTO_INCREMENT for table `master_employeelocation`
--
ALTER TABLE `master_employeelocation`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `master_employeerights`
--
ALTER TABLE `master_employeerights`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `master_menumain`
--
ALTER TABLE `master_menumain`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `master_menusub`
--
ALTER TABLE `master_menusub`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
