-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2017 at 06:08 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mainschool`
--

-- --------------------------------------------------------

--
-- Table structure for table `activebatch`
--

CREATE TABLE `activebatch` (
  `auto_number` int(255) NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batch` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `activebatch`
--

INSERT INTO `activebatch` (`auto_number`, `course`, `batch`, `exam`, `status`, `ipaddress`, `updatedate`, `updatedby`) VALUES
(17, 'INFORMATION TECHNOLGOY', '2008', 'SEMESTER I', '', '192.168.1.15', '2009-05-24 13:33:41', 'admin'),
(18, 'INFORMATION TECHNOLGOY', '2008', 'SEMESTER II', '', '192.168.1.15', '2009-05-24 13:33:46', 'admin'),
(19, 'INFORMATION TECHNOLGOY', '2008', 'SEMESTER III', 'ACTIVE', '192.168.1.15', '2009-05-24 13:33:52', 'admin'),
(20, 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'ACTIVE', '192.168.1.15', '2009-05-24 13:34:01', 'admin'),
(21, 'COMPUTER SCIENCE', '2008', 'SEMESTER I', 'ACTIVE', '192.168.1.15', '2009-05-24 13:42:04', 'admin'),
(22, 'CIVIL ENGINEERING', '2014', 'SEMESTER I', 'ACTIVE', '27.6.148.72', '2014-07-29 16:51:25', 'admin'),
(23, 'COMPUTER SCIENCE', '2014', 'SEMESTER I', 'ACTIVE', '115.98.112.238', '2014-09-16 17:47:16', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `class_section`
--

CREATE TABLE `class_section` (
  `auto_number` int(30) NOT NULL,
  `class` varchar(225) NOT NULL,
  `classid` varchar(255) NOT NULL,
  `section` varchar(225) NOT NULL,
  `sectionid` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL,
  `updatedatetime` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_section`
--

INSERT INTO `class_section` (`auto_number`, `class`, `classid`, `section`, `sectionid`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, 'NURSERY', '1', 'A', '1', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(2, 'NURSERY', '1', 'B', '2', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(3, 'NURSERY', '1', 'C', '3', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(4, 'LKG', '2', 'A', '1', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(5, 'LKG', '2', 'B', '2', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(6, 'LKG', '2', 'C', '3', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(7, 'UKG', '3', 'A', '1', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(8, 'UKG', '3', 'B', '2', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(9, 'UKG', '3', 'C', '3', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(10, 'I', '4', 'A', '1', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(11, 'I', '4', 'B', '2', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(12, 'I', '4', 'C', '3', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(13, 'II', '5', 'A', '1', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(14, 'II', '5', 'B', '2', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(15, 'II', '5', 'C', '3', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(16, 'IV', '7', 'A', '1', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(17, 'IV', '7', 'B', '2', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(18, 'IV', '7', 'C', '3', '', '2017-10-26 ', '2017-10-26 10:06:26', 'admin', '::1', 'HYD', 'LOC-1'),
(19, 'V', '8', 'A', '1', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(20, 'V', '8', 'B', '2', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(21, 'V', '8', 'C', '3', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(22, 'V', '8', 'D', '4', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(23, 'V', '8', 'E', '5', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(24, 'VI', '9', 'A', '1', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(25, 'VI', '9', 'B', '2', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(26, 'VI', '9', 'C', '3', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(27, 'VI', '9', 'D', '4', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(28, 'VI', '9', 'E', '5', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(29, 'VII', '10', 'A', '1', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(30, 'VII', '10', 'B', '2', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(31, 'VII', '10', 'C', '3', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(32, 'VII', '10', 'D', '4', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(33, 'VII', '10', 'E', '5', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(34, 'VIII', '11', 'A', '1', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(35, 'VIII', '11', 'B', '2', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(36, 'VIII', '11', 'C', '3', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(37, 'VIII', '11', 'D', '4', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(38, 'VIII', '11', 'E', '5', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(39, 'IX', '12', 'A', '1', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(40, 'IX', '12', 'B', '2', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(41, 'IX', '12', 'C', '3', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(42, 'IX', '12', 'D', '4', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(43, 'IX', '12', 'E', '5', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(44, 'X', '13', 'A', '1', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(45, 'X', '13', 'B', '2', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(46, 'X', '13', 'C', '3', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(47, 'X', '13', 'D', '4', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(48, 'X', '13', 'E', '5', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(49, 'XI', '14', 'A', '1', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(50, 'XI', '14', 'B', '2', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(51, 'XI', '14', 'C', '3', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(52, 'XI', '14', 'D', '4', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(53, 'XI', '14', 'E', '5', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(54, 'XII', '15', 'A', '1', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(55, 'XII', '15', 'B', '2', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(56, 'XII', '15', 'C', '3', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(57, 'XII', '15', 'D', '4', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(58, 'XII', '15', 'E', '5', '', '2017-11-01 ', '2017-11-01 10:16:56', 'admin', '192.168.1.8', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `class_subject1`
--

CREATE TABLE `class_subject1` (
  `auto_number` int(10) NOT NULL,
  `classid` varchar(255) NOT NULL,
  `class` varchar(225) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `subjectid` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL,
  `username` varchar(225) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_subject1`
--

INSERT INTO `class_subject1` (`auto_number`, `classid`, `class`, `subject`, `subjectid`, `status`, `updatedatetime`, `recorddate`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, '1', 'NURSERY', 'TEL', '1', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(2, '1', 'NURSERY', 'ENG', '2', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(3, '1', 'NURSERY', 'HIN', '3', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(4, '2', 'LKG', 'TEL', '1', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(5, '2', 'LKG', 'ENG', '2', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(6, '2', 'LKG', 'HIN', '3', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(7, '3', 'UKG', 'TEL', '1', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(8, '3', 'UKG', 'ENG', '2', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(9, '3', 'UKG', 'HIN', '3', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(10, '4', 'I', 'TEL', '1', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(11, '4', 'I', 'ENG', '2', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(12, '4', 'I', 'HIN', '3', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(13, '5', 'II', 'TEL', '1', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(14, '5', 'II', 'ENG', '2', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(15, '5', 'II', 'HIN', '3', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(16, '6', 'III', 'TEL', '1', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(17, '6', 'III', 'ENG', '2', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(18, '6', 'III', 'HIN', '3', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(19, '7', 'IV', 'TEL', '1', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(20, '7', 'IV', 'ENG', '2', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(21, '7', 'IV', 'HIN', '3', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(22, '8', 'V', 'TEL', '1', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(23, '8', 'V', 'ENG', '2', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1'),
(24, '8', 'V', 'HIN', '3', '', '2017-10-27 11:38:35', '2017-10-27 ', 'admin', '::1', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `details_attendance`
--

CREATE TABLE `details_attendance` (
  `auto_number` int(255) NOT NULL,
  `masteranum` int(255) NOT NULL,
  `studentid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `attendance` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchyear` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchsection` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `daynumber` int(255) NOT NULL,
  `sessionnumber` int(255) NOT NULL,
  `attendancedate` date NOT NULL,
  `starttimehour` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `starttimeminute` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `endtimehour` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `endtimeminute` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `classname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `department` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subject` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `staffid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `staff` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `details_attendance`
--

INSERT INTO `details_attendance` (`auto_number`, `masteranum`, `studentid`, `studentname`, `attendance`, `course`, `batchyear`, `exam`, `batchsection`, `daynumber`, `sessionnumber`, `attendancedate`, `starttimehour`, `starttimeminute`, `endtimehour`, `endtimeminute`, `classname`, `department`, `subject`, `staffid`, `staff`, `updatedby`, `updatedate`, `ipaddress`) VALUES
(1, 14, 'STD4', 'Vijay', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 1, '2009-05-26', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF4', 'Sivanesan', 'admin', '2009-05-26 16:28:47', '192.168.1.15'),
(2, 14, 'STD6', 'vinoth', 'ABSENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 1, '2009-05-26', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF4', 'Sivanesan', 'admin', '2009-05-26 16:28:47', '192.168.1.15'),
(3, 15, 'STD8', 'Sowmiya', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 1, '2009-06-07', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF4', 'Sivanesan', 'admin', '2009-06-07 19:06:59', '192.168.1.15'),
(4, 15, 'STD4', 'Vijay', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 1, '2009-06-07', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF4', 'Sivanesan', 'admin', '2009-06-07 19:06:59', '192.168.1.15'),
(5, 15, 'STD6', 'vinoth', 'ABSENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 1, '2009-06-07', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF4', 'Sivanesan', 'admin', '2009-06-07 19:06:59', '192.168.1.15'),
(6, 16, 'STD8', 'Sowmiya', 'ABSENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 2, 1, '2009-06-07', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF3', 'Venkatesan', 'admin', '2009-06-07 19:07:32', '192.168.1.15'),
(7, 16, 'STD4', 'Vijay', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 2, 1, '2009-06-07', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF3', 'Venkatesan', 'admin', '2009-06-07 19:07:32', '192.168.1.15'),
(8, 16, 'STD6', 'vinoth', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 2, 1, '2009-06-07', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF3', 'Venkatesan', 'admin', '2009-06-07 19:07:32', '192.168.1.15'),
(9, 17, 'STD8', 'Sowmiya', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 1, '2009-06-05', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF4', 'Sivanesan', 'admin', '2009-06-09 15:24:10', '192.168.1.15'),
(10, 17, 'STD4', 'Vijay', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 1, '2009-06-05', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF4', 'Sivanesan', 'admin', '2009-06-09 15:24:10', '192.168.1.15'),
(11, 17, 'STD6', 'vinoth', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 1, '2009-06-05', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF4', 'Sivanesan', 'admin', '2009-06-09 15:24:10', '192.168.1.15'),
(12, 18, 'STD8', 'Sowmiya', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 2, 1, '2009-06-05', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF3', 'Venkatesan', 'admin', '2009-06-09 15:24:26', '192.168.1.15'),
(13, 18, 'STD4', 'Vijay', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 2, 1, '2009-06-05', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF3', 'Venkatesan', 'admin', '2009-06-09 15:24:26', '192.168.1.15'),
(14, 18, 'STD6', 'vinoth', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 2, 1, '2009-06-05', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF3', 'Venkatesan', 'admin', '2009-06-09 15:24:26', '192.168.1.15'),
(15, 19, 'STD8', 'Sowmiya', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 2, '2009-06-05', '02', '10', '02', '15', '', '', '', '', '', 'admin', '2009-06-09 15:25:25', '192.168.1.15'),
(16, 19, 'STD4', 'Vijay', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 2, '2009-06-05', '02', '10', '02', '15', '', '', '', '', '', 'admin', '2009-06-09 15:25:25', '192.168.1.15'),
(17, 19, 'STD6', 'vinoth', 'PRESENT', 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 2, '2009-06-05', '02', '10', '02', '15', '', '', '', '', '', 'admin', '2009-06-09 15:25:25', '192.168.1.15');

-- --------------------------------------------------------

--
-- Table structure for table `details_attendancestaff`
--

CREATE TABLE `details_attendancestaff` (
  `auto_number` int(255) NOT NULL,
  `masteranum` int(255) NOT NULL,
  `staffid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `staffname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `departmentanum` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `department` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `attendance` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `attendancedate` date NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `details_attendancestaff`
--

INSERT INTO `details_attendancestaff` (`auto_number`, `masteranum`, `staffid`, `staffname`, `departmentanum`, `department`, `attendance`, `attendancedate`, `updatedby`, `updatedate`, `ipaddress`) VALUES
(1, 1, 'admin', 'Administrator', '15', 'INFORMATION TECHNOLOGY ', 'PRESENT', '2009-05-27', 'admin', '2009-05-27 18:26:16', '192.168.1.15'),
(2, 1, 'STF4', 'Sivanesan', '15', 'INFORMATION TECHNOLOGY ', 'PRESENT', '2009-05-27', 'admin', '2009-05-27 18:26:16', '192.168.1.15'),
(3, 1, 'STF3', 'Venkatesan', '15', 'INFORMATION TECHNOLOGY ', 'PRESENT', '2009-05-27', 'admin', '2009-05-27 18:26:16', '192.168.1.15');

-- --------------------------------------------------------

--
-- Table structure for table `details_classtimetable`
--

CREATE TABLE `details_classtimetable` (
  `auto_number` int(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `totaldays` int(255) NOT NULL,
  `totalsessions` int(255) NOT NULL,
  `zeroperiod` varchar(255) NOT NULL,
  `weekdays` varchar(255) NOT NULL,
  `session0` text NOT NULL,
  `session1` text NOT NULL,
  `session2` text NOT NULL,
  `session3` text NOT NULL,
  `session4` text NOT NULL,
  `session5` text NOT NULL,
  `session6` text NOT NULL,
  `session7` text NOT NULL,
  `session8` text NOT NULL,
  `session9` text NOT NULL,
  `session10` text NOT NULL,
  `session11` text NOT NULL,
  `session12` text NOT NULL,
  `session13` text NOT NULL,
  `session14` text NOT NULL,
  `session15` text NOT NULL,
  `session16` text NOT NULL,
  `session17` text NOT NULL,
  `session18` text NOT NULL,
  `session19` text NOT NULL,
  `session20` text NOT NULL,
  `session21` text NOT NULL,
  `session22` text NOT NULL,
  `session23` text NOT NULL,
  `session24` text NOT NULL,
  `session25` text NOT NULL,
  `recordstatus` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedate` datetime NOT NULL,
  `username` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details_classtimetable`
--

INSERT INTO `details_classtimetable` (`auto_number`, `academicyear`, `class`, `totaldays`, `totalsessions`, `zeroperiod`, `weekdays`, `session0`, `session1`, `session2`, `session3`, `session4`, `session5`, `session6`, `session7`, `session8`, `session9`, `session10`, `session11`, `session12`, `session13`, `session14`, `session15`, `session16`, `session17`, `session18`, `session19`, `session20`, `session21`, `session22`, `session23`, `session24`, `session25`, `recordstatus`, `ipaddress`, `updatedate`, `username`) VALUES
(70, '2014', 'NURA', 5, 11, 'yes', 'FRI', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(69, '2014', 'NURA', 5, 11, 'yes', 'THU', '', 'MATHS ||Naveen^Nikitha^RAVI KUMAR ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(68, '2014', 'NURA', 5, 11, 'yes', 'WED', '', 'PHYSICS ||Sivanesan^Sreedevi^Vasudevan ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(67, '2014', 'NURA', 5, 11, 'yes', 'TUE', '', 'MATHS ||Naveen^Nikitha^RAVI KUMAR ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(66, '2014', 'NURA', 5, 11, 'yes', 'MON', '', 'ENGLISH ||Arundhati^Beena^Bharath ', 'ENGLISH ||Arundhati^Beena^Bharath ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(65, '2014', '1A', 5, 11, 'yes', 'FRI', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(64, '2014', '1A', 5, 11, 'yes', 'THU', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(63, '2014', '1A', 5, 11, 'yes', 'WED', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(55, '2014', 'LKGA', 5, 11, 'yes', 'FRI', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(54, '2014', 'LKGA', 5, 11, 'yes', 'THU', '', '', '', 'MATHS ||Naveen^Nikitha^RAVI KUMAR ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(52, '2014', 'LKGA', 5, 11, 'yes', 'TUE', '', '', '', 'MATHS ||Naveen^Nikitha^RAVI KUMAR ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(53, '2014', 'LKGA', 5, 11, 'yes', 'WED', '', '', '', 'MATHS ||Naveen^Nikitha^RAVI KUMAR ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(51, '2014', 'LKGA', 5, 11, 'yes', 'MON', '', '', '', 'MATHS ||Naveen^Nikitha^RAVI KUMAR ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(50, '2014', 'NURC', 5, 11, 'yes', 'FRI', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:37:47', 'admin'),
(49, '2014', 'NURC', 5, 11, 'yes', 'THU', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:37:47', 'admin'),
(48, '2014', 'NURC', 5, 11, 'yes', 'WED', '', '', ' ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:37:47', 'admin'),
(47, '2014', 'NURC', 5, 11, 'yes', 'TUE', '', '', 'PHYSICS ||Sivanesan^Sreedevi^Vasudevan ', 'PHYSICS ||Sivanesan^Sreedevi^Vasudevan ', 'PHYSICS ||Sivanesan^Sreedevi^Vasudevan ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:37:47', 'admin'),
(59, '2014', 'LKGB', 5, 11, 'yes', 'THU', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 13:50:25', 'admin'),
(58, '2014', 'LKGB', 5, 11, 'yes', 'WED', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 13:50:25', 'admin'),
(46, '2014', 'NURC', 5, 11, 'yes', 'MON', '', 'MATHS ||Naveen^Nikitha^RAVI KUMAR ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:37:47', 'admin'),
(62, '2014', '1A', 5, 11, 'yes', 'TUE', '', '', '', '', 'PHYSICS ||Beena^Bharath ', 'PHYSICS ||Beena^Bharath ', 'SCIENCE ||Arundhati^Beena^Bharath^Deborah^Florance^Krishnan^Ritu^Saberi^Venkatesan ', 'SCIENCE ||Arundhati^Beena^Bharath^Deborah^Florance^Krishnan^Ritu^Saberi^Venkatesan ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(60, '2014', 'LKGB', 5, 11, 'yes', 'FRI', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 13:50:25', 'admin'),
(61, '2014', '1A', 5, 11, 'yes', 'MON', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(57, '2014', 'LKGB', 5, 11, 'yes', 'TUE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 13:50:25', 'admin'),
(56, '2014', 'LKGB', 5, 11, 'yes', 'MON', '', 'ENGLISH ||Venkatesan ', 'ENGLISH ||Venkatesan ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 13:50:25', 'admin'),
(36, '2014', 'NURA', 5, 11, 'yes', 'MON', '', 'ENGLISH ||Arundhati^Beena^Bharath ', 'ENGLISH ||Arundhati^Beena^Bharath ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(37, '2014', 'NURA', 5, 11, 'yes', 'TUE', '', 'MATHS ||Naveen^Nikitha^RAVI KUMAR ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(38, '2014', 'NURA', 5, 11, 'yes', 'WED', '', 'PHYSICS ||Sivanesan^Sreedevi^Vasudevan ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(39, '2014', 'NURA', 5, 11, 'yes', 'THU', '', 'MATHS ||Naveen^Nikitha^RAVI KUMAR ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(40, '2014', 'NURA', 5, 11, 'yes', 'FRI', '', 'MATHS ||Naveen^Nikitha^RAVI KUMAR ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(41, '2014', 'NURB', 5, 11, 'yes', 'MON', '', '', 'MATHS ||Naveen^Nikitha^RAVI KUMAR ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin'),
(42, '2014', 'NURB', 5, 11, 'yes', 'TUE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin'),
(43, '2014', 'NURB', 5, 11, 'yes', 'WED', '', '', 'PHYSICS ||Sivanesan^Sreedevi^Vasudevan ', 'PHYSICS ||Sivanesan^Sreedevi^Vasudevan ', 'PHYSICS ||Sivanesan^Sreedevi^Vasudevan ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin'),
(44, '2014', 'NURB', 5, 11, 'yes', 'THU', '', '', 'ENGLISH ||Arundhati^Beena^Bharath ', 'ENGLISH ||Arundhati^Beena^Bharath ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin'),
(45, '2014', 'NURB', 5, 11, 'yes', 'FRI', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `details_feepayment`
--

CREATE TABLE `details_feepayment` (
  `auto_number` int(255) NOT NULL,
  `receiptautonumber` int(255) NOT NULL,
  `receiptnumber` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `applicationnumber` varchar(255) NOT NULL,
  `admissionnumber` varchar(255) NOT NULL,
  `feeupto` date NOT NULL,
  `subtotal` decimal(13,2) NOT NULL,
  `feehead` varchar(255) NOT NULL,
  `discountpercent` decimal(13,2) NOT NULL,
  `discountrupees` decimal(13,2) NOT NULL,
  `totalamount` decimal(13,2) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `recordstatus` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details_feepayment`
--

INSERT INTO `details_feepayment` (`auto_number`, `receiptautonumber`, `receiptnumber`, `receiptdate`, `applicationnumber`, `admissionnumber`, `feeupto`, `subtotal`, `feehead`, `discountpercent`, `discountrupees`, `totalamount`, `academicyear`, `recordstatus`, `ipaddress`, `username`, `updatedatetime`) VALUES
(1, 5, 'FEE/2014-15/1003', '2014-10-10', 'APP/2014-15/1003 ', '', '2014-10-10', '4300.00', 'BUILDING FUND', '0.00', '0.00', '1000.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 13:47:57'),
(2, 5, 'FEE/2014-15/1003', '2014-10-10', 'APP/2014-15/1003 ', '', '2014-10-10', '4300.00', 'ADMISSION FEE', '0.00', '0.00', '1500.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 13:47:57'),
(3, 5, 'FEE/2014-15/1003', '2014-10-10', 'APP/2014-15/1003 ', '', '2014-10-10', '4300.00', 'BOOK FEE', '0.00', '0.00', '1800.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 13:47:57'),
(4, 6, 'FEE/2014-15/1004', '2014-10-10', 'APP/2014-15/1002 ', '', '2014-10-10', '1000.00', 'BUILDING FUND', '0.00', '0.00', '1000.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 14:55:25'),
(5, 7, 'FEE/2014-15/1005', '2014-10-10', 'APP/2014-15/1002 ', '', '2014-10-10', '1000.00', 'BUILDING FUND', '0.00', '0.00', '1000.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 14:59:55'),
(6, 8, 'FEE/2014-15/1006', '2014-10-10', 'APP/2014-15/1003 ', '', '2014-10-10', '4300.00', 'BUILDING FUND', '0.00', '0.00', '1000.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:00:15'),
(7, 8, 'FEE/2014-15/1006', '2014-10-10', 'APP/2014-15/1003 ', '', '2014-10-10', '4300.00', 'ADMISSION FEE', '0.00', '0.00', '1500.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:00:15'),
(8, 8, 'FEE/2014-15/1006', '2014-10-10', 'APP/2014-15/1003 ', '', '2014-10-10', '4300.00', 'BOOK FEE', '0.00', '0.00', '1800.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:00:15'),
(9, 9, 'FEE/2014-15/1007', '2014-10-10', 'APP/2014-15/1002 ', '', '2014-10-10', '1000.00', 'BUILDING FUND', '0.00', '0.00', '1000.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:01:01'),
(10, 10, 'FEE/2014-15/1008', '2014-10-10', 'APP/2014-15/1002 ', '', '2014-10-10', '1000.00', 'BUILDING FUND', '0.00', '0.00', '1000.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:01:51'),
(11, 11, 'FEE/2014-15/1009', '2014-10-10', '', '', '2014-10-10', '0.00', '', '0.00', '0.00', '0.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:02:30'),
(12, 11, 'FEE/2014-15/1009', '2014-10-10', '', '', '2014-10-10', '0.00', '', '0.00', '0.00', '0.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:02:30'),
(13, 11, 'FEE/2014-15/1009', '2014-10-10', '', '', '2014-10-10', '0.00', '', '0.00', '0.00', '0.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:02:30'),
(14, 11, 'FEE/2014-15/1009', '2014-10-10', '', '', '2014-10-10', '0.00', '', '0.00', '0.00', '0.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:02:30'),
(15, 11, 'FEE/2014-15/1009', '2014-10-10', '', '', '2014-10-10', '0.00', '', '0.00', '0.00', '0.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:02:30'),
(16, 11, 'FEE/2014-15/1009', '2014-10-10', '', '', '2014-10-10', '0.00', '', '0.00', '0.00', '0.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:02:30'),
(17, 11, 'FEE/2014-15/1009', '2014-10-10', '', '', '2014-10-10', '0.00', '', '0.00', '0.00', '0.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:02:30'),
(18, 11, 'FEE/2014-15/1009', '2014-10-10', '', '', '2014-10-10', '0.00', '', '0.00', '0.00', '0.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:02:30'),
(19, 11, 'FEE/2014-15/1009', '2014-10-10', '', '', '2014-10-10', '0.00', '', '0.00', '0.00', '0.00', '2014', '', '127.0.0.1', 'admin', '2014-10-10 15:02:30'),
(20, 12, 'FEE/2014-15/1010', '2014-10-12', 'APP/2014-15/1007 ', '', '2014-10-12', '3500.00', 'BUILDING FUND', '0.00', '0.00', '1000.00', '2014-15', '', '127.0.0.1', 'admin', '2014-10-12 12:07:35'),
(21, 12, 'FEE/2014-15/1010', '2014-10-12', 'APP/2014-15/1007 ', '', '2014-10-12', '3500.00', 'UNIFORM FEE', '0.00', '0.00', '2500.00', '2014-15', '', '127.0.0.1', 'admin', '2014-10-12 12:07:35'),
(22, 15, 'FEE/2014-15/1013', '2014-10-31', '', '', '2014-10-31', '3500.00', 'BUILDING FUND', '0.00', '0.00', '2000.00', '2014-15', '', '192.168.1.14', 'admin', '2014-10-31 18:59:32'),
(23, 15, 'FEE/2014-15/1013', '2014-10-31', '', '', '2014-10-31', '3500.00', 'ADMISSION FEE', '0.00', '0.00', '500.00', '2014-15', '', '192.168.1.14', 'admin', '2014-10-31 18:59:32'),
(24, 15, 'FEE/2014-15/1013', '2014-10-31', '', '', '2014-10-31', '3500.00', 'BOOK FEE', '0.00', '0.00', '1000.00', '2014-15', '', '192.168.1.14', 'admin', '2014-10-31 18:59:32'),
(25, 1, 'FEE/2017-18/1000', '2017-10-21', '', '', '2017-10-21', '21000.00', 'TUTION FEE', '0.00', '0.00', '2000.00', '2005-01', '', '192.168.1.6', 'admin', '2017-10-21 16:29:49'),
(26, 1, 'FEE/2017-18/1000', '2017-10-21', '', '', '2017-10-21', '21000.00', 'UNIFORM FEE', '0.00', '0.00', '1500.00', '2005-01', '', '192.168.1.6', 'admin', '2017-10-21 16:29:49'),
(27, 1, 'FEE/2017-18/1000', '2017-10-21', '', '', '2017-10-21', '21000.00', 'BOOK FEES', '0.00', '0.00', '5000.00', '2005-01', '', '192.168.1.6', 'admin', '2017-10-21 16:29:49');

-- --------------------------------------------------------

--
-- Table structure for table `details_interview`
--

CREATE TABLE `details_interview` (
  `auto_number` int(255) NOT NULL,
  `interviewdate` date NOT NULL,
  `applicationnumber` varchar(255) NOT NULL,
  `studentname` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `fathername` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `questionanum1` int(255) NOT NULL,
  `answer1` varchar(255) NOT NULL,
  `questionanum2` int(255) NOT NULL,
  `answer2` varchar(255) NOT NULL,
  `questionanum3` int(255) NOT NULL,
  `answer3` varchar(255) NOT NULL,
  `questionanum4` int(255) NOT NULL,
  `answer4` varchar(255) NOT NULL,
  `questionanum5` int(255) NOT NULL,
  `answer5` varchar(255) NOT NULL,
  `questionanum6` int(255) NOT NULL,
  `answer6` varchar(255) NOT NULL,
  `questionanum7` int(255) NOT NULL,
  `answer7` varchar(255) NOT NULL,
  `questionanum8` int(255) NOT NULL,
  `answer8` varchar(255) NOT NULL,
  `questionanum9` int(255) NOT NULL,
  `answer9` varchar(255) NOT NULL,
  `questionanum10` int(255) NOT NULL,
  `answer10` varchar(255) NOT NULL,
  `questionanum11` int(255) NOT NULL,
  `answer11` varchar(255) NOT NULL,
  `questionanum12` int(255) NOT NULL,
  `answer12` varchar(255) NOT NULL,
  `questionanum13` int(255) NOT NULL,
  `answer13` varchar(255) NOT NULL,
  `questionanum14` int(255) NOT NULL,
  `answer14` varchar(255) NOT NULL,
  `questionanum15` int(255) NOT NULL,
  `answer15` varchar(255) NOT NULL,
  `questionanum16` int(255) NOT NULL,
  `answer16` varchar(255) NOT NULL,
  `questionanum17` int(255) NOT NULL,
  `answer17` varchar(255) NOT NULL,
  `questionanum18` int(255) NOT NULL,
  `answer18` varchar(255) NOT NULL,
  `questionanum19` int(255) NOT NULL,
  `answer19` varchar(255) NOT NULL,
  `questionanum20` int(255) NOT NULL,
  `answer20` varchar(255) NOT NULL,
  `questionanum21` int(255) NOT NULL,
  `answer21` varchar(255) NOT NULL,
  `questionanum22` int(255) NOT NULL,
  `answer22` varchar(255) NOT NULL,
  `questionanum23` int(255) NOT NULL,
  `answer23` varchar(255) NOT NULL,
  `questionanum24` int(255) NOT NULL,
  `answer24` varchar(255) NOT NULL,
  `questionanum25` int(255) NOT NULL,
  `answer25` varchar(255) NOT NULL,
  `applicationstatus` varchar(255) NOT NULL,
  `amountpaydate` date NOT NULL,
  `recordstatus` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details_interview`
--

INSERT INTO `details_interview` (`auto_number`, `interviewdate`, `applicationnumber`, `studentname`, `class`, `fathername`, `category`, `questionanum1`, `answer1`, `questionanum2`, `answer2`, `questionanum3`, `answer3`, `questionanum4`, `answer4`, `questionanum5`, `answer5`, `questionanum6`, `answer6`, `questionanum7`, `answer7`, `questionanum8`, `answer8`, `questionanum9`, `answer9`, `questionanum10`, `answer10`, `questionanum11`, `answer11`, `questionanum12`, `answer12`, `questionanum13`, `answer13`, `questionanum14`, `answer14`, `questionanum15`, `answer15`, `questionanum16`, `answer16`, `questionanum17`, `answer17`, `questionanum18`, `answer18`, `questionanum19`, `answer19`, `questionanum20`, `answer20`, `questionanum21`, `answer21`, `questionanum22`, `answer22`, `questionanum23`, `answer23`, `questionanum24`, `answer24`, `questionanum25`, `answer25`, `applicationstatus`, `amountpaydate`, `recordstatus`, `ipaddress`, `username`, `updatedatetime`) VALUES
(1, '2014-10-04', 'APP/2014-15/1002 ', 'Vasudevan', 'nursery', 'Krishnasamy', 'Dayscholar', 1, 'Nice person', 2, 'watching TV', 3, 'maths', 4, 'social', 12, 'no', 13, '', 14, 'no', 15, 'yes', 16, 'Bharath, 10th', 17, 'cricket', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-08', '', '127.0.0.1', 'admin', '2014-10-05 10:51:18'),
(2, '2014-10-03', 'APP/2014-15/1004 ', 'Vasudevan', 'nursery', 'Krishnasamy', 'Dayscholar', 1, '', 2, '', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'waitlisted', '0000-00-00', '', '127.0.0.1', 'admin', '2014-10-05 11:20:11'),
(3, '2014-10-05', 'APP/2014-15/1003 ', 'Bharath', '3', 'Krishnasamy', 'Dayscholar', 1, '', 2, '', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'rejected', '0000-00-00', '', '127.0.0.1', 'admin', '2014-10-05 11:21:38'),
(4, '2014-10-05', 'APP/2014-15/1003 ', 'Bharath', '3', 'Krishnasamy', 'Dayscholar', 1, '', 2, '', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-10', '', '127.0.0.1', 'admin', '2014-10-05 11:27:45'),
(5, '2014-10-03', 'APP/2014-15/1004 ', 'Vasudevan', 'nursery', 'Krishnasamy', 'Dayscholar', 1, '', 2, '', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'waitlisted', '0000-00-00', '', '127.0.0.1', 'admin', '2014-10-05 11:28:01'),
(6, '2014-10-05', 'APP/2014-15/1003 ', 'Bharath', '3', 'Krishnasamy', 'Dayscholar', 1, '', 2, '', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-09', '', '127.0.0.1', 'admin', '2014-10-05 11:36:38'),
(7, '2014-10-04', 'APP/2014-15/1002 ', 'Vasudevan', 'nursery', 'Krishnasamy', 'Dayscholar', 1, 'gdfgdsf', 2, 'gdfg', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'rejected', '0000-00-00', '', '127.0.0.1', 'admin', '2014-10-06 09:43:29'),
(8, '0000-00-00', 'APP/2014-15/1006 ', 'Arun', '3', 'Krishnan', 'Dayscholar', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'waitlisted', '0000-00-00', '', '127.0.0.1', 'admin', '0000-00-00 00:00:00'),
(10, '0000-00-00', 'APP/2014-15/1002 ', 'Vasudevan', 'nursery', 'Krishnasamy', 'Dayscholar', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-13', '', '127.0.0.1', 'admin', '2014-10-08 11:38:07'),
(11, '0000-00-00', 'APP/2014-15/1003 ', 'Bharath', '3', 'Krishnasamy', 'Dayscholar', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'waitlisted', '0000-00-00', '', '127.0.0.1', 'admin', '2014-10-08 11:45:59'),
(12, '2014-10-03', 'APP/2014-15/1004 ', 'Vasudevan', '', 'Krishnasamy', 'Dayscholar', 1, '', 2, '', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'rejected', '0000-00-00', '', '127.0.0.1', 'admin', '2014-10-08 11:47:01'),
(13, '0000-00-00', 'APP/2014-15/1004 ', 'Vasudevan', 'nursery', 'Krishnasamy', 'Residential', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'waitlisted', '0000-00-00', '', '127.0.0.1', 'admin', '2014-10-08 11:50:25'),
(14, '0000-00-00', 'APP/2014-15/1003 ', 'Bharath', '3', 'Krishnasamy', 'Dayscholar', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-10', '', '127.0.0.1', 'admin', '2014-10-08 12:53:01'),
(15, '2014-10-05', 'APP/2014-15/1003 ', 'Bharath', 'LKG', 'Krishnasamy', 'Dayscholar', 1, '', 2, '', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-10', '', '127.0.0.1', 'admin', '2014-10-08 12:59:05'),
(16, '2014-10-05', 'APP/2014-15/1003 ', 'Bharath', 'LKG', 'Krishnasamy', 'Residential', 1, '', 2, '', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-20', '', '127.0.0.1', 'admin', '2014-10-08 12:59:25'),
(17, '2014-10-05', 'APP/2014-15/1003 ', 'Bharath', 'LKG', 'Krishnasamy', 'Dayscholar', 1, '', 2, '', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'waitlisted', '0000-00-00', '', '127.0.0.1', 'admin', '2014-10-08 12:59:42'),
(18, '0000-00-00', 'APP/2014-15/1002 ', 'Vasudevan', 'LKG', 'Krishnasamy', 'Dayscholar', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-10', '', '127.0.0.1', 'admin', '2014-10-08 13:08:45'),
(19, '0000-00-00', 'APP/2014-15/1002 ', 'Vasudevan', 'LKG', 'Krishnasamy', 'Dayscholar', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-10', '', '127.0.0.1', 'admin', '2014-10-08 13:09:21'),
(20, '0000-00-00', 'APP/2014-15/1002 ', 'Vasudevan', 'LKG', 'Krishnasamy', 'Residential', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-10', '', '127.0.0.1', 'admin', '2014-10-08 13:09:46'),
(21, '2014-10-04', 'APP/2014-15/1002 ', 'Vasudevan', 'LKG', 'Krishnasamy', 'Dayscholar', 1, '', 2, '', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'waitlisted', '0000-00-00', '', '127.0.0.1', 'admin', '2014-10-08 13:12:36'),
(22, '2014-10-04', 'APP/2014-15/1002 ', 'Vasudevan', 'LKG', 'Krishnasamy', 'Dayscholar', 1, '', 2, '', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-17', '', '127.0.0.1', 'admin', '2014-10-08 13:12:55'),
(23, '0000-00-00', 'APP/2014-15/1002 ', 'Vasudevan', 'LKG', 'Krishnasamy', 'Dayscholar', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-10', '', '127.0.0.1', 'admin', '2014-10-08 18:29:22'),
(24, '0000-00-00', 'APP/2014-15/1003 ', 'Bharath', 'LKG', 'Krishnasamy', 'Dayscholar', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-20', '', '127.0.0.1', 'admin', '2014-10-09 10:58:56'),
(25, '0000-00-00', 'APP/2014-15/1007 ', 'Venkat', '5', 'Rajan', 'Dayscholar', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-15', '', '127.0.0.1', 'admin', '2014-10-12 10:19:17'),
(26, '0000-00-00', '', 'Giri', '2', '', 'Residential', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', '', '0000-00-00', '', '127.0.0.1', 'admin', '2014-10-17 13:17:45'),
(27, '0000-00-00', 'APP/2014-15/1002 ', 'Vasudevan', 'Nursery', 'Krishnasamy', 'Dayscholar', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-21', '', '192.168.1.14', 'admin', '2014-10-20 10:59:40'),
(28, '0000-00-00', 'APP/2014-15/1009 ', 'Prem Kumar', '11', 'Ram', 'Residential', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-27', '', '192.168.1.14', 'admin', '2014-10-25 15:19:40'),
(29, '0000-00-00', 'APP/2014-15/1009 ', 'Prem Kumar', '11', 'Ram', 'Residential', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'waitlisted', '0000-00-00', '', '192.168.1.14', 'admin', '2014-10-25 15:21:18'),
(30, '2014-10-25', 'APP/2014-15/1009 ', 'Prem Kumar', '11', 'Ram', 'Residential', 1, '', 2, '', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'waitlisted', '0000-00-00', '', '192.168.1.14', 'admin', '2014-10-25 15:46:33'),
(31, '0000-00-00', 'APP/2014-15/1009 ', 'Prem Kumar', '11', 'Ram', 'Dayscholar', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2014-10-13', '', '192.168.1.14', 'admin', '2014-10-25 15:46:59'),
(32, '2017-05-26', 'APP/2017-18/1000 ', 'Vignesh', 'Nursery', 'Krishna', 'Dayscholar', 1, '', 2, '', 3, '', 4, '', 12, 'yes', 13, '', 14, 'yes', 15, 'yes', 16, '', 17, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 'selected', '2017-06-05', '', '192.168.1.21', 'admin', '2017-10-11 11:38:01');

-- --------------------------------------------------------

--
-- Table structure for table `details_login`
--

CREATE TABLE `details_login` (
  `auto_number` int(255) NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `logintime` datetime NOT NULL,
  `logouttime` datetime NOT NULL,
  `sessionid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `openingcash` decimal(13,2) NOT NULL,
  `closingcash` decimal(13,2) NOT NULL,
  `sales` decimal(13,2) NOT NULL,
  `expenses` decimal(13,2) NOT NULL,
  `deposit` decimal(13,2) NOT NULL,
  `withdrawal` decimal(13,2) NOT NULL,
  `cashmrc` decimal(13,2) NOT NULL,
  `salesreturn` decimal(13,2) NOT NULL,
  `customercollection` decimal(13,2) NOT NULL,
  `supplierpayment` decimal(13,2) NOT NULL,
  `useropeningcash` decimal(13,2) NOT NULL,
  `userclosingcash` decimal(13,2) NOT NULL,
  `usersales` decimal(13,2) NOT NULL,
  `userexpenses` decimal(13,2) NOT NULL,
  `userdeposit` decimal(13,2) NOT NULL,
  `userwithdrawal` decimal(13,2) NOT NULL,
  `usercashmrc` decimal(13,2) NOT NULL,
  `usersalesreturn` decimal(13,2) NOT NULL,
  `usercustomercollection` decimal(13,2) NOT NULL,
  `usersupplierpayment` decimal(13,2) NOT NULL,
  `remarks` text COLLATE latin1_general_ci NOT NULL,
  `rs1000` int(255) NOT NULL,
  `rs500` int(255) NOT NULL,
  `rs100` int(255) NOT NULL,
  `rs50` int(255) NOT NULL,
  `rs20` int(255) NOT NULL,
  `rs10` int(255) NOT NULL,
  `rs5` int(255) NOT NULL,
  `rs2` int(255) NOT NULL,
  `rs1` int(255) NOT NULL,
  `rscoins` decimal(13,2) NOT NULL,
  `denominationtotal` decimal(13,2) NOT NULL,
  `lastupdate` datetime NOT NULL,
  `lastupdateipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdateusername` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `details_login`
--

INSERT INTO `details_login` (`auto_number`, `username`, `logintime`, `logouttime`, `sessionid`, `openingcash`, `closingcash`, `sales`, `expenses`, `deposit`, `withdrawal`, `cashmrc`, `salesreturn`, `customercollection`, `supplierpayment`, `useropeningcash`, `userclosingcash`, `usersales`, `userexpenses`, `userdeposit`, `userwithdrawal`, `usercashmrc`, `usersalesreturn`, `usercustomercollection`, `usersupplierpayment`, `remarks`, `rs1000`, `rs500`, `rs100`, `rs50`, `rs20`, `rs10`, `rs5`, `rs2`, `rs1`, `rscoins`, `denominationtotal`, `lastupdate`, `lastupdateipaddress`, `lastupdateusername`) VALUES
(1, 'admin', '2013-08-20 13:11:17', '0000-00-00 00:00:00', 'pjvdgojfp291sij00btp0e4tc1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-08-20 13:11:17', '192.168.1.7', 'admin'),
(2, 'admin', '2013-08-21 11:23:09', '0000-00-00 00:00:00', '5ooqiiasrjt3pdjkljjju61440', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-08-21 11:23:09', '192.168.1.7', 'admin'),
(3, 'admin', '2013-08-21 13:31:48', '0000-00-00 00:00:00', 'u50d4ib3gs0kvttlccqg3ig7m6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-08-21 13:31:48', '192.168.1.7', 'admin'),
(4, 'admin', '2013-08-21 13:35:06', '2013-08-21 13:35:47', '2j0g0so49j6ioupha712kcnsc4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-08-21 13:35:06', '127.0.0.1', 'admin'),
(5, 'admin', '2013-08-21 15:12:08', '0000-00-00 00:00:00', 'jfhm4dq6d8bmuta7d3m4lg6oe7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-08-21 15:12:08', '192.168.1.7', 'admin'),
(6, 'admin', '2013-08-22 13:34:16', '2013-08-22 13:34:37', 't6pu90k72g8oem9cfu9m37te67', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-08-22 13:34:16', '192.168.1.7', 'admin'),
(7, 'admin', '2013-08-24 16:10:18', '0000-00-00 00:00:00', 'e6e6clebk2vgm0jp60njglgnd0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-08-24 16:10:18', '192.168.1.7', 'admin'),
(8, 'admin', '2013-08-26 17:16:40', '2013-08-26 17:47:43', 'fqjbrkr7i3stva7tu6u1fkusf0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-08-26 17:16:40', '192.168.1.7', 'admin'),
(9, 'admin', '2013-09-02 14:02:23', '0000-00-00 00:00:00', 'rlbq8kknc23errcodh1pa8qph0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-02 14:02:23', '192.168.1.7', 'admin'),
(10, 'admin', '2013-09-09 15:03:32', '0000-00-00 00:00:00', '74esu51ig7oiskpqhdt2b8cpf2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-09 15:03:32', '192.168.1.7', 'admin'),
(11, 'admin', '2013-09-09 15:18:08', '0000-00-00 00:00:00', 'gei5m9s3d2jn3acv5ackihhtn6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-09 15:18:08', '192.168.1.7', 'admin'),
(12, 'admin', '2013-09-09 15:18:12', '2013-09-09 15:18:28', 'ik0864irdotmv3f2im2t88tt51', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-09 15:18:12', '192.168.1.7', 'admin'),
(13, 'admin', '2013-09-09 15:20:08', '2013-09-09 15:24:03', 'dp6crl6l9u6sig22g35mhont17', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-09 15:20:08', '192.168.1.7', 'admin'),
(14, 'admin', '2013-09-14 12:15:59', '0000-00-00 00:00:00', 'a7nkda0ktsqcs5np9b8ntsj0s3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-14 12:15:59', '192.168.1.7', 'admin'),
(15, 'admin', '2013-09-14 14:40:26', '0000-00-00 00:00:00', '1s44qcp0k7u1qh7rk0ld93vlk3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-14 14:40:26', '192.168.1.7', 'admin'),
(16, 'admin', '2013-09-16 11:10:17', '0000-00-00 00:00:00', 'snnhtsr130d46tu8f9eapbh5c7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-16 11:10:17', '192.168.1.7', 'admin'),
(17, 'admin', '2013-09-17 13:17:30', '0000-00-00 00:00:00', 'tc13comuqsqre4todulisbr5a4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-17 13:17:30', '192.168.1.7', 'admin'),
(18, 'admin', '2013-09-18 11:28:16', '2013-09-18 12:17:44', '1nubg2vt3vl5ka4sp24fkr25a1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-18 11:28:16', '127.0.0.1', 'admin'),
(19, 'admin', '2013-09-18 16:17:09', '2013-09-18 16:20:41', 'o7vfan688c92ijih0bj6dlvv52', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-18 16:17:09', '127.0.0.1', 'admin'),
(20, 'admin', '2013-09-19 13:08:53', '2013-09-19 13:13:57', 'sqdiomda4fii8ge0ct3370v916', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-19 13:08:53', '127.0.0.1', 'admin'),
(21, 'admin', '2013-09-19 14:14:29', '2013-09-19 14:15:45', '0ef8559h0ge0mc3qgigbbb7dl5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-19 14:14:29', '127.0.0.1', 'admin'),
(22, 'admin', '2013-09-20 14:58:44', '2013-09-20 16:15:18', 'fupdohtduuuqth4s6rtsfdgmu2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-20 14:58:44', '127.0.0.1', 'admin'),
(23, 'admin', '2013-09-20 15:52:38', '0000-00-00 00:00:00', '7ujufk2vrrv6633t1b2ralgou0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-20 15:52:38', '192.168.1.7', 'admin'),
(24, 'admin', '2013-09-24 15:56:06', '0000-00-00 00:00:00', '2vto1164347pbntvbdra8v24q2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-09-24 15:56:06', '192.168.1.7', 'admin'),
(25, 'admin', '2013-10-03 11:27:50', '0000-00-00 00:00:00', 'oondpa9unlsliia4tjhh0sdn50', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-03 11:27:50', '192.168.1.7', 'admin'),
(26, 'admin', '2013-10-08 13:29:49', '0000-00-00 00:00:00', 'da00d85282666dce8728536e5ee8755a', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-08 13:29:49', '127.0.0.1', 'admin'),
(27, 'admin', '2013-10-15 14:42:01', '2013-10-15 15:15:59', 'ajtjiumkdvf6vu5io5u28jabu2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-15 14:42:01', '192.168.1.7', 'admin'),
(28, 'admin', '2013-10-15 15:16:04', '0000-00-00 00:00:00', 'qlmuab2e85c43ad94u3lfthmb4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-15 15:16:04', '192.168.1.7', 'admin'),
(29, 'admin', '2013-10-16 12:08:51', '2013-10-16 12:14:34', '1iu947630k4ee9579ni9mhdit1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-16 12:08:51', '127.0.0.1', 'admin'),
(30, 'admin', '2013-10-16 12:14:54', '2013-10-16 16:53:48', 'u03cpe6pm1tdld74ofk7kc4sr1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-16 12:14:54', '127.0.0.1', 'admin'),
(31, 'admin', '2013-10-16 16:54:18', '2013-10-16 17:58:34', 'll0leiol1comi3ckuapk8qb831', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-16 16:54:18', '127.0.0.1', 'admin'),
(32, 'admin', '2013-10-17 10:46:13', '2013-10-17 11:26:07', 'f648bv1q8ki5qq5kcaipg12cl3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-17 10:46:13', '127.0.0.1', 'admin'),
(33, 'admin', '2013-10-17 11:26:36', '0000-00-00 00:00:00', 'l1mcvagt81edehlisevr83rnb3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-17 11:26:36', '127.0.0.1', 'admin'),
(34, 'admin', '2013-10-17 13:07:34', '0000-00-00 00:00:00', 'tfe0a3p5opc1dqif7tq4t87j25', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-17 13:07:34', '127.0.0.1', 'admin'),
(35, 'admin', '2013-10-17 13:51:00', '0000-00-00 00:00:00', 'r7sl2fmv326eotg710tttjfa15', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-17 13:51:00', '127.0.0.1', 'admin'),
(36, 'admin', '2013-10-17 14:52:12', '0000-00-00 00:00:00', 'vso1lk690oif4kf9modf5firo3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-17 14:52:12', '127.0.0.1', 'admin'),
(37, 'admin', '2013-10-17 15:12:28', '2013-10-17 15:33:33', 'vbi9tlht8hj51atv9mtb3maj20', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-17 15:12:28', '127.0.0.1', 'admin'),
(38, 'admin', '2013-10-17 15:42:27', '2013-10-17 16:31:27', 'fot4auis4qfc8bep20m1d3s4i3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-17 15:42:27', '127.0.0.1', 'admin'),
(39, 'admin', '2013-10-17 16:39:36', '2013-10-17 18:33:49', '4toj2gog6ejdqep07c15e2c026', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-17 16:39:36', '127.0.0.1', 'admin'),
(40, 'admin', '2013-10-18 10:22:11', '2013-10-18 11:44:04', 'nhkfa73jpoa65qpmf3jerr90n5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-18 10:22:11', '127.0.0.1', 'admin'),
(41, 'admin', '2013-10-18 15:12:30', '2013-10-18 15:18:36', '476gppo23v53t82qfnb5dnr151', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-18 15:12:30', '127.0.0.1', 'admin'),
(42, 'admin', '2013-10-18 16:31:49', '2013-10-18 17:24:28', '39eu0s5tkfoonaqkm5d1j9ot90', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-18 16:31:49', '127.0.0.1', 'admin'),
(43, 'admin', '2013-10-21 14:06:09', '2013-10-21 17:01:50', 'aghm6m6ajkt74f17tbh0974ab4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-21 14:06:09', '127.0.0.1', 'admin'),
(44, 'admin', '2013-10-21 17:03:21', '2013-10-21 17:15:20', '4ah26peb4glequu0g48dotj4h7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-21 17:03:21', '127.0.0.1', 'admin'),
(45, 'admin', '2013-10-22 10:56:55', '2013-10-22 12:01:43', 't1c2m2g4bus7aofl66vmv3q9s1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-22 10:56:55', '127.0.0.1', 'admin'),
(46, 'admin', '2013-10-22 15:34:14', '2013-10-22 15:38:23', 'e657ece0028cf3719bc541fc84785004', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-22 15:34:14', '122.164.32.103', 'admin'),
(47, 'admin', '2013-10-22 15:38:32', '2013-10-22 15:41:07', 'f7c4c0f2da7bf1506d6ca7315370d937', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-22 15:38:32', '122.164.32.103', 'admin'),
(48, 'admin', '2013-10-22 15:41:46', '2013-10-22 15:44:29', '452cbd6180fb61ee32f8c5b705e7987d', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-22 15:41:46', '122.164.32.103', 'admin'),
(49, 'admin', '2013-10-22 15:44:39', '2013-10-22 15:47:07', '701ac1330f1af275a192e23803911eed', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-22 15:44:39', '122.164.32.103', 'admin'),
(50, 'admin', '2013-10-22 15:47:17', '2013-10-22 15:53:11', 'ef9f06b6ed789f3fab03cae2a863a149', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-22 15:47:17', '122.164.32.103', 'admin'),
(51, 'admin', '2013-10-22 15:53:21', '2013-10-22 15:53:45', '4b6d28ec09095741429daa7fbc7033e7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-22 15:53:21', '122.164.32.103', 'admin'),
(52, 'admin', '2013-10-22 16:33:35', '0000-00-00 00:00:00', '9f6e232cbe096fa3f69510db4f7829d4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-22 16:33:35', '122.164.32.103', 'admin'),
(53, 'admin', '2013-10-23 12:21:06', '2013-10-23 16:24:22', '3352b811bd887898be5c7869dee32d99', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-23 12:21:06', '14.96.61.12', 'admin'),
(54, 'admin', '2013-10-23 16:24:45', '2013-10-23 16:25:18', '406d1103780e68f7cd3b6ee513b824cd', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-23 16:24:45', '14.96.61.12', 'admin'),
(55, 'admin', '2013-10-23 16:25:28', '0000-00-00 00:00:00', '76eb1b0ca357cbaf712da447ec185e62', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-23 16:25:28', '14.96.61.12', 'admin'),
(56, 'admin', '2013-10-24 10:31:27', '2013-10-24 10:32:02', '9evfjduo1l4ij9pm3qg6id4m35', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-24 10:31:27', '127.0.0.1', 'admin'),
(57, 'admin', '2013-10-24 10:32:10', '2013-10-24 11:16:44', 'sbfoupt5uqp80t2j452l4qgja6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-24 10:32:10', '127.0.0.1', 'admin'),
(58, 'admin', '2013-10-24 11:17:46', '2013-10-24 14:48:52', 'tt130v4ou69odm61rpogmfqa32', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-24 11:17:46', '127.0.0.1', 'admin'),
(59, 'admin', '2013-10-24 13:07:33', '0000-00-00 00:00:00', '9gd08m4osfkuf9u9m57sgk3762', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-24 13:07:33', '192.168.1.7', 'admin'),
(60, 'admin', '2013-10-28 16:46:54', '2013-10-28 17:58:56', 'co33fleekloavsi7sch6rc0mf1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-28 16:46:54', '127.0.0.1', 'admin'),
(61, 'admin', '2013-10-29 12:18:38', '2013-10-29 12:19:58', '66bmidnvmt754khtvmu2g1dq20', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-29 12:18:38', '127.0.0.1', 'admin'),
(62, 'admin', '2013-10-29 12:20:50', '2013-10-29 12:21:47', '191u6oqrj16068s6u1544hd0e5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-29 12:20:50', '127.0.0.1', 'admin'),
(63, 'admin', '2013-10-29 17:17:11', '2013-10-29 17:18:35', 'i306t3k05ivpe2v3h9d229ueo0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-29 17:17:11', '192.168.1.7', 'admin'),
(64, 'admin', '2013-10-31 11:51:17', '2013-10-31 11:51:56', '4f72147e17023174f578955714bc1a19', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-31 11:51:17', '122.164.22.254', 'admin'),
(65, 'admin', '2013-10-31 15:49:29', '0000-00-00 00:00:00', 'a30251c1e507700774d88c4d610bcda5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-10-31 15:49:29', '122.164.22.254', 'admin'),
(66, 'admin', '2013-11-04 14:37:20', '0000-00-00 00:00:00', '761613bbfff7ccfeb578e5add5d12887', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-04 14:37:20', '122.174.39.234', 'admin'),
(67, 'admin', '2013-11-05 15:44:34', '0000-00-00 00:00:00', '0d4d753cf3dcc758694aebe2dacc73c6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-05 15:44:34', '14.96.54.74', 'admin'),
(68, 'admin', '2013-11-05 15:53:42', '0000-00-00 00:00:00', '1c1164093c7b5b87ec4de53eb13bc4a6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-05 15:53:42', '122.164.74.79', 'admin'),
(69, 'admin', '2013-11-08 16:34:04', '2013-11-08 16:47:04', '25ba38b9ddd425ddd070bc6547112a10', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-08 16:34:04', '122.164.254.129', 'admin'),
(70, 'admin', '2013-11-08 16:48:59', '2013-11-08 18:08:31', '383be7dc1cd8f3318f3df8a83accdeb1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-08 16:48:59', '122.164.254.129', 'admin'),
(71, 'admin', '2013-11-11 12:47:17', '0000-00-00 00:00:00', '2d62dda04e1f50b857c94a06010970a8', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-11 12:47:17', '14.96.20.171', 'admin'),
(72, 'admin', '2013-11-11 12:59:59', '0000-00-00 00:00:00', 'e662580fab25900cd489224ee1903398', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-11 12:59:59', '14.96.20.171', 'admin'),
(73, 'admin', '2013-11-13 14:22:57', '0000-00-00 00:00:00', 'c096d7de0839d488e54e7d6fba4d1d5c', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-13 14:22:57', '14.99.151.93', 'admin'),
(74, 'admin', '2013-11-13 14:31:31', '2013-11-13 14:46:43', '5f95a20ad1101b8e342fe065691ac7fa', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-13 14:31:31', '122.164.249.183', 'admin'),
(75, 'admin', '2013-11-13 14:48:00', '2013-11-13 15:12:51', 'dd244273a8ce18e500b89f4e8f9e1d03', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-13 14:48:00', '122.164.249.183', 'admin'),
(76, 'admin', '2013-11-13 14:51:40', '2013-11-13 15:34:45', '45482bbfae2b8820068eaaab7bf2238c', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-13 14:51:40', '14.99.151.93', 'admin'),
(77, 'admin', '2013-11-13 15:40:08', '0000-00-00 00:00:00', '1f11964a4aec7c92e68344f4aa2ec2e7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-13 15:40:08', '14.99.255.231', 'admin'),
(78, 'admin', '2013-11-13 15:40:38', '2013-11-13 15:56:28', '255e6700f37244d72d23dd0a80bdfeaf', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-13 15:40:38', '14.99.255.231', 'admin'),
(79, 'admin', '2013-11-13 15:56:40', '2013-11-13 15:57:34', 'cd646e4f1374c0928c32a01824513db2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-13 15:56:40', '14.99.255.231', 'admin'),
(80, 'admin', '2013-11-13 15:57:47', '0000-00-00 00:00:00', 'b795674146c19c0907091ce83346eac2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-13 15:57:47', '14.99.255.231', 'admin'),
(81, 'admin', '2013-11-13 15:58:00', '2013-11-13 16:10:27', 'e100a9e6e494e750ec8153aa73b8ea73', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-13 15:58:00', '14.99.255.231', 'admin'),
(82, 'admin', '2013-11-13 16:10:41', '2013-11-13 16:19:39', '09d04aafb0a18cbab4bb4a8846dbf05d', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-13 16:10:41', '14.99.255.231', 'admin'),
(83, 'admin', '2013-11-13 16:20:11', '0000-00-00 00:00:00', 'a145db91e584fc4860eebc213b805f73', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-13 16:20:11', '14.99.255.231', 'admin'),
(84, 'admin', '2013-11-13 16:37:04', '2013-11-13 16:48:50', 'be2c50f0621180fcdffe1a217a197661', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-13 16:37:04', '14.99.160.239', 'admin'),
(85, 'admin', '2013-11-13 16:49:04', '2013-11-13 17:26:47', '8625533d9b983707ce59183c86636398', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-13 16:49:04', '14.99.160.239', 'admin'),
(86, 'admin', '2013-11-14 14:31:41', '2013-11-14 15:09:23', 'd61ece12e9cbc41ca2340abeb5efd47c', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-14 14:31:41', '14.99.135.136', 'admin'),
(87, 'admin', '2013-11-14 15:09:35', '0000-00-00 00:00:00', '03d9a1a35fcba0224d1c19431e03a4ae', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-14 15:09:35', '14.99.135.136', 'admin'),
(88, 'admin', '2013-11-14 16:28:21', '0000-00-00 00:00:00', 'b262dac558474e10410e086489c725ab', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-14 16:28:21', '14.99.135.136', 'admin'),
(89, 'admin', '2013-11-14 18:04:38', '2013-11-14 18:12:08', '436a20fb19f6b906562707bc7ddb71e4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-14 18:04:38', '14.99.135.136', 'admin'),
(90, 'admin', '2013-11-14 18:12:19', '2013-11-14 18:14:45', '5e761c18d5adc0621654699157e56af2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-14 18:12:19', '14.99.135.136', 'admin'),
(91, 'admin', '2013-11-14 18:14:57', '2013-11-14 18:17:44', 'f788ad9a61e40b2b4a6936e8b9a4c891', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-14 18:14:57', '14.99.135.136', 'admin'),
(92, 'admin', '2013-11-14 18:17:56', '2013-11-14 18:22:38', '48138362b7b2aa36463ff95aa4a59c4a', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-14 18:17:56', '14.99.135.136', 'admin'),
(93, 'admin', '2013-11-14 18:22:53', '2013-11-14 18:34:40', 'f4a684b1f28d4c9101724b8f1658e940', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-14 18:22:53', '14.99.135.136', 'admin'),
(94, 'admin', '2013-11-15 11:25:53', '2013-11-15 12:07:59', '64d58981a6825bfeb0b3c7bd499340b4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-15 11:25:53', '14.99.166.209', 'admin'),
(95, 'admin', '2013-11-15 11:27:35', '0000-00-00 00:00:00', 'efb9438a9e586c191f8c58599594b91e', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-15 11:27:35', '14.99.166.209', 'admin'),
(96, 'admin', '2013-11-15 11:46:57', '2013-11-15 12:15:22', '757ea7f470e11af01d3cf0de8c84e323', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-15 11:46:57', '122.164.251.2', 'admin'),
(97, 'admin', '2013-11-15 12:08:14', '2013-11-15 13:50:28', '1f23744800d9572b676a00a02a89ae59', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-15 12:08:14', '14.99.166.209', 'admin'),
(98, 'admin', '2013-11-15 13:06:43', '0000-00-00 00:00:00', '26a10241ea2fdd4fa93d801e6d129151', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-15 13:06:43', '14.99.166.209', 'admin'),
(99, 'admin', '2013-11-15 13:50:56', '2013-11-15 14:26:08', 'f3cadf12ae3a7232bdeace14b2dfa7f1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-15 13:50:56', '14.99.166.209', 'admin'),
(100, 'admin', '2013-11-15 14:26:31', '2013-11-15 14:28:34', 'f1dfa6094d3517cd9d0f6c97121a42c1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-15 14:26:31', '14.99.166.209', 'admin'),
(101, 'admin', '2013-11-15 14:28:49', '0000-00-00 00:00:00', '55a60cdbd8a3fad1ecb1bbab037c5765', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-15 14:28:49', '14.99.166.209', 'admin'),
(102, 'admin', '2013-11-15 17:50:17', '0000-00-00 00:00:00', 'c7dc2c6bb33b973a07c986d826c78453', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-15 17:50:17', '14.99.166.209', 'admin'),
(103, 'admin', '2013-11-16 11:21:25', '2013-11-16 11:52:03', '04050cf803213ee3e82f0eb2d7456546', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-16 11:21:25', '14.99.238.121', 'admin'),
(104, 'admin', '2013-11-16 11:52:15', '2013-11-16 11:58:03', '4c5ede2fa602b2093528b64b61caad88', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-16 11:52:15', '14.99.238.121', 'admin'),
(105, 'admin', '2013-11-16 11:58:15', '2013-11-16 11:59:57', '03ea9f7f2914405585d08e68cf38a5cb', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-16 11:58:15', '14.99.238.121', 'admin'),
(106, 'admin', '2013-11-16 12:00:11', '2013-11-16 12:04:26', 'ca22f89c5c316bcee358485a672b60fb', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-16 12:00:11', '14.99.238.121', 'admin'),
(107, 'admin', '2013-11-16 12:04:39', '2013-11-16 12:14:27', 'fface4af32002f460750934d6611f917', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-16 12:04:39', '14.99.238.121', 'admin'),
(108, 'admin', '2013-11-16 12:14:58', '2013-11-16 12:27:08', '6ecbfd66ba9419883ab1f72f393f25ba', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-16 12:14:58', '14.99.238.121', 'admin'),
(109, 'admin', '2013-11-16 12:27:21', '0000-00-00 00:00:00', 'd2332c1dcfd621e7ca7e6619088ffb58', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-16 12:27:21', '14.99.238.121', 'admin'),
(110, 'admin', '2013-11-18 11:14:38', '2013-11-18 11:19:15', '672d3a8a05cc809eb4e82e4941cf3bc0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-18 11:14:38', '14.99.177.67', 'admin'),
(111, 'admin', '2013-11-18 11:19:34', '2013-11-18 11:46:50', '7ee242e12c72eb34127ad9e80fbb3553', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-18 11:19:34', '14.99.177.67', 'admin'),
(112, 'admin', '2013-11-18 11:47:05', '0000-00-00 00:00:00', '60f3d3600044cd5a88dfdd7d06657313', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-18 11:47:05', '14.99.177.67', 'admin'),
(113, 'admin', '2013-11-18 15:15:29', '0000-00-00 00:00:00', 'd4ae08affdf211f6d0eafe5177045470', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-18 15:15:29', '14.99.177.67', 'admin'),
(114, 'admin', '2013-11-23 13:24:20', '2013-11-23 15:44:54', '4db87384120a778a4360221ca8784528', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-23 13:24:20', '122.164.26.81', 'admin'),
(115, 'admin', '2013-11-23 19:10:37', '2013-11-23 19:11:43', '2fed1659d91c7b3de3b1ab4aac0db43f', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-23 19:10:37', '122.164.26.81', 'admin'),
(116, 'admin', '2013-11-25 12:15:09', '2013-11-25 12:20:37', '900b4e8e43abc4d2419954ef9b045d34', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-25 12:15:09', '122.164.99.41', 'admin'),
(117, 'admin', '2013-11-25 14:16:31', '2013-11-25 15:05:16', 'a78223fa55a05c1a476e0ccc401052df', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-25 14:16:31', '14.99.38.242', 'admin'),
(118, 'admin', '2013-11-25 14:38:11', '2013-11-25 14:48:15', 'f6d97333721eadfb4d0f399adc2c681f', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-25 14:38:11', '122.164.99.41', 'admin'),
(119, 'admin', '2013-11-25 15:05:31', '2013-11-25 16:17:34', '1e3c64a9fab4112ff152a8707a96d223', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-25 15:05:31', '14.99.38.242', 'admin'),
(120, 'admin', '2013-11-25 16:18:02', '2013-11-25 16:37:20', '8f0a7f8e0531b99986e0bed9cb190bd0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-25 16:18:02', '14.96.6.14', 'admin'),
(121, 'admin', '2013-11-25 16:37:32', '0000-00-00 00:00:00', '8a314d8eb0883b2127eac6912a08e6e5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-25 16:37:32', '14.96.6.14', 'admin'),
(122, 'admin', '2013-11-28 13:25:03', '2013-11-28 13:25:53', '151aa6e3e4fd20768dbe675da5ecb04a', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-28 13:25:03', '122.164.127.218', 'admin'),
(123, 'admin', '2013-11-28 13:26:49', '2013-11-28 14:25:53', '41d0f1043e399a8485c726e95a9640b1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-28 13:26:49', '122.164.127.218', 'admin'),
(124, 'admin', '2013-11-28 17:26:54', '2013-11-28 17:43:13', '214be2de7a183479ca9c59824984f543', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-28 17:26:54', '122.164.127.218', 'admin'),
(125, 'admin', '2013-11-28 17:43:22', '2013-11-28 17:44:55', '59739a665c63ec23b45204a5eb0cdc12', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-28 17:43:22', '122.164.127.218', 'admin'),
(126, 'admin', '2013-11-28 17:45:07', '2013-11-28 17:59:19', 'efe9045732a92cbd47becacd38d97998', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-28 17:45:07', '122.164.127.218', 'admin'),
(127, 'admin', '2013-11-28 17:59:34', '2013-11-28 18:00:58', '1495d3f392c01bd3cbcfc8af81bc7840', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-28 17:59:34', '122.164.127.218', 'admin'),
(128, 'admin', '2013-11-30 12:20:40', '0000-00-00 00:00:00', 'c2bcdb6981e0bb95db550832d6d8f174', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-11-30 12:20:40', '14.99.69.111', 'admin'),
(129, 'admin', '2013-12-06 12:39:11', '2013-12-06 12:53:37', 'ae73b77d4c6497c360488987c6e13c0c', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-06 12:39:11', '14.99.236.8', 'admin'),
(130, 'admin', '2013-12-06 12:53:48', '2013-12-06 13:03:15', '07818a38f615b586fa3dd96e97162ed2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-06 12:53:48', '14.99.236.8', 'admin'),
(131, 'admin', '2013-12-06 13:03:34', '2013-12-06 13:07:06', '70f46dd9d1a64a55b4e8a28e93a38f00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-06 13:03:34', '14.99.236.8', 'admin'),
(132, 'admin', '2013-12-06 13:07:20', '2013-12-06 14:16:20', 'ef1bc7cd40fd252330517ece71e9b4d5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-06 13:07:20', '14.99.236.8', 'admin'),
(133, 'admin', '2013-12-06 13:48:47', '2013-12-06 15:29:12', '769fbddc51e41659d5753aa8d3dc5c66', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-06 13:48:47', '122.164.133.118', 'admin'),
(134, 'admin', '2013-12-06 14:16:41', '0000-00-00 00:00:00', '09a0b880b3d251c5d3c71fec68655ba4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-06 14:16:41', '14.99.236.8', 'admin'),
(135, 'admin', '2013-12-07 12:25:48', '0000-00-00 00:00:00', 'b943f2adb5b8c3863e395057afc5a3a6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-07 12:25:48', '14.99.74.99', 'admin'),
(136, 'admin', '2013-12-07 12:45:53', '2013-12-07 12:54:32', '35c02976587e28dc35e0fe00925ff4fb', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-07 12:45:53', '14.99.114.83', 'admin'),
(137, 'admin', '2013-12-07 12:54:39', '2013-12-07 12:58:22', '7d4136b202166c67beed39ca9fc25fab', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-07 12:54:39', '14.99.114.83', 'admin'),
(138, 'admin', '2013-12-07 12:58:30', '0000-00-00 00:00:00', 'faa9cd3a47afb8b57d6801786118e7ad', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-07 12:58:30', '14.99.114.83', 'admin'),
(139, 'admin', '2013-12-07 14:36:53', '0000-00-00 00:00:00', '1aa801e431996376088d5ae55508dc59', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-07 14:36:53', '14.99.133.125', 'admin'),
(140, 'admin', '2013-12-07 16:47:33', '0000-00-00 00:00:00', '3abf33b280c1e2f61b063ee53a7a2d99', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-07 16:47:33', '14.99.94.149', 'admin'),
(141, 'admin', '2013-12-09 10:49:04', '2013-12-09 11:19:12', 'aaa22b9f6bd83858ee4c9d75d23d4f6b', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-09 10:49:04', '14.96.46.62', 'admin'),
(142, 'admin', '2013-12-09 11:19:19', '2013-12-09 15:56:30', '841f63932536e43d46e364a9df62de13', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-09 11:19:19', '14.96.46.62', 'admin');
INSERT INTO `details_login` (`auto_number`, `username`, `logintime`, `logouttime`, `sessionid`, `openingcash`, `closingcash`, `sales`, `expenses`, `deposit`, `withdrawal`, `cashmrc`, `salesreturn`, `customercollection`, `supplierpayment`, `useropeningcash`, `userclosingcash`, `usersales`, `userexpenses`, `userdeposit`, `userwithdrawal`, `usercashmrc`, `usersalesreturn`, `usercustomercollection`, `usersupplierpayment`, `remarks`, `rs1000`, `rs500`, `rs100`, `rs50`, `rs20`, `rs10`, `rs5`, `rs2`, `rs1`, `rscoins`, `denominationtotal`, `lastupdate`, `lastupdateipaddress`, `lastupdateusername`) VALUES
(143, 'admin', '2013-12-09 15:56:41', '2013-12-09 16:15:33', '9c32e5766a964cacd8b7c81d198b8460', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-09 15:56:41', '14.96.31.140', 'admin'),
(144, 'admin', '2013-12-09 16:15:42', '0000-00-00 00:00:00', '4d131159052cafe6d82e27a5e7ef8cd4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-09 16:15:42', '14.96.31.140', 'admin'),
(145, 'admin', '2013-12-10 11:30:41', '2013-12-10 11:45:06', 'ecad7c3294a4ea95e8f45db244224a9b', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-10 11:30:41', '14.96.92.169', 'admin'),
(146, 'admin', '2013-12-10 11:45:24', '2013-12-10 12:19:56', '7915b6fb142a8e27bd923d136f3729b5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-10 11:45:24', '14.96.92.169', 'admin'),
(147, 'admin', '2013-12-10 12:20:06', '2013-12-10 12:21:42', '3222e0ad0bd5a9f4f402abe248ab21ec', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-10 12:20:06', '14.99.68.151', 'admin'),
(148, 'admin', '2013-12-10 12:21:49', '2013-12-10 12:22:15', 'c473b16c39456d814df891c3746c71a4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-10 12:21:49', '14.99.68.151', 'admin'),
(149, 'admin', '2013-12-10 12:22:21', '0000-00-00 00:00:00', 'a13f869e51ce1f5e0f74771747b229b7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-10 12:22:21', '14.99.68.151', 'admin'),
(150, 'admin', '2013-12-10 12:22:31', '2013-12-10 15:19:18', '3d039fc0d9008c8040502e8378fc616e', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-10 12:22:31', '14.99.68.151', 'admin'),
(151, 'admin', '2013-12-10 15:19:25', '0000-00-00 00:00:00', '5306b7179ab45f12da3a1f043342ef38', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-10 15:19:25', '14.99.152.237', 'admin'),
(152, 'admin', '2013-12-10 15:23:18', '0000-00-00 00:00:00', '42aec0aeab93fc04de63b600bb60b9be', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-10 15:23:18', '122.164.38.164', 'admin'),
(153, 'admin', '2013-12-13 10:25:01', '2013-12-13 10:30:14', '928018a5183cc6a368a82a9b9c7f9c2e', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-13 10:25:01', '122.164.64.123', 'admin'),
(154, 'admin', '2013-12-13 11:59:05', '0000-00-00 00:00:00', '37081f508378e2045e1b831f6bf9e8c5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-13 11:59:05', '14.96.7.113', 'admin'),
(155, 'admin', '2013-12-13 12:01:49', '0000-00-00 00:00:00', '0d215f534995e65995fdbca303296c69', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-13 12:01:49', '14.96.7.113', 'admin'),
(156, 'admin', '2013-12-13 13:25:41', '0000-00-00 00:00:00', 'f492fbaf863162c1e3a2f1d0622c0d45', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-13 13:25:41', '14.96.17.235', 'admin'),
(157, 'admin', '2013-12-14 10:46:42', '2013-12-14 10:47:32', '4d9fef6f1d1a30256df4db691c644d12', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-14 10:46:42', '122.164.27.85', 'admin'),
(158, 'admin', '2013-12-14 10:50:48', '2013-12-14 11:06:01', '108e1338d7565a6354baf6f6c501570f', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-14 10:50:48', '122.174.18.88', 'admin'),
(159, 'admin', '2013-12-14 10:52:51', '2013-12-14 10:55:39', '05bdeab962cd995c8ea81b24f5cd61b9', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-14 10:52:51', '117.193.160.128', 'admin'),
(160, 'admin', '2013-12-14 10:55:54', '0000-00-00 00:00:00', '9fd8ae9033e7a57a326eccc5105d2e6d', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-14 10:55:54', '117.193.160.128', 'admin'),
(161, 'admin', '2013-12-14 11:07:52', '2013-12-14 15:56:19', 'ffad04c0c41bacda645177d7d2782191', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-14 11:07:52', '14.99.190.215', 'admin'),
(162, 'admin', '2013-12-14 15:19:36', '0000-00-00 00:00:00', 'fceebae7e8db4374db7a8c6c2dcc9943', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-14 15:19:36', '122.164.158.94', 'admin'),
(163, 'admin', '2013-12-14 15:55:10', '0000-00-00 00:00:00', '61a8bd188f5b78f0070c8cedb9350d95', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-14 15:55:10', '59.96.210.127', 'admin'),
(164, 'admin', '2013-12-14 15:56:29', '2013-12-14 16:26:22', '10eb87412ab555842b9848f4dabc0470', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-14 15:56:29', '14.96.67.165', 'admin'),
(165, 'admin', '2013-12-14 16:26:33', '2013-12-14 16:34:59', '1d09b2dff68bf364b7e446204633db5d', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-14 16:26:33', '14.96.57.110', 'admin'),
(166, 'admin', '2013-12-14 16:35:07', '2013-12-14 16:55:57', '5d8499a0feefd1282028c7d3e8f6c14b', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-14 16:35:07', '14.96.57.110', 'admin'),
(167, 'admin', '2013-12-14 16:35:48', '2013-12-14 17:23:58', '2a41e0b3fd0aa463ad4abf1a49d10410', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-14 16:35:48', '122.164.43.175', 'admin'),
(168, 'admin', '2013-12-14 16:56:06', '0000-00-00 00:00:00', 'ecd46967b178f345735f67a682b86a5a', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-14 16:56:06', '14.96.57.110', 'admin'),
(169, 'admin', '2013-12-16 11:34:54', '0000-00-00 00:00:00', '6a8c2650b5b948ee297976ba240e650e', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-16 11:34:54', '14.96.98.142', 'admin'),
(170, 'admin', '2013-12-16 12:49:31', '2013-12-16 12:57:41', '41af50dedf93f1863182998cc93006df', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-16 12:49:31', '14.96.98.142', 'admin'),
(171, 'admin', '2013-12-16 12:57:55', '0000-00-00 00:00:00', '0c467e3ca186b305c0a5d244aed0e4f7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-16 12:57:55', '14.96.98.142', 'admin'),
(172, 'admin', '2013-12-16 16:06:09', '0000-00-00 00:00:00', 'b6ac4b62877633347de97335e48f0a29', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-16 16:06:09', '14.99.137.165', 'admin'),
(173, 'admin', '2013-12-17 12:57:48', '2013-12-17 12:58:14', 'f23ffb88feaac2c37024cad20ce0fbe2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-17 12:57:48', '14.99.161.216', 'admin'),
(174, 'admin', '2013-12-17 12:58:26', '2013-12-17 13:41:01', 'b46d99f6e861097597b9413de9dcf659', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-17 12:58:26', '14.99.161.216', 'admin'),
(175, 'admin', '2013-12-17 13:42:05', '0000-00-00 00:00:00', '8745379b24318cea70b528693af9916f', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-17 13:42:05', '14.99.161.216', 'admin'),
(176, 'admin', '2013-12-17 14:52:05', '2013-12-17 14:57:34', '7a6cb9a6527b00c5b5dee4ab4824c41b', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-17 14:52:05', '14.99.146.186', 'admin'),
(177, 'admin', '2013-12-17 14:57:15', '2013-12-17 15:22:20', '8c96954d84cc712b5c5804d5cb2d5f9d', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-17 14:57:15', '14.99.146.186', 'admin'),
(178, 'admin', '2013-12-17 14:59:06', '2013-12-17 15:04:22', 'a247dad2b08434bae1e9f1e8785f3d80', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-17 14:59:06', '14.99.146.186', 'admin'),
(179, 'admin', '2013-12-17 15:04:29', '0000-00-00 00:00:00', '26daa16ed553a0c0505b591261fc1ce3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-17 15:04:29', '14.99.146.186', 'admin'),
(180, 'admin', '2013-12-17 15:22:29', '2013-12-17 15:31:23', '7695f7e7d16c592237d4a604a1c8f0d7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-17 15:22:29', '14.99.146.186', 'admin'),
(181, 'admin', '2013-12-17 15:31:33', '2013-12-17 15:32:27', '0d6cf88de7444394b370ca636faff126', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-17 15:31:33', '14.99.146.186', 'admin'),
(182, 'admin', '2013-12-17 15:32:39', '0000-00-00 00:00:00', 'b637447ec91d8b3c119b9157e95f14ad', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-17 15:32:39', '14.99.146.186', 'admin'),
(183, 'admin', '2013-12-18 08:58:12', '0000-00-00 00:00:00', '5927612bffb4af1b1aff1c5cd1ef86c8', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 08:58:12', '117.193.172.245', 'admin'),
(184, 'admin', '2013-12-18 12:40:23', '2013-12-18 12:45:53', 'c09692c89eaf0747e3ab878db5ea5d4f', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 12:40:23', '14.99.46.128', 'admin'),
(185, 'admin', '2013-12-18 12:46:07', '2013-12-18 12:50:22', '4d3a8636e68d637ad76f2ae0a0f4a585', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 12:46:07', '14.99.46.128', 'admin'),
(186, 'admin', '2013-12-18 12:46:59', '0000-00-00 00:00:00', '6519b1e26b933d958f40abdf4936b995', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 12:46:59', '14.99.46.128', 'admin'),
(187, 'admin', '2013-12-18 12:50:32', '0000-00-00 00:00:00', '2ac92bc5596136063ca78c81a804cdd3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 12:50:32', '14.99.46.128', 'admin'),
(188, 'admin', '2013-12-18 13:02:50', '2013-12-18 13:05:40', '3505f48c19516ca9206aebce0f76377c', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 13:02:50', '117.193.172.245', 'admin'),
(189, 'admin', '2013-12-18 13:05:53', '2013-12-18 13:06:40', '43f9657bb0e60a5d3582744fe9d08984', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 13:05:53', '117.193.172.245', 'admin'),
(190, 'admin', '2013-12-18 13:16:51', '0000-00-00 00:00:00', 'ed9fc9961d78e8c1f8e671ed93e7b373', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 13:16:51', '117.193.172.245', 'admin'),
(191, 'admin', '2013-12-18 14:25:32', '2013-12-18 14:29:17', '987c33c96f418fd849c75a2abcf7a427', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 14:25:32', '117.193.172.245', 'admin'),
(192, 'admin', '2013-12-18 14:29:51', '0000-00-00 00:00:00', 'b99d2848790f7bcc2e6a8de0f4883b09', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 14:29:51', '117.193.172.245', 'admin'),
(193, 'admin', '2013-12-18 14:47:04', '2013-12-18 17:36:22', '4cc95b0aeab9f1cadd462b36064f809e', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 14:47:04', '117.193.172.245', 'admin'),
(194, 'admin', '2013-12-18 15:14:49', '2013-12-18 15:20:02', 'a37a1477258d1b082cbdc1b0b97e1fdf', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 15:14:49', '14.96.49.229', 'admin'),
(195, 'admin', '2013-12-18 15:20:11', '2013-12-18 16:12:05', 'e6092028fdfedb162261f689a10d1978', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 15:20:11', '14.96.49.229', 'admin'),
(196, 'admin', '2013-12-18 15:22:41', '2013-12-18 16:13:16', '6f7187e062b355bf15a2809c5abd7ad6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 15:22:41', '14.96.49.229', 'admin'),
(197, 'admin', '2013-12-18 16:12:13', '0000-00-00 00:00:00', 'ab3f53fefae37a0360990c0dbc2601fb', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 16:12:13', '14.96.49.229', 'admin'),
(198, 'admin', '2013-12-18 16:50:41', '2013-12-18 16:58:37', 'f3e1e3c7138c86111f83803bd991623b', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 16:50:41', '117.193.173.12', 'admin'),
(199, 'admin', '2013-12-18 16:58:53', '2013-12-18 17:50:27', 'd1fda74e276abc9efce71314d0fbf7c4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 16:58:53', '117.193.173.12', 'admin'),
(200, 'admin', '2013-12-18 17:36:54', '0000-00-00 00:00:00', '228c23e465ada2d4e6c8090e6e260a2b', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 17:36:54', '117.193.173.12', 'admin'),
(201, 'admin', '2013-12-18 17:50:43', '2013-12-18 18:01:50', '8a4bf80ae6ced6219d08b0f9ca611ff2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 17:50:43', '117.193.173.12', 'admin'),
(202, 'admin', '2013-12-18 18:02:59', '2013-12-18 18:12:54', '0682a96c3187cdfbf4f7e33b20e46479', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-18 18:02:59', '117.193.173.12', 'admin'),
(203, 'admin', '2013-12-19 10:59:17', '2013-12-19 11:05:44', 'aa73dff3f0b134524f9842fc6fad6623', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-19 10:59:17', '14.96.29.28', 'admin'),
(204, 'admin', '2013-12-19 11:05:53', '2013-12-19 12:20:37', '090c4873250789dd88a0278cb846e3e4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-19 11:05:53', '14.96.29.28', 'admin'),
(205, 'admin', '2013-12-19 12:20:46', '2013-12-19 12:23:48', '331885f52fbfce7b771d442efc5f7505', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-19 12:20:46', '14.96.29.28', 'admin'),
(206, 'admin', '2013-12-19 12:23:56', '2013-12-19 12:34:20', '7db276b78ab64877fc65602dace5a6dc', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-19 12:23:56', '14.96.29.28', 'admin'),
(207, 'admin', '2013-12-19 12:34:30', '0000-00-00 00:00:00', 'ffaacd3b4cb2f539a026d2edcf3c94d0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-19 12:34:30', '14.96.29.28', 'admin'),
(208, 'admin', '2013-12-19 15:01:53', '2013-12-19 17:59:28', 'ec79b8bed60d9cfedde045fb93ef2d6d', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-19 15:01:53', '14.99.49.78', 'admin'),
(209, 'admin', '2013-12-19 15:09:43', '2013-12-19 15:43:45', 'da021ab7ce479b14f1fe2d3372a5c3ec', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-19 15:09:43', '122.164.172.32', 'admin'),
(210, 'admin', '2013-12-19 16:12:26', '2013-12-19 16:13:28', 'afdb6b897cb32c1a2cf765ea6c80bbfb', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-19 16:12:26', '122.164.172.32', 'admin'),
(211, 'admin', '2013-12-19 17:59:38', '0000-00-00 00:00:00', '773e52ba65290e078cf5130bfe120624', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-19 17:59:38', '14.99.198.166', 'admin'),
(212, 'admin', '2013-12-20 10:51:24', '2013-12-20 12:47:11', '9253ef74bb75331b596f07e58a738e8b', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-20 10:51:24', '14.99.22.144', 'admin'),
(213, 'admin', '2013-12-20 11:57:20', '2013-12-20 12:46:55', '465c814de2818370b65acce72259a1ef', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-20 11:57:20', '14.99.22.144', 'admin'),
(214, 'admin', '2013-12-20 12:47:34', '2013-12-20 14:04:26', '0041442200399657af7c8d77baf8d4a5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-20 12:47:34', '14.99.16.23', 'admin'),
(215, 'admin', '2013-12-20 12:53:29', '2013-12-20 13:40:07', '3cbd5d4ce72f959d9aaa61c6b3879021', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-20 12:53:29', '14.96.25.183', 'admin'),
(216, 'admin', '2013-12-20 13:40:46', '0000-00-00 00:00:00', 'f91473cf730fa6bf48a94c3afcd45dc9', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-20 13:40:46', '14.96.25.183', 'admin'),
(217, 'admin', '2013-12-20 14:04:44', '2013-12-20 14:31:09', 'd1911ef5ab71da9d7ed00bbebec6932b', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-20 14:04:44', '14.99.16.23', 'admin'),
(218, 'admin', '2013-12-20 14:23:54', '2013-12-20 14:32:08', 'ed8b84f4f7948618219ed0afed18017d', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-20 14:23:54', '14.96.25.183', 'admin'),
(219, 'admin', '2013-12-20 14:31:27', '2013-12-20 14:42:06', '774df43dbf5b69781374e803295e0bc2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-20 14:31:27', '14.99.230.43', 'admin'),
(220, 'admin', '2013-12-20 14:32:42', '0000-00-00 00:00:00', 'c550d28c8f6a5260e44325699257aed6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-20 14:32:42', '14.96.25.183', 'admin'),
(221, 'admin', '2013-12-20 14:42:28', '2013-12-20 15:19:22', '6f3622d06043c4e908a2d05aab05557f', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-20 14:42:28', '14.99.230.43', 'admin'),
(222, 'admin', '2013-12-20 15:19:35', '0000-00-00 00:00:00', '1739fbebc83fbb4817fce00f9fb10a64', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-20 15:19:35', '14.99.230.43', 'admin'),
(223, 'admin', '2013-12-20 15:25:21', '2013-12-20 15:35:52', 'ab3bf993abcbd5bbb3b82afe97cf428b', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-20 15:25:21', '14.96.25.183', 'admin'),
(224, 'admin', '2013-12-20 15:36:13', '0000-00-00 00:00:00', 'd6e5f18c64cde869bb375dfbc4380d2f', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-20 15:36:13', '14.96.25.183', 'admin'),
(225, 'admin', '2013-12-21 12:30:13', '2013-12-21 12:56:08', '3f5314cab8dda220e4d4d853fb9c348a', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-21 12:30:13', '14.99.140.148', 'admin'),
(226, 'admin', '2013-12-21 12:56:18', '0000-00-00 00:00:00', '4f67bb16be6382b6d6ff6e517d0d14e7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-21 12:56:18', '14.99.140.148', 'admin'),
(227, 'admin', '2013-12-21 14:26:10', '0000-00-00 00:00:00', '6b0be7edc8a2ed6cbbe356d67278fe4b', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-21 14:26:10', '14.99.214.193', 'admin'),
(228, 'admin', '2013-12-23 09:57:38', '0000-00-00 00:00:00', '1962cdd7168687f470461795b5ba11ac', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-23 09:57:38', '117.193.191.165', 'admin'),
(229, 'admin', '2013-12-23 14:40:55', '0000-00-00 00:00:00', 'c5d289b76e105a8f0d7307726e861e5a', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-23 14:40:55', '14.99.1.140', 'admin'),
(230, 'admin', '2013-12-23 16:13:55', '2013-12-23 16:19:49', '4fb23e7fd2dc1dec40e517dd56c5f59e', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-23 16:13:55', '14.99.1.140', 'admin'),
(231, 'admin', '2013-12-23 16:20:25', '0000-00-00 00:00:00', 'a1fa0ee1d72a347f542eba25103dd1e4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-23 16:20:25', '14.99.1.140', 'admin'),
(232, 'admin', '2013-12-23 16:31:20', '0000-00-00 00:00:00', '0c5798f2a6e0ca2e43ec74627aa32fcf', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-23 16:31:20', '14.99.18.94', 'admin'),
(233, 'admin', '2013-12-24 10:35:26', '2013-12-24 10:36:58', '3d41c362515fe3b2eb8c747f2dac996c', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-24 10:35:26', '122.164.250.89', 'admin'),
(234, 'admin', '2013-12-24 11:09:19', '0000-00-00 00:00:00', 'e2fbe13ef9eaef81fe07959d5be52f90', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-24 11:09:19', '117.193.178.157', 'admin'),
(235, 'admin', '2013-12-24 11:14:26', '0000-00-00 00:00:00', '3b3cc3cb4656a40593910e2ddae9ddbe', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-24 11:14:26', '14.99.216.170', 'admin'),
(236, 'admin', '2013-12-24 11:20:46', '2013-12-24 11:48:09', 'eb3a59608e519cde58055b247672c3a1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-24 11:20:46', '14.99.216.170', 'admin'),
(237, 'admin', '2013-12-24 11:48:19', '0000-00-00 00:00:00', 'e8885ff10dc978eb86cbf7b311a10f09', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-24 11:48:19', '14.99.216.170', 'admin'),
(238, 'admin', '2013-12-24 15:51:11', '0000-00-00 00:00:00', 'cf1609bfa1f1c71ea46eccdf277ff883', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-24 15:51:11', '117.193.183.110', 'admin'),
(239, 'admin', '2013-12-26 11:13:29', '2013-12-26 11:25:39', 'd579ace23c886e1b0d711b956a38f5b1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-26 11:13:29', '14.96.22.67', 'admin'),
(240, 'admin', '2013-12-26 11:16:23', '0000-00-00 00:00:00', 'd43f458e570744ef092520c115edbd06', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-26 11:16:23', '117.193.185.64', 'admin'),
(241, 'admin', '2013-12-26 11:25:47', '2013-12-26 11:34:48', '2e6efce2f20eca3085a7d0a588333f84', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-26 11:25:47', '14.96.22.67', 'admin'),
(242, 'admin', '2013-12-26 11:34:56', '0000-00-00 00:00:00', 'c350ebeaf1260c58a02126b752a2ed22', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-26 11:34:56', '14.96.22.67', 'admin'),
(243, 'admin', '2013-12-26 13:23:40', '0000-00-00 00:00:00', '3f2db979ed1f5505e6246cf13971700a', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-26 13:23:40', '14.96.22.67', 'admin'),
(244, 'admin', '2013-12-26 15:21:40', '2013-12-26 16:44:18', 'c49d38865347194aac1576f87950cb19', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-26 15:21:40', '14.96.4.110', 'admin'),
(245, 'admin', '2013-12-26 16:45:16', '2013-12-26 16:45:38', 'd00a821f5bfb341b0e067c706c43cc49', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-26 16:45:16', '14.96.4.110', 'admin'),
(246, 'admin', '2013-12-26 16:45:45', '0000-00-00 00:00:00', '2ef628bb83b40c901100cc4b0fbde488', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-26 16:45:45', '14.96.4.110', 'admin'),
(247, 'admin', '2013-12-26 16:47:26', '0000-00-00 00:00:00', '44bb4cb99a42e718a25caa26f0c6f9b4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-26 16:47:26', '14.96.4.110', 'admin'),
(248, 'admin', '2013-12-27 09:37:49', '2013-12-27 09:40:31', '9096e6b24b83400269abbb36beb5c757', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-27 09:37:49', '117.193.171.234', 'admin'),
(249, 'admin', '2013-12-27 09:40:58', '2013-12-27 09:41:53', '6f446d826c24a5c8f9fefeea544ae498', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-27 09:40:58', '117.193.171.234', 'admin'),
(250, 'admin', '2013-12-27 09:51:28', '0000-00-00 00:00:00', 'e1ca72d5885a81f19231b755a2797007', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-27 09:51:28', '14.99.197.28', 'admin'),
(251, 'admin', '2013-12-27 09:57:14', '2013-12-27 09:57:42', '59dca3d905a82ca0c57fb60b139f8bf3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-27 09:57:14', '117.193.171.234', 'admin'),
(252, 'admin', '2013-12-27 09:58:07', '0000-00-00 00:00:00', 'cffc3f53e4783c017b5395da1fb595e1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-27 09:58:07', '117.193.171.234', 'admin'),
(253, 'admin', '2013-12-27 12:11:46', '2013-12-27 12:17:33', '5c30f14331e917efdc6b9c606a3baecb', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-27 12:11:46', '117.193.171.234', 'admin'),
(254, 'admin', '2013-12-27 12:17:47', '2013-12-27 12:24:02', '4dd50e701a8380540b6395c4b4881e85', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-27 12:17:47', '117.193.171.234', 'admin'),
(255, 'admin', '2013-12-27 12:24:16', '2013-12-27 12:27:15', '05479d8057adfa8c53fc45f25531556e', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-27 12:24:16', '117.193.171.234', 'admin'),
(256, 'admin', '2013-12-27 12:27:33', '2013-12-27 12:29:05', 'b12dc2cc1db1b0700597ac7ee3527772', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-27 12:27:33', '117.193.171.234', 'admin'),
(257, 'admin', '2013-12-27 12:29:20', '0000-00-00 00:00:00', '2790b56dce2aed394a9a035c5460568e', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-27 12:29:20', '117.193.171.234', 'admin'),
(258, 'admin', '2013-12-27 15:00:56', '0000-00-00 00:00:00', '034add9b50a072c88ab6698e969414cc', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-27 15:00:56', '117.193.171.234', 'admin'),
(259, 'admin', '2013-12-27 15:39:50', '0000-00-00 00:00:00', '52c9032cb011bcd8db69bee090541aad', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-27 15:39:50', '117.193.171.234', 'admin'),
(260, 'admin', '2013-12-28 12:17:26', '0000-00-00 00:00:00', '010a4caeebbd4379c64051fe053d602a', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-28 12:17:26', '117.193.169.33', 'admin'),
(261, 'admin', '2013-12-28 13:44:06', '0000-00-00 00:00:00', '50d276595a473f1b2d4bd4f67134a19c', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-28 13:44:06', '14.99.43.253', 'admin'),
(262, 'admin', '2013-12-28 17:20:36', '0000-00-00 00:00:00', '196e97a0cdd63c410230a58108b5f933', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-28 17:20:36', '14.99.43.253', 'admin'),
(263, 'admin', '2013-12-30 11:48:18', '2013-12-30 11:54:38', 'f340117725729d34664cf8194e24b950', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-30 11:48:18', '14.96.100.91', 'admin'),
(264, 'admin', '2013-12-30 11:55:14', '0000-00-00 00:00:00', 'be343c2ff25c0735f7e407d717756335', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-30 11:55:14', '14.96.100.91', 'admin'),
(265, 'admin', '2013-12-30 12:12:50', '0000-00-00 00:00:00', 'f659eeb2511c82b15a734227501447bb', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-30 12:12:50', '14.99.40.7', 'admin'),
(266, 'admin', '2013-12-30 15:07:52', '0000-00-00 00:00:00', '54bfb0e2597db0500bfaf0ed60e9c766', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-30 15:07:52', '14.99.172.103', 'admin'),
(267, 'admin', '2013-12-30 15:40:06', '0000-00-00 00:00:00', '6713c79e53bf9f08dde4860cce1a3570', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-30 15:40:06', '14.99.172.103', 'admin'),
(268, 'admin', '2013-12-30 15:47:59', '2013-12-30 15:57:52', '43137490631c0be05edb2dde7ca11f24', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-30 15:47:59', '14.96.44.91', 'admin'),
(269, 'admin', '2013-12-30 15:58:29', '0000-00-00 00:00:00', '787232cd6365c06397185f719764b7d1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-30 15:58:29', '14.96.44.91', 'admin'),
(270, 'admin', '2013-12-30 16:19:17', '0000-00-00 00:00:00', '8976eafc6df21f0b92dd861e71f47b4f', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-30 16:19:17', '14.99.164.118', 'admin'),
(271, 'admin', '2013-12-30 16:43:56', '0000-00-00 00:00:00', 'c23865264580c24fb432c8a0d3e7fbac', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-30 16:43:56', '14.99.164.118', 'admin'),
(272, 'admin', '2013-12-30 17:03:25', '0000-00-00 00:00:00', '17f5d84a48073fd7803b39013a180424', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-30 17:03:25', '14.99.164.118', 'admin'),
(273, 'admin', '2013-12-30 19:49:38', '2013-12-30 19:50:29', 'd4895986df65eff9f22a4683a9d9d0f7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-30 19:49:38', '117.193.160.219', 'admin'),
(274, 'admin', '2013-12-30 19:50:46', '2013-12-30 19:58:15', 'a9eaa3d1a5e8f5abd5f83b4c333d139c', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-30 19:50:46', '117.193.160.219', 'admin'),
(275, 'admin', '2013-12-30 19:50:46', '2013-12-30 19:58:15', '6926a96e9f9bfd25e507f99cae8c8089', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-30 19:50:46', '117.193.160.219', 'admin'),
(276, 'admin', '2013-12-31 11:04:17', '2013-12-31 12:57:15', 'caa7ae7c06564bfeeaf884511c37d024', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 11:04:17', '14.99.170.167', 'admin'),
(277, 'admin', '2013-12-31 13:33:11', '0000-00-00 00:00:00', '7214bb2c6c9192ea21aebd6eb0a4f5ed', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 13:33:11', '117.217.184.161', 'admin'),
(278, 'admin', '2013-12-31 13:33:12', '0000-00-00 00:00:00', 'cda636fc4afed633d47b86ba3d729ec0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 13:33:12', '117.217.184.161', 'admin'),
(279, 'admin', '2013-12-31 13:41:08', '2013-12-31 15:34:22', 'f53ea845ece56f0a9dc3c0683a9d2287', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 13:41:08', '14.96.9.8', 'admin'),
(280, 'admin', '2013-12-31 14:47:24', '2013-12-31 15:09:57', '41c67ab49e18febe5986f7f46680b7ef', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 14:47:24', '14.96.9.8', 'admin'),
(281, 'admin', '2013-12-31 15:10:12', '0000-00-00 00:00:00', '43b1a1429ebdec71a5ccabda875d03df', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 15:10:12', '14.96.9.8', 'admin'),
(282, 'admin', '2013-12-31 15:34:32', '2013-12-31 15:44:34', 'e4661298b4033686f10e0f7c524e80a7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 15:34:32', '14.96.9.8', 'admin');
INSERT INTO `details_login` (`auto_number`, `username`, `logintime`, `logouttime`, `sessionid`, `openingcash`, `closingcash`, `sales`, `expenses`, `deposit`, `withdrawal`, `cashmrc`, `salesreturn`, `customercollection`, `supplierpayment`, `useropeningcash`, `userclosingcash`, `usersales`, `userexpenses`, `userdeposit`, `userwithdrawal`, `usercashmrc`, `usersalesreturn`, `usercustomercollection`, `usersupplierpayment`, `remarks`, `rs1000`, `rs500`, `rs100`, `rs50`, `rs20`, `rs10`, `rs5`, `rs2`, `rs1`, `rscoins`, `denominationtotal`, `lastupdate`, `lastupdateipaddress`, `lastupdateusername`) VALUES
(283, 'admin', '2013-12-31 15:44:49', '2013-12-31 16:10:06', 'a8a3f9fdfa891ff0d165dbe4797558db', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 15:44:49', '14.96.9.8', 'admin'),
(284, 'admin', '2013-12-31 16:10:18', '2013-12-31 17:04:57', '542de8c1554df69da9c67793e538acd2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 16:10:18', '14.96.9.8', 'admin'),
(285, 'admin', '2013-12-31 17:05:06', '2013-12-31 18:54:52', 'f3bb85af0c0c3d28a0d815d53dd998e7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 17:05:06', '14.96.9.8', 'admin'),
(286, 'admin', '2013-12-31 17:10:24', '0000-00-00 00:00:00', 'd294b0c5317cb8d2374522b7532186d3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 17:10:24', '117.217.184.161', 'admin'),
(287, 'admin', '2013-12-31 18:55:05', '2013-12-31 18:57:02', 'dc33033e8a29af28a9f3e3ff97a67b5e', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 18:55:05', '14.96.9.8', 'admin'),
(288, 'admin', '2013-12-31 18:57:11', '0000-00-00 00:00:00', 'ae467845bdfb07af4ab6b59d34cb73df', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 18:57:11', '14.96.9.8', 'admin'),
(289, 'admin', '2013-12-31 19:26:15', '0000-00-00 00:00:00', 'e1aac8e1941a5e4d10cc5abeecda583b', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2013-12-31 19:26:15', '14.99.150.90', 'admin'),
(290, 'admin', '2014-01-02 09:19:45', '2014-01-02 10:32:45', '0b541a4e87babc22b54a07d62b988cb7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-02 09:19:45', '117.193.188.246', 'admin'),
(291, 'admin', '2014-01-02 10:33:02', '2014-01-02 10:47:27', '1bd60d62cd3462ff0d1435075ec33ca2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-02 10:33:02', '117.217.184.114', 'admin'),
(292, 'admin', '2014-01-02 10:47:43', '0000-00-00 00:00:00', '1c667441040ea771b1f272c9a34db6e8', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-02 10:47:43', '117.217.184.114', 'admin'),
(293, 'admin', '2014-01-02 12:04:51', '2014-01-02 12:06:03', '60f63d49bf7257728534beac7fc2c41c', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-02 12:04:51', '14.96.249.232', 'admin'),
(294, 'admin', '2014-01-02 12:05:39', '0000-00-00 00:00:00', 'f59d850be649ffe88ff087f83e79bb03', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-02 12:05:39', '117.217.184.114', 'admin'),
(295, 'admin', '2014-01-02 12:06:30', '2014-01-02 12:09:56', 'fa68be1276b3abe0b069fe4ee5ecca34', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-02 12:06:30', '14.96.249.232', 'admin'),
(296, 'admin', '2014-01-02 12:10:04', '2014-01-02 12:29:41', '4040d2d4a23b23a2dbf1d60cf9a515e1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-02 12:10:04', '14.96.249.232', 'admin'),
(297, 'admin', '2014-01-02 12:29:54', '0000-00-00 00:00:00', '47b16f5d26887e77126314a06aff191e', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-02 12:29:54', '14.96.249.232', 'admin'),
(298, 'admin', '2014-01-02 15:04:19', '0000-00-00 00:00:00', '02fe5d3c04a1af722fb18c756fee1c94', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-02 15:04:19', '117.193.185.61', 'admin'),
(299, 'admin', '2014-01-02 15:48:01', '2014-01-02 15:50:24', 'bde6b49de50a822ae51db25d8299458b', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-02 15:48:01', '14.99.138.18', 'admin'),
(300, 'admin', '2014-01-02 15:51:04', '0000-00-00 00:00:00', '7bc3013ee3af7440ef4dc6ebf45f6b59', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-02 15:51:04', '14.99.138.18', 'admin'),
(301, 'admin', '2014-01-02 19:41:21', '0000-00-00 00:00:00', '69bc957b569e03aed3d0658d8a8967f1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-02 19:41:21', '14.99.160.174', 'admin'),
(302, 'admin', '2014-01-03 10:23:58', '2014-01-03 10:28:54', '089071923017c887392886f04c7f8d5c', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-03 10:23:58', '14.99.70.215', 'admin'),
(303, 'admin', '2014-01-03 10:29:17', '0000-00-00 00:00:00', 'aea3bbd48011c284a8beec64abe6f134', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-03 10:29:17', '14.99.70.215', 'admin'),
(304, 'admin', '2014-01-03 10:43:37', '0000-00-00 00:00:00', '6b3bcca7f46ffedcac7b57bb052895a9', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-03 10:43:37', '117.193.183.0', 'admin'),
(305, 'admin', '2014-01-03 12:40:48', '0000-00-00 00:00:00', '45369b89f8f5dc6dd0194ede96c7631b', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-03 12:40:48', '14.99.0.151', 'admin'),
(306, 'admin', '2014-01-03 16:44:00', '2014-01-03 17:03:57', 'e1770e959967b5fed4b810d15214011e', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-03 16:44:00', '14.96.49.136', 'admin'),
(307, 'admin', '2014-01-03 17:04:04', '2014-01-03 17:11:59', 'd0a8cc48da4792537803bcdafe8dd746', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-03 17:04:04', '14.96.49.136', 'admin'),
(308, 'admin', '2014-01-03 17:12:07', '0000-00-00 00:00:00', 'b4128d06ed741f47f86023208f15358a', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-03 17:12:07', '14.96.49.136', 'admin'),
(309, 'admin', '2014-01-04 09:53:09', '0000-00-00 00:00:00', '7485c57cc7dcc4daaecdee763c5e5467', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-04 09:53:09', '117.193.167.63', 'admin'),
(310, 'admin', '2014-01-04 10:52:17', '0000-00-00 00:00:00', '767e1c9348eda1b4ca8a68601d53acd8', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-04 10:52:17', '14.96.48.234', 'admin'),
(311, 'admin', '2014-01-04 11:28:54', '0000-00-00 00:00:00', '93fd5d4540be21c60485569e02651dc8', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-04 11:28:54', '117.193.167.63', 'admin'),
(312, 'ADMIN', '2014-01-04 12:17:29', '0000-00-00 00:00:00', 'eeb29584d93f9337d6d3ddac7781ed6d', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-04 12:17:29', '117.193.167.63', 'ADMIN'),
(313, 'admin', '2014-01-04 16:21:33', '2014-01-04 16:35:08', 'h4up3uaegmuk0srpa38n2p5l53', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-04 16:21:33', '127.0.0.1', 'admin'),
(314, 'admin', '2014-01-06 10:28:46', '2014-01-06 10:29:48', 'v791iim3rek6gegi5ojilngut7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-06 10:28:46', '127.0.0.1', 'admin'),
(315, 'admin', '2014-01-06 15:11:59', '2014-01-06 16:13:46', '50ihaca165olnj9l30rj54ls20', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-06 15:11:59', '127.0.0.1', 'admin'),
(316, 'admin', '2014-01-07 14:40:53', '2014-01-07 15:13:30', 'qiacf54qko1f8i60hg4pr12fj2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-07 14:40:53', '127.0.0.1', 'admin'),
(317, 'admin', '2014-01-08 14:59:29', '2014-01-08 14:59:45', 'ccpjj2jhg3rcep2un0ct33g9f5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-08 14:59:29', '127.0.0.1', 'admin'),
(318, 'admin', '2014-01-08 16:03:32', '2014-01-08 16:04:04', '3u05bd2b4c1ma8196a82ce6k86', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-08 16:03:32', '127.0.0.1', 'admin'),
(319, 'admin', '2014-01-09 14:49:49', '2014-01-09 18:18:03', 'c9rv8uq65r777o3qddqemn2jp7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-09 14:49:49', '127.0.0.1', 'admin'),
(320, 'admin', '2014-01-11 12:34:47', '0000-00-00 00:00:00', 'p7r7af6ni304rvjkvqn576sac2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-11 12:34:47', '127.0.0.1', 'admin'),
(321, 'admin', '2014-01-11 12:38:01', '2014-01-11 12:38:35', '27ovm5l2t1vopa53p3fbo7dfd4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-11 12:38:01', '127.0.0.1', 'admin'),
(322, 'admin', '2014-01-16 11:13:38', '0000-00-00 00:00:00', 'houa3aahsa0vfv87mn18pg2b62', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-16 11:13:38', '192.168.1.14', 'admin'),
(323, 'admin', '2014-01-16 11:15:59', '0000-00-00 00:00:00', '3v19o92e08591269hnnt0abub5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-16 11:15:59', '192.168.1.14', 'admin'),
(324, 'admin', '2014-01-16 14:39:36', '0000-00-00 00:00:00', '296m5o9rtoi5p8ikf4f80800r6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-16 14:39:36', '192.168.1.14', 'admin'),
(325, 'admin', '2014-01-16 16:03:20', '0000-00-00 00:00:00', '4dq6m7cikslfobb4tuttj0h374', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-16 16:03:20', '192.168.1.14', 'admin'),
(326, 'admin', '2014-01-17 17:32:35', '2014-01-17 19:08:32', 'sivd8ausgmto2ubvr514s549a6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-17 17:32:35', 'fe80::e012:d88b:cc5b:1dc1', 'admin'),
(327, 'admin', '2014-01-22 12:39:32', '0000-00-00 00:00:00', 'jjduu1picmp2gm01dvtuksu5g2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-22 12:39:32', 'fe80::e012:d88b:cc5b:1dc1', 'admin'),
(328, 'admin', '2014-01-30 16:46:58', '0000-00-00 00:00:00', 'vomlf456opjpcno53vmd40lv24', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-01-30 16:46:58', 'fe80::e012:d88b:cc5b:1dc1', 'admin'),
(329, 'admin', '2014-02-12 19:51:37', '0000-00-00 00:00:00', 'gkqh27hgm8m4jb1unq0cjfq5o7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-02-12 19:51:37', '192.168.1.34', 'admin'),
(330, 'admin', '2014-02-14 11:44:38', '0000-00-00 00:00:00', 'gbdfn4a8r49r1addpgclv8dpn1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-02-14 11:44:38', 'fe80::e012:d88b:cc5b:1dc1', 'admin'),
(331, 'admin', '2014-02-14 11:44:38', '0000-00-00 00:00:00', 't9gl6jg3f8dkeo7a0s8re50n71', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-02-14 11:44:38', 'fe80::e012:d88b:cc5b:1dc1', 'admin'),
(332, 'admin', '2014-02-18 13:53:35', '2014-02-18 13:54:22', '5vceegmlc3g5o51ms8pcte4gk7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-02-18 13:53:35', '192.168.1.14', 'admin'),
(333, 'admin', '2014-02-19 19:02:57', '0000-00-00 00:00:00', 'd3h3qtl9okcv2bf84an4u9k4u5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-02-19 19:02:57', 'fe80::e012:d88b:cc5b:1dc1', 'admin'),
(334, 'admin', '2014-04-01 16:05:43', '2014-04-01 16:44:43', 'jq6o6i7k2fq3am0dtagm1oab07', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-01 16:05:43', '127.0.0.1', 'admin'),
(335, 'admin', '2014-04-01 16:51:57', '2014-04-01 16:52:34', 'qhihe5deb7veepivtp203dpit0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-01 16:51:57', '127.0.0.1', 'admin'),
(336, 'admin', '2014-04-04 13:41:01', '0000-00-00 00:00:00', '1u8jk1efkbh8uvjmgo4mjj2557', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-04 13:41:01', '192.168.1.36', 'admin'),
(337, 'admin', '2014-04-05 10:39:22', '2014-04-05 10:46:17', 'svcqd401leifeifg501m3j7os3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-05 10:39:22', '127.0.0.1', 'admin'),
(338, 'admin', '2014-04-09 17:04:59', '2014-04-09 18:16:38', 'dda79rbpg3mcbausp25piu0el2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-09 17:04:59', '127.0.0.1', 'admin'),
(339, 'admin', '2014-04-10 10:21:07', '0000-00-00 00:00:00', '7sk2fp09459tlcv4ico1te0d77', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-10 10:21:07', '127.0.0.1', 'admin'),
(340, 'admin', '2014-04-10 12:00:20', '2014-04-10 12:08:31', '7t0cqpaco16mdcjmdq4s66hu51', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-10 12:00:20', '127.0.0.1', 'admin'),
(341, 'admin', '2014-04-16 15:45:59', '0000-00-00 00:00:00', 'h58c8vbba73g2pq7trm550p4n6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-16 15:45:59', '192.168.1.14', 'admin'),
(342, 'admin', '2014-04-16 18:04:47', '0000-00-00 00:00:00', 'ei2u3br92etkqko3a2nb4enpc5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-16 18:04:47', '192.168.1.14', 'admin'),
(343, 'admin', '2014-04-16 18:19:09', '2014-04-16 19:08:16', 'uc8k24pk6avh7mf6m9plub6pd1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-16 18:19:09', '192.168.1.14', 'admin'),
(344, 'admin', '2014-04-17 10:11:02', '0000-00-00 00:00:00', '23ghpq3cj6couijjoa2t3b6jg4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-17 10:11:02', '192.168.1.14', 'admin'),
(345, 'admin', '2014-04-17 10:20:00', '0000-00-00 00:00:00', 'qm3oa0tvmprfubjfjbkbboqqo4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-17 10:20:00', '192.168.1.14', 'admin'),
(346, 'admin', '2014-04-17 11:04:24', '2014-04-17 12:28:16', 'hojscm4vpfi6ub88q4t0d293r3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-17 11:04:24', '192.168.1.14', 'admin'),
(347, 'admin', '2014-04-17 16:11:54', '0000-00-00 00:00:00', '0khtm58mcrehor636kfsqq3n62', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-17 16:11:54', '192.168.1.14', 'admin'),
(348, 'admin', '2014-04-17 16:27:23', '0000-00-00 00:00:00', '8js1rehrjdmj5jhisrv6ohavj4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-17 16:27:23', '192.168.1.14', 'admin'),
(349, 'admin', '2014-04-17 16:45:12', '0000-00-00 00:00:00', 'enqh0t710mtucobs5tl9f6nm31', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-17 16:45:12', '192.168.1.14', 'admin'),
(350, 'admin', '2014-04-17 17:05:55', '0000-00-00 00:00:00', '3d2asp3cev0ocj31oug2bflau7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-17 17:05:55', '192.168.1.14', 'admin'),
(351, 'admin', '2014-04-17 17:13:57', '2014-04-17 17:14:25', 'gmn6msgf3t4vku270vob4qbhc5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-17 17:13:57', '192.168.1.14', 'admin'),
(352, 'admin', '2014-04-17 17:19:59', '2014-04-17 17:23:36', '3hf4lri9pb0594jtriaun5huq6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-17 17:19:59', '192.168.1.14', 'admin'),
(353, 'admin', '2014-04-17 18:06:15', '0000-00-00 00:00:00', 't5s0vg3rk0qd6o02sr1ftn8566', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-17 18:06:15', '192.168.1.14', 'admin'),
(354, 'admin', '2014-04-18 09:53:54', '0000-00-00 00:00:00', 'kvdriauk07359r2anqqkpo0un1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-18 09:53:54', '192.168.1.14', 'admin'),
(355, 'admin', '2014-04-18 10:28:51', '0000-00-00 00:00:00', 'tuk0nkkjfsb0mon48na5q1j651', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-18 10:28:51', '192.168.1.14', 'admin'),
(356, 'admin', '2014-04-18 18:20:30', '0000-00-00 00:00:00', '0007pakcnu8n5g083hsfaju9a1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-18 18:20:30', '192.168.1.14', 'admin'),
(357, 'admin', '2014-04-21 16:53:45', '0000-00-00 00:00:00', '699mhf1qacc4tnbp79pdmgl544', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-21 16:53:45', '192.168.1.14', 'admin'),
(358, 'admin', '2014-04-25 10:51:35', '2014-04-25 10:54:12', 'k9c2nu0rl9bnme1e55ehm8luv0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-25 10:51:35', '192.168.1.14', 'admin'),
(359, 'admin', '2014-04-25 19:04:37', '2014-04-25 19:05:48', '5in0g6jk0rrapaer8idlgpatt7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-25 19:04:37', '127.0.0.1', 'admin'),
(360, 'admin', '2014-04-30 14:40:21', '0000-00-00 00:00:00', 'mtag8a1th2nolvj6nrrjs2cga7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-30 14:40:21', '192.168.1.14', 'admin'),
(361, 'admin', '2014-04-30 14:55:18', '2014-04-30 15:05:27', 'p7b99olbrum2pt59hmhu27vv90', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-04-30 14:55:18', '192.168.1.14', 'admin'),
(362, 'admin', '2014-05-05 14:15:37', '0000-00-00 00:00:00', 'k52epida9a5qf6i6oc682tonk5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-05 14:15:37', '192.168.1.14', 'admin'),
(363, 'admin', '2014-05-05 14:25:22', '0000-00-00 00:00:00', 'jc98ke855hnk1pjj9ro0ah2bd1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-05 14:25:22', '192.168.1.14', 'admin'),
(364, 'admin', '2014-05-05 14:32:40', '0000-00-00 00:00:00', '3brh0cd7mjc8u7ii5vbn430t70', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-05 14:32:40', '192.168.1.14', 'admin'),
(365, 'admin', '2014-05-05 14:50:32', '0000-00-00 00:00:00', 'hqe97mkfuj1asmmddhjinr8h46', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-05 14:50:32', '192.168.1.14', 'admin'),
(366, 'admin', '2014-05-05 16:42:14', '0000-00-00 00:00:00', 'a6pbdcrrm5ta1alq34pu389un3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-05 16:42:14', '192.168.1.14', 'admin'),
(367, 'admin', '2014-05-06 15:33:08', '0000-00-00 00:00:00', 'j396m93r4i3hmied85tt9kdoj6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-06 15:33:08', '192.168.1.14', 'admin'),
(368, 'admin', '2014-05-06 18:02:20', '0000-00-00 00:00:00', 'n305ftl3smuios8kplc1qsu7q1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-06 18:02:20', '192.168.1.14', 'admin'),
(369, 'admin', '2014-05-06 18:04:43', '0000-00-00 00:00:00', 'nimshc9r5c8lhr6ugh7rl5esm6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-06 18:04:43', '192.168.1.14', 'admin'),
(370, 'admin', '2014-05-06 18:35:35', '0000-00-00 00:00:00', 'gl62m0qthnq403m4kbiv9jnaf6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-06 18:35:35', '192.168.1.14', 'admin'),
(371, 'admin', '2014-05-06 18:46:18', '0000-00-00 00:00:00', 'vo24v5hnh76nq93gvtca1ccg57', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-06 18:46:18', '192.168.1.14', 'admin'),
(372, 'admin', '2014-05-06 18:54:09', '2014-05-06 19:10:27', 'b6lsc1n2b2h0p8us1i4g04f6h4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-06 18:54:09', '192.168.1.14', 'admin'),
(373, 'admin', '2014-05-12 10:50:50', '0000-00-00 00:00:00', '1hetv3s8k8ttt3aohcvt4nu7p5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-12 10:50:50', '192.168.1.14', 'admin'),
(374, 'admin', '2014-05-12 11:01:20', '0000-00-00 00:00:00', 'l5djb4smodkqo2ha8crmpn3ai7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-12 11:01:20', '192.168.1.14', 'admin'),
(375, 'admin', '2014-05-12 11:04:14', '0000-00-00 00:00:00', 'mgb5hlhon8kq02c4r8kpeugqv1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-12 11:04:14', '192.168.1.14', 'admin'),
(376, 'admin', '2014-05-12 12:11:49', '2014-05-12 12:23:28', '975fbsf7hlc3qq30b4bit5b0o7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-12 12:11:49', '192.168.1.14', 'admin'),
(377, 'admin', '2014-05-12 12:35:34', '2014-05-12 12:36:04', 'ts5ccg3im0ekj5rf9gr74nhud1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-12 12:35:34', '192.168.1.14', 'admin'),
(378, 'admin', '2014-05-12 14:05:19', '2014-05-12 15:26:08', 'l1poaqgd1si7l3pijmval5s703', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-12 14:05:19', '192.168.1.14', 'admin'),
(379, 'admin', '2014-05-12 15:36:11', '0000-00-00 00:00:00', 'mf6tarkdvj6ocrgbl83sf68kr4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-12 15:36:11', '192.168.1.14', 'admin'),
(380, 'admin', '2014-05-12 15:39:40', '0000-00-00 00:00:00', 'eq51j6ogiajrs7m2ede5j7j2k2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-12 15:39:40', '192.168.1.14', 'admin'),
(381, 'admin', '2014-05-12 15:54:41', '0000-00-00 00:00:00', '50go4j27j9u1bbc7cult08ql41', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-12 15:54:41', '192.168.1.14', 'admin'),
(382, 'admin', '2014-05-13 12:56:56', '0000-00-00 00:00:00', '9bkncafnmaah7v13tbukorsff7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-13 12:56:56', '192.168.1.14', 'admin'),
(383, 'admin', '2014-05-13 13:41:40', '0000-00-00 00:00:00', 'tprujk1henapepu8dcghs5q7n7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-13 13:41:40', '192.168.1.14', 'admin'),
(384, 'admin', '2014-05-13 14:59:26', '0000-00-00 00:00:00', '4dopsgjf4ilknev4440ch2eeh1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-13 14:59:26', '192.168.1.14', 'admin'),
(385, 'admin', '2014-05-14 11:30:18', '0000-00-00 00:00:00', '43rc9snv0fmip3glps4kdlirm5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-14 11:30:18', '192.168.1.14', 'admin'),
(386, 'admin', '2014-05-16 10:26:54', '0000-00-00 00:00:00', 'tot1gmt20tve6i1j5m5n67p6e6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-16 10:26:54', '192.168.1.14', 'admin'),
(387, 'admin', '2014-05-16 11:24:37', '2014-05-16 11:25:56', 'cil93mk3gl0d4ma85ss2vs0fu2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-16 11:24:37', '192.168.1.14', 'admin'),
(388, 'admin', '2014-05-16 11:26:02', '2014-05-16 11:34:05', '7kj48emvrctlql3j4srk7gmfo4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-16 11:26:02', '192.168.1.14', 'admin'),
(389, 'admin', '2014-05-17 13:32:29', '0000-00-00 00:00:00', 'a0nfjrtdcco75128rfcak7ohu6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-17 13:32:29', '192.168.1.14', 'admin'),
(390, 'admin', '2014-05-17 13:36:54', '0000-00-00 00:00:00', 'vjocvk0vgmla1ek9ag2aiamo80', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-17 13:36:54', '192.168.1.14', 'admin'),
(391, 'admin', '2014-05-17 16:33:35', '0000-00-00 00:00:00', 'js9ukvaedcbtrpfhsp3ahjutv0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-17 16:33:35', '192.168.1.14', 'admin'),
(392, 'admin', '2014-05-19 10:35:35', '0000-00-00 00:00:00', 'v8b4p573g2rlbs8lhuo2ga43e1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-19 10:35:35', '192.168.1.14', 'admin'),
(393, 'admin', '2014-05-19 11:56:02', '0000-00-00 00:00:00', 'mdkd9brgj011600l94rpa6m6q1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-19 11:56:02', '192.168.1.14', 'admin'),
(394, 'admin', '2014-05-19 12:12:44', '0000-00-00 00:00:00', 'scp1vo3oudhhe64ul1nia2uei3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-19 12:12:44', '192.168.1.14', 'admin'),
(395, 'admin', '2014-05-19 12:35:03', '0000-00-00 00:00:00', 'ffsta3jntetb5lie0adnkvfbh1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-19 12:35:03', '192.168.1.14', 'admin'),
(396, 'admin', '2014-05-19 15:32:05', '0000-00-00 00:00:00', 'i3puigo5h0knm31j4ckd7uj7v7', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-19 15:32:05', '192.168.1.14', 'admin'),
(397, 'admin', '2014-05-19 18:48:20', '0000-00-00 00:00:00', 'l8j4otv4k0ofi0575khipa3mi0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-05-19 18:48:20', '192.168.1.14', 'admin'),
(398, 'admin', '2014-06-03 12:34:29', '0000-00-00 00:00:00', 'qefombgvo7cr88u9uev6vee2s6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-06-03 12:34:29', '192.168.1.14', 'admin'),
(399, 'admin', '2014-06-13 12:49:04', '0000-00-00 00:00:00', 'io8frhugek1gvl62r4m51pvid2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-06-13 12:49:04', '192.168.1.14', 'admin'),
(400, 'admin', '2014-06-18 14:13:58', '0000-00-00 00:00:00', '5b2d2jaalkqs9m8ka0otddpn91', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-06-18 14:13:58', '192.168.1.14', 'admin'),
(401, 'admin', '2014-06-18 14:18:46', '0000-00-00 00:00:00', 'cvhe7s3j2d0h1anp59vfa32jt3', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-06-18 14:18:46', '192.168.1.14', 'admin'),
(402, 'admin', '2014-06-18 14:34:44', '0000-00-00 00:00:00', 'uue3354c7sgkm0l9d67crt5un2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-06-18 14:34:44', '192.168.1.14', 'admin'),
(403, 'admin', '2014-06-18 15:18:32', '0000-00-00 00:00:00', 'o1jt8pf1qmb17876is0jtkalu2', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-06-18 15:18:32', '192.168.1.14', 'admin'),
(404, 'admin', '2014-06-19 17:14:12', '2014-06-19 17:14:15', '9cljtpiseb5snfk4fe8vnr2ne4', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-06-19 17:14:12', '192.168.1.14', 'admin'),
(405, 'admin', '2014-06-19 17:14:21', '0000-00-00 00:00:00', 'sa0kd1adtvhe0d8v5ldhnulfo6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-06-19 17:14:21', '192.168.1.14', 'admin'),
(406, 'admin', '2014-06-23 16:35:56', '0000-00-00 00:00:00', 'guj52qlq2c9p44gec4mun1h8e6', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-06-23 16:35:56', '192.168.1.14', 'admin'),
(407, 'admin', '2014-09-23 18:15:40', '0000-00-00 00:00:00', '2ti52j25aa9u2d7cpdamf773v5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-09-23 18:15:40', '127.0.0.1', 'admin'),
(408, 'admin', '2014-09-25 18:13:37', '0000-00-00 00:00:00', 'ml144j6dhqp7kcu45a1ff997f1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-09-25 18:13:37', '127.0.0.1', 'admin'),
(409, 'admin', '2014-09-28 20:36:04', '0000-00-00 00:00:00', 'ar0hrnt89a32u7fj2b0holt6c1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-09-28 20:36:04', '127.0.0.1', 'admin'),
(410, 'admin', '2014-10-05 11:44:07', '2014-10-05 11:46:07', '98c71av9obh81gebopqbcpvnt1', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-10-05 11:44:07', '127.0.0.1', 'admin'),
(411, 'admin', '2014-10-06 13:30:48', '0000-00-00 00:00:00', 'vuk48rf2l4kuc9unrrjb8tq765', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-10-06 13:30:48', '127.0.0.1', 'admin'),
(412, 'admin', '2014-10-06 15:18:04', '0000-00-00 00:00:00', 's5nsd8794gpf4gg3peb6a7efa5', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00', '0.00', '2014-10-06 15:18:04', '127.0.0.1', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `details_teachertimetable`
--

CREATE TABLE `details_teachertimetable` (
  `auto_number` int(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `teacher` varchar(255) NOT NULL,
  `totaldays` int(255) NOT NULL,
  `totalsessions` int(255) NOT NULL,
  `zeroperiod` varchar(255) NOT NULL,
  `weekdays` varchar(255) NOT NULL,
  `classreference` varchar(255) NOT NULL,
  `session0` text NOT NULL,
  `session1` text NOT NULL,
  `session2` text NOT NULL,
  `session3` text NOT NULL,
  `session4` text NOT NULL,
  `session5` text NOT NULL,
  `session6` text NOT NULL,
  `session7` text NOT NULL,
  `session8` text NOT NULL,
  `session9` text NOT NULL,
  `session10` text NOT NULL,
  `session11` text NOT NULL,
  `session12` text NOT NULL,
  `session13` text NOT NULL,
  `session14` text NOT NULL,
  `session15` text NOT NULL,
  `session16` text NOT NULL,
  `session17` text NOT NULL,
  `session18` text NOT NULL,
  `session19` text NOT NULL,
  `session20` text NOT NULL,
  `session21` text NOT NULL,
  `session22` text NOT NULL,
  `session23` text NOT NULL,
  `session24` text NOT NULL,
  `session25` text NOT NULL,
  `recordstatus` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedate` datetime NOT NULL,
  `username` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details_teachertimetable`
--

INSERT INTO `details_teachertimetable` (`auto_number`, `academicyear`, `teacher`, `totaldays`, `totalsessions`, `zeroperiod`, `weekdays`, `classreference`, `session0`, `session1`, `session2`, `session3`, `session4`, `session5`, `session6`, `session7`, `session8`, `session9`, `session10`, `session11`, `session12`, `session13`, `session14`, `session15`, `session16`, `session17`, `session18`, `session19`, `session20`, `session21`, `session22`, `session23`, `session24`, `session25`, `recordstatus`, `ipaddress`, `updatedate`, `username`) VALUES
(110, '2014', 'Naveen', 5, 11, 'yes', 'TUE', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(107, '2014', 'Arundhati', 5, 11, 'yes', 'MON', 'NURA', '', 'ENGLISH ||NURA', 'ENGLISH ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(96, '2014', 'RAVI KUMAR ', 5, 11, 'yes', 'THU', 'LKGA', '', '', '', 'MATHS ||LKGA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(95, '2014', 'Nikitha', 5, 11, 'yes', 'THU', 'LKGA', '', '', '', 'MATHS ||LKGA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(106, '2014', 'Venkatesan ', 5, 11, 'yes', 'TUE', '1A', '', '', '', '', '', '', 'SCIENCE ||1A', 'SCIENCE ||1A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(105, '2014', 'Saberi', 5, 11, 'yes', 'TUE', '1A', '', '', '', '', '', '', 'SCIENCE ||1A', 'SCIENCE ||1A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(104, '2014', 'Ritu', 5, 11, 'yes', 'TUE', '1A', '', '', '', '', '', '', 'SCIENCE ||1A', 'SCIENCE ||1A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(94, '2014', 'Naveen', 5, 11, 'yes', 'THU', 'LKGA', '', '', '', 'MATHS ||LKGA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(93, '2014', 'RAVI KUMAR ', 5, 11, 'yes', 'WED', 'LKGA', '', '', '', 'MATHS ||LKGA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(92, '2014', 'Nikitha', 5, 11, 'yes', 'WED', 'LKGA', '', '', '', 'MATHS ||LKGA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(91, '2014', 'Naveen', 5, 11, 'yes', 'WED', 'LKGA', '', '', '', 'MATHS ||LKGA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(86, '2014', 'Nikitha', 5, 11, 'yes', 'MON', 'LKGA', '', '', '', 'MATHS ||LKGA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(85, '2014', 'Naveen', 5, 11, 'yes', 'MON', 'LKGA', '', '', '', 'MATHS ||LKGA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(84, '2014', 'Vasudevan ', 5, 11, 'yes', 'TUE', 'NURC', '', '', 'PHYSICS ||NURC', 'PHYSICS ||NURC', 'PHYSICS ||NURC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:37:47', 'admin'),
(90, '2014', 'RAVI KUMAR ', 5, 11, 'yes', 'TUE', 'LKGA', '', '', '', 'MATHS ||LKGA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(89, '2014', 'Nikitha', 5, 11, 'yes', 'TUE', 'LKGA', '', '', '', 'MATHS ||LKGA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(88, '2014', 'Naveen', 5, 11, 'yes', 'TUE', 'LKGA', '', '', '', 'MATHS ||LKGA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(87, '2014', 'RAVI KUMAR ', 5, 11, 'yes', 'MON', 'LKGA', '', '', '', 'MATHS ||LKGA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:44:03', 'admin'),
(83, '2014', 'Sreedevi', 5, 11, 'yes', 'TUE', 'NURC', '', '', 'PHYSICS ||NURC', 'PHYSICS ||NURC', 'PHYSICS ||NURC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:37:47', 'admin'),
(82, '2014', 'Sivanesan', 5, 11, 'yes', 'TUE', 'NURC', '', '', 'PHYSICS ||NURC', 'PHYSICS ||NURC', 'PHYSICS ||NURC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:37:47', 'admin'),
(81, '2014', 'RAVI KUMAR ', 5, 11, 'yes', 'MON', 'NURC', '', 'MATHS ||NURC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:37:47', 'admin'),
(80, '2014', 'Nikitha', 5, 11, 'yes', 'MON', 'NURC', '', 'MATHS ||NURC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:37:47', 'admin'),
(102, '2014', 'Florance', 5, 11, 'yes', 'TUE', '1A', '', '', '', '', '', '', 'SCIENCE ||1A', 'SCIENCE ||1A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(101, '2014', 'Deborah', 5, 11, 'yes', 'TUE', '1A', '', '', '', '', '', '', 'SCIENCE ||1A', 'SCIENCE ||1A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(99, '2014', 'Bharath ', 5, 11, 'yes', 'TUE', '1A', '', '', '', '', 'PHYSICS ||1A', 'PHYSICS ||1A', 'SCIENCE ||1A', 'SCIENCE ||1A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(79, '2014', 'Naveen', 5, 11, 'yes', 'MON', 'NURC', '', 'MATHS ||NURC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:37:47', 'admin'),
(103, '2014', 'Krishnan', 5, 11, 'yes', 'TUE', '1A', '', '', '', '', '', '', 'SCIENCE ||1A', 'SCIENCE ||1A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(100, '2014', 'Arundhati', 5, 11, 'yes', 'TUE', '1A', '', '', '', '', '', '', 'SCIENCE ||1A', 'SCIENCE ||1A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(98, '2014', 'Beena', 5, 11, 'yes', 'TUE', '1A', '', '', '', '', 'PHYSICS ||1A', 'PHYSICS ||1A', 'SCIENCE ||1A', 'SCIENCE ||1A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 15:00:47', 'admin'),
(97, '2014', 'Venkatesan ', 5, 11, 'yes', 'MON', 'LKGB', '', 'ENGLISH ||LKGB', 'ENGLISH ||LKGB', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 13:50:25', 'admin'),
(118, '2014', 'RAVI KUMAR ', 5, 11, 'yes', 'THU', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(117, '2014', 'Nikitha', 5, 11, 'yes', 'THU', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(116, '2014', 'Naveen', 5, 11, 'yes', 'THU', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(115, '2014', 'Vasudevan ', 5, 11, 'yes', 'WED', 'NURA', '', 'PHYSICS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(114, '2014', 'Sreedevi', 5, 11, 'yes', 'WED', 'NURA', '', 'PHYSICS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(113, '2014', 'Sivanesan', 5, 11, 'yes', 'WED', 'NURA', '', 'PHYSICS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(112, '2014', 'RAVI KUMAR ', 5, 11, 'yes', 'TUE', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(111, '2014', 'Nikitha', 5, 11, 'yes', 'TUE', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(109, '2014', 'Bharath ', 5, 11, 'yes', 'MON', 'NURA', '', 'ENGLISH ||NURA', 'ENGLISH ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(108, '2014', 'Beena', 5, 11, 'yes', 'MON', 'NURA', '', 'ENGLISH ||NURA', 'ENGLISH ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-02 20:17:31', 'admin'),
(55, '2014', 'Arundhati', 5, 11, 'yes', 'MON', 'NURA', '', 'ENGLISH ||NURA', 'ENGLISH ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(56, '2014', 'Beena', 5, 11, 'yes', 'MON', 'NURA', '', 'ENGLISH ||NURA', 'ENGLISH ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(57, '2014', 'Bharath ', 5, 11, 'yes', 'MON', 'NURA', '', 'ENGLISH ||NURA', 'ENGLISH ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(58, '2014', 'Naveen', 5, 11, 'yes', 'TUE', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(59, '2014', 'Nikitha', 5, 11, 'yes', 'TUE', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(60, '2014', 'RAVI KUMAR ', 5, 11, 'yes', 'TUE', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(61, '2014', 'Sivanesan', 5, 11, 'yes', 'WED', 'NURA', '', 'PHYSICS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(62, '2014', 'Sreedevi', 5, 11, 'yes', 'WED', 'NURA', '', 'PHYSICS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(63, '2014', 'Vasudevan ', 5, 11, 'yes', 'WED', 'NURA', '', 'PHYSICS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(64, '2014', 'Naveen', 5, 11, 'yes', 'THU', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(65, '2014', 'Nikitha', 5, 11, 'yes', 'THU', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(66, '2014', 'RAVI KUMAR ', 5, 11, 'yes', 'THU', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(67, '2014', 'Naveen', 5, 11, 'yes', 'FRI', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(68, '2014', 'Nikitha', 5, 11, 'yes', 'FRI', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(69, '2014', 'RAVI KUMAR ', 5, 11, 'yes', 'FRI', 'NURA', '', 'MATHS ||NURA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DELETED', '127.0.0.1', '2014-10-01 11:26:52', 'admin'),
(70, '2014', 'Naveen', 5, 11, 'yes', 'MON', 'NURB', '', '', 'MATHS ||NURB', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin'),
(71, '2014', 'Nikitha', 5, 11, 'yes', 'MON', 'NURB', '', '', 'MATHS ||NURB', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin'),
(72, '2014', 'RAVI KUMAR ', 5, 11, 'yes', 'MON', 'NURB', '', '', 'MATHS ||NURB', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin'),
(73, '2014', 'Sivanesan', 5, 11, 'yes', 'WED', 'NURB', '', '', 'PHYSICS ||NURB', 'PHYSICS ||NURB', 'PHYSICS ||NURB', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin'),
(74, '2014', 'Sreedevi', 5, 11, 'yes', 'WED', 'NURB', '', '', 'PHYSICS ||NURB', 'PHYSICS ||NURB', 'PHYSICS ||NURB', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin'),
(75, '2014', 'Vasudevan ', 5, 11, 'yes', 'WED', 'NURB', '', '', 'PHYSICS ||NURB', 'PHYSICS ||NURB', 'PHYSICS ||NURB', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin'),
(76, '2014', 'Arundhati', 5, 11, 'yes', 'THU', 'NURB', '', '', 'ENGLISH ||NURB', 'ENGLISH ||NURB', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin'),
(77, '2014', 'Beena', 5, 11, 'yes', 'THU', 'NURB', '', '', 'ENGLISH ||NURB', 'ENGLISH ||NURB', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin'),
(78, '2014', 'Bharath ', 5, 11, 'yes', 'THU', 'NURB', '', '', 'ENGLISH ||NURB', 'ENGLISH ||NURB', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 11:30:10', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `details_timetable`
--

CREATE TABLE `details_timetable` (
  `auto_number` int(255) NOT NULL,
  `timetableanum` int(255) NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchyear` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchsection` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `daynumber` int(255) NOT NULL,
  `sessionnumber` int(255) NOT NULL,
  `starttimehour` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `starttimeminute` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `endtimehour` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `endtimeminute` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `classname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `department` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `staffid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `staff` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subject` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `details_transport`
--

CREATE TABLE `details_transport` (
  `auto_number` int(255) NOT NULL,
  `transportnumber` varchar(255) NOT NULL,
  `admissionnumber` varchar(255) NOT NULL,
  `rollnumber` varchar(255) NOT NULL,
  `studentcode` varchar(255) NOT NULL,
  `studentname` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `studentmobile` varchar(255) NOT NULL,
  `studentemail` varchar(255) NOT NULL,
  `routeanum` int(255) NOT NULL,
  `routename` varchar(255) NOT NULL,
  `pointanum` int(255) NOT NULL,
  `pointname` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details_transport`
--

INSERT INTO `details_transport` (`auto_number`, `transportnumber`, `admissionnumber`, `rollnumber`, `studentcode`, `studentname`, `class`, `section`, `gender`, `dob`, `studentmobile`, `studentemail`, `routeanum`, `routename`, `pointanum`, `pointname`, `status`, `ipaddress`, `username`, `updatedatetime`) VALUES
(1, 'TRN/2014-15/1002', 'ADM/2014-15/1004', '', 'STU00000005', 'Bharath  ', 'LKG', '', 'male', '2004-09-04', '9952722542', '', 5, 'ROUTE 3', 17, 'Mambalam', '', '127.0.0.1', 'admin', '2014-10-12 11:49:50'),
(2, 'TRN/2014-15/1003', 'ADM/2014-15/1007', '', 'STU00000008', 'Taman  ', '7', 'A', 'male', '2001-10-10', '', '', 5, 'ROUTE 3', 17, 'Mambalam', '', '127.0.0.1', 'admin', '2014-10-13 10:53:40');

-- --------------------------------------------------------

--
-- Table structure for table `examtocourse`
--

CREATE TABLE `examtocourse` (
  `auto_number` int(255) NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `examtocourse`
--

INSERT INTO `examtocourse` (`auto_number`, `exam`, `course`, `ipaddress`, `updatedate`, `updatedby`, `status`) VALUES
(1, 'SEMESTER I', 'INFORMATION TECHNOLGOY', '192.168.1.15', '2009-05-23 18:34:28', 'admin', ''),
(2, 'SEMESTER II', 'INFORMATION TECHNOLGOY', '192.168.1.15', '2009-05-23 18:45:50', 'admin', ''),
(3, 'SEMESTER III', 'INFORMATION TECHNOLGOY', '192.168.1.15', '2009-05-23 18:45:54', 'admin', ''),
(4, 'SEMESTER IV', 'INFORMATION TECHNOLGOY', '192.168.1.15', '2009-05-23 18:45:59', 'admin', ''),
(5, 'SEMESTER V', 'INFORMATION TECHNOLGOY', '192.168.1.15', '2009-05-23 18:46:02', 'admin', ''),
(6, 'SEMESTER VI', 'INFORMATION TECHNOLGOY', '192.168.1.15', '2009-05-23 18:46:05', 'admin', ''),
(7, 'SEMESTER VII', 'INFORMATION TECHNOLGOY', '192.168.1.15', '2009-05-23 18:46:08', 'admin', ''),
(8, 'SEMESTER VIII', 'INFORMATION TECHNOLGOY', '192.168.1.15', '2009-05-23 18:46:10', 'admin', ''),
(9, 'SEMESTER I', 'COMPUTER SCIENCE', '192.168.1.15', '2009-05-23 20:50:51', 'admin', ''),
(10, 'SEMESTER I', 'CIVIL ENGINEERING', '122.174.119.126', '2012-08-07 16:03:23', 'admin', ''),
(11, '<? echo $exam; ?>', '', '192.168.1.5', '2017-10-23 14:06:09', 'admin', '');

-- --------------------------------------------------------

--
-- Table structure for table `feeheadmapping`
--

CREATE TABLE `feeheadmapping` (
  `auto_number` int(255) NOT NULL,
  `feeheadanum` int(255) NOT NULL,
  `feehead` varchar(255) NOT NULL,
  `feesubheadanum` int(255) NOT NULL,
  `feesubhead` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feeheadmapping`
--

INSERT INTO `feeheadmapping` (`auto_number`, `feeheadanum`, `feehead`, `feesubheadanum`, `feesubhead`, `status`, `ipaddress`, `username`, `updatedatetime`) VALUES
(1, 1, 'NEW ADMISSION FEE', 1, 'BUILDING FEE', '', '192.168.1.9', 'admin', '2017-10-20 11:43:18'),
(2, 1, 'NEW ADMISSION FEE', 2, 'TUTION FEE', '', '192.168.1.9', 'admin', '2017-10-20 11:43:18'),
(3, 1, 'NEW ADMISSION FEE', 3, 'UNIFORM FEE', '', '192.168.1.9', 'admin', '2017-10-20 11:43:18'),
(4, 1, 'NEW ADMISSION FEE', 4, 'BOOK FEES', '', '192.168.1.9', 'admin', '2017-10-20 11:43:18'),
(5, 1, 'NEW ADMISSION FEE', 6, 'HOSTEL DEPOSIT', '', '192.168.1.9', 'admin', '2017-10-20 11:43:18'),
(6, 2, 'FIRST TERM FEE', 1, 'BUILDING FEE', 'deleted', '192.168.1.9', 'admin', '2017-10-20 11:43:38'),
(7, 2, 'FIRST TERM FEE', 2, 'TUTION FEE', '', '192.168.1.9', 'admin', '2017-10-20 11:43:38'),
(8, 2, 'FIRST TERM FEE', 5, 'EXAM FEES', '', '192.168.1.9', 'admin', '2017-10-20 11:43:38'),
(9, 3, 'SECOND TERM FEE', 1, 'BUILDING FEE', 'deleted', '192.168.1.9', 'admin', '2017-10-20 11:43:50'),
(10, 3, 'SECOND TERM FEE', 2, 'TUTION FEE', '', '192.168.1.9', 'admin', '2017-10-20 11:43:50'),
(11, 4, 'THIRD TERM FEE', 1, 'BUILDING FEE', 'deleted', '192.168.1.9', 'admin', '2017-10-20 11:43:56'),
(12, 4, 'THIRD TERM FEE', 2, 'TUTION FEE', '', '192.168.1.9', 'admin', '2017-10-20 11:43:56'),
(13, 5, 'FOURTH TERM FEE', 1, 'BUILDING FEE', 'deleted', '192.168.1.9', 'admin', '2017-10-20 11:44:02'),
(14, 5, 'FOURTH TERM FEE', 2, 'TUTION FEE', '', '192.168.1.9', 'admin', '2017-10-20 11:44:02'),
(15, 3, 'SECOND TERM FEE', 5, 'EXAM FEES', '', '192.168.1.25', 'admin', '2017-10-31 11:44:56'),
(16, 4, 'THIRD TERM FEE', 5, 'EXAM FEES', '', '192.168.1.25', 'admin', '2017-10-31 11:45:02'),
(17, 5, 'FOURTH TERM FEE', 5, 'EXAM FEES', '', '192.168.1.25', 'admin', '2017-10-31 11:45:07');

-- --------------------------------------------------------

--
-- Table structure for table `feespayment`
--

CREATE TABLE `feespayment` (
  `auto_number` int(255) NOT NULL,
  `studentid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `courseanum` int(255) NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `examanum` int(255) NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchyear` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchsection` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `feestocourseanum` int(255) NOT NULL,
  `feesanum` int(255) NOT NULL,
  `fees` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `amount` decimal(13,2) NOT NULL,
  `feesstatus` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `feesdate` date NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `feespayment`
--

INSERT INTO `feespayment` (`auto_number`, `studentid`, `studentname`, `courseanum`, `course`, `examanum`, `exam`, `batchyear`, `batchsection`, `feestocourseanum`, `feesanum`, `fees`, `amount`, `feesstatus`, `feesdate`, `updatedby`, `updatedate`, `ipaddress`) VALUES
(6, 'STD4', 'Vijay', 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', '2009', 'SECTION A', 8, 1, 'TUITION FEES', '12000.00', 'PAID', '2009-05-28', 'admin', '2009-05-28 15:28:28', '192.168.1.15'),
(5, 'STD1', 'Prem', 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', '2008', 'SECTION A', 7, 3, 'LAB FEES', '1500.00', 'PAID', '2009-05-28', 'admin', '2009-05-28 15:24:04', '192.168.1.15'),
(4, 'STD1', 'Prem', 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', '2008', 'SECTION A', 8, 1, 'TUITION FEES', '12000.00', 'PAID', '2009-05-28', 'admin', '2009-05-28 15:22:31', '192.168.1.15'),
(7, 'STD8', 'Sowmiya', 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', '2009', 'SECTION A', 6, 4, 'EXAM FEES', '1200.00', 'PAID', '2009-06-09', 'admin', '2009-06-09 17:59:34', '192.168.1.15'),
(8, 'STD8', 'Sowmiya', 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', '2009', 'SECTION A', 7, 3, 'LAB FEES', '1500.00', 'PAID', '2009-06-09', 'admin', '2009-06-09 18:01:51', '192.168.1.15'),
(9, 'STD8', 'Sowmiya', 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', '2009', 'SECTION A', 4, 6, 'BUILDING FUND', '7000.00', 'PAID', '2009-08-15', 'admin', '2009-08-15 13:06:49', '122.164.160.119'),
(10, 'STD8', 'Sowmiya', 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', '2009', 'SECTION A', 5, 5, 'BUS FEES', '500.00', 'PAID', '2014-07-23', 'admin', '2014-07-23 15:43:55', '127.0.0.1'),
(11, 'STD8', 'Sowmiya', 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', '2009', 'SECTION A', 8, 1, 'TUITION FEES', '12000.00', 'PAID', '2014-07-23', 'admin', '2014-07-23 15:43:55', '127.0.0.1'),
(12, 'STD13', 'Aravind K', 3, 'CIVIL ENGINEERING', 1, 'SEMESTER I', '2014', 'B1', 15, 6, 'BUILDING FUND', '7000.00', 'PAID', '2014-07-29', 'admin', '2014-07-29 16:55:28', '27.6.148.72'),
(13, 'STD10', 'Ravi Kumar', 3, 'CIVIL ENGINEERING', 1, 'SEMESTER I', '2014', 'SECTION A', 15, 6, 'BUILDING FUND', '7000.00', 'PAID', '2014-09-16', 'admin', '2014-09-16 18:13:23', '115.98.112.238'),
(14, 'STD10', 'Ravi Kumar', 3, 'CIVIL ENGINEERING', 1, 'SEMESTER I', '2014', 'SECTION A', 16, 1, 'TUITION FEES', '12000.00', 'PAID', '2014-09-16', 'admin', '2014-09-16 18:13:23', '115.98.112.238');

-- --------------------------------------------------------

--
-- Table structure for table `feestocourse`
--

CREATE TABLE `feestocourse` (
  `auto_number` int(255) NOT NULL,
  `courseanum` int(255) NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `examanum` int(255) NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `feesanum` int(255) NOT NULL,
  `fees` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `amount` decimal(13,2) NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `feestocourse`
--

INSERT INTO `feestocourse` (`auto_number`, `courseanum`, `course`, `examanum`, `exam`, `feesanum`, `fees`, `amount`, `status`, `updatedby`, `updatedate`, `ipaddress`) VALUES
(6, 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', 4, 'EXAM FEES', '1200.00', '', 'admin', '2009-05-28 13:16:17', '192.168.1.15'),
(5, 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', 5, 'BUS FEES', '500.00', '', 'admin', '2009-05-28 13:15:23', '192.168.1.15'),
(4, 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', 6, 'BUILDING FUND', '7050.00', '', 'admin', '2009-05-28 13:14:50', '192.168.1.15'),
(7, 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', 3, 'LAB FEES', '1500.00', '', 'admin', '2009-05-28 13:16:26', '192.168.1.15'),
(8, 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', 1, 'TUITION FEES', '12000.00', '', 'admin', '2009-05-28 13:16:46', '192.168.1.15'),
(9, 1, 'INFORMATION TECHNOLGOY', 2, 'SEMESTER II', 4, 'EXAM FEES', '1200.00', '', 'admin', '2009-05-28 13:17:23', '192.168.1.15'),
(10, 1, 'INFORMATION TECHNOLGOY', 2, 'SEMESTER II', 1, 'TUITION FEES', '12000.00', '', 'admin', '2009-05-28 13:17:36', '192.168.1.15'),
(11, 1, 'INFORMATION TECHNOLGOY', 2, 'SEMESTER II', 3, 'LAB FEES', '1500.00', '', 'admin', '2009-05-28 13:17:50', '192.168.1.15'),
(12, 1, 'INFORMATION TECHNOLGOY', 3, 'SEMESTER III', 4, 'EXAM FEES', '1200.00', '', 'admin', '2009-05-28 13:18:09', '192.168.1.15'),
(13, 1, 'INFORMATION TECHNOLGOY', 3, 'SEMESTER III', 2, 'LIBRARY FEES', '450.00', '', 'admin', '2009-05-28 13:18:16', '192.168.1.15'),
(14, 1, 'INFORMATION TECHNOLGOY', 1, 'SEMESTER I', 12, 'LATE FEES', '100.00', '', 'admin', '2014-07-23 16:32:56', '127.0.0.1'),
(15, 3, 'CIVIL ENGINEERING', 1, 'SEMESTER I', 6, 'BUILDING FUND', '7000.00', '', 'admin', '2014-07-29 16:40:49', '27.6.148.72'),
(16, 3, 'CIVIL ENGINEERING', 1, 'SEMESTER I', 1, 'TUITION FEES', '12000.00', '', 'admin', '2014-09-16 18:12:33', '115.98.112.238');

-- --------------------------------------------------------

--
-- Table structure for table `hostelallotment`
--

CREATE TABLE `hostelallotment` (
  `auto_number` int(255) NOT NULL,
  `hostelnumber` varchar(255) NOT NULL,
  `admissionnumber` varchar(255) NOT NULL,
  `rollnumber` varchar(255) NOT NULL,
  `studentcode` varchar(255) NOT NULL,
  `studentname` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(255) NOT NULL,
  `doj` date NOT NULL,
  `studentmobile` varchar(255) NOT NULL,
  `studentemail` varchar(255) NOT NULL,
  `fathername` varchar(255) NOT NULL,
  `fathermobile` varchar(255) NOT NULL,
  `fatheremail` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `contactname` varchar(255) NOT NULL,
  `relationship` varchar(255) NOT NULL,
  `contactmobile` varchar(255) NOT NULL,
  `contactaddress` text NOT NULL,
  `bedanum` int(255) NOT NULL,
  `bednumber` varchar(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hostelallotment`
--

INSERT INTO `hostelallotment` (`auto_number`, `hostelnumber`, `admissionnumber`, `rollnumber`, `studentcode`, `studentname`, `class`, `section`, `dob`, `gender`, `doj`, `studentmobile`, `studentemail`, `fathername`, `fathermobile`, `fatheremail`, `address`, `city`, `state`, `pincode`, `country`, `contactname`, `relationship`, `contactmobile`, `contactaddress`, `bedanum`, `bednumber`, `academicyear`, `ipaddress`, `username`, `updatedatetime`, `status`) VALUES
(4, 'HSL/2014-15/1000', 'ADM/2014-15/1005', '', 'STU00000006', 'Raja  ', '9', 'G', '2014-10-13', 'male', '2014-10-11', '9442144768', 'raja@gmail.com', 'Krishna', '9443245789', 'kri@gmail.com', '1st street', 'namakkal', 'Tamil nadu', '600002', 'India', 'ghfhgfg', 'ghfhf', 'hgfghfhg', 'hgfghfhgfh', 15, 'SB-001', '2014-15', '127.0.0.1', 'admin', '2014-10-11 20:18:33', 'Active'),
(5, 'HSL/2014-15/1001', 'ADM/2014-15/1005', '', 'STU00000006', 'Raja  ', '9', 'G', '2014-10-13', 'male', '2014-10-11', '9442144768', 'raja@gmail.com', 'Krishna', '9443245789', 'kri@gmail.com', '1st street', 'namakkal', 'Tamil nadu', '600002', 'India', '', '', '', '', 17, 'SB-002', '2014-15', '127.0.0.1', 'admin', '2014-10-11 20:20:46', 'Active'),
(6, 'HSL/2014-15/1002', 'ADM/2014-15/1005', '', 'STU00000006', 'Raja  ', '9', 'G', '2014-10-13', 'male', '2014-10-11', '9442144768', 'raja@gmail.com', 'Krishna', '9443245789', 'kri@gmail.com', '1st street', 'namakkal', 'Tamil nadu', '600002', 'India', '', '', '', '', 16, 'SB-001', '2014-15', '127.0.0.1', 'admin', '2014-10-11 20:27:32', 'Active'),
(7, 'HSL/2014-15/1003', 'ADM/2014-15/1008', '', 'STU00000009', 'Naresh  ', '8', 'B', '2001-10-19', 'male', '2014-10-13', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 18, 'SB-002', '2014-15', '127.0.0.1', 'admin', '2014-10-13 10:55:35', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `login_restriction`
--

CREATE TABLE `login_restriction` (
  `auto_number` int(255) NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `logintime` datetime NOT NULL,
  `logouttime` datetime NOT NULL,
  `sessionid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdate` datetime NOT NULL,
  `lastupdateipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdateusername` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `login_restriction`
--

INSERT INTO `login_restriction` (`auto_number`, `username`, `logintime`, `logouttime`, `sessionid`, `lastupdate`, `lastupdateipaddress`, `lastupdateusername`) VALUES
(412, 'admin', '2014-10-06 15:18:04', '0000-00-00 00:00:00', 's5nsd8794gpf4gg3peb6a7efa5', '2014-10-06 15:18:04', '127.0.0.1', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `master_academicyear`
--

CREATE TABLE `master_academicyear` (
  `auto_number` int(255) NOT NULL,
  `academicfromdate` varchar(255) NOT NULL,
  `academicfrommonth` varchar(255) NOT NULL,
  `academicfromyear` varchar(255) NOT NULL,
  `academictodate` varchar(255) NOT NULL,
  `academictomonth` varchar(255) NOT NULL,
  `academictoyear` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(225) NOT NULL,
  `recorddate` varchar(225) NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `master_academicyear2`
--

CREATE TABLE `master_academicyear2` (
  `auto_number` int(15) NOT NULL,
  `academicyear` varchar(225) NOT NULL,
  `academicfromyear` varchar(255) NOT NULL,
  `academictoyear` varchar(255) NOT NULL,
  `academicfrommonth` varchar(255) NOT NULL,
  `academictomonth` varchar(225) NOT NULL,
  `status` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_academicyear2`
--

INSERT INTO `master_academicyear2` (`auto_number`, `academicyear`, `academicfromyear`, `academictoyear`, `academicfrommonth`, `academictomonth`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, '2010-11(SSC)', '06/06/2017', '03/14/2018', 'Jun-2017', 'Mar-2018', '', '2017-10-31 ', '2017-10-31 16:53:16', 'admin', '::1', 'HYD', 'LOC-1'),
(2, '2011-15(CBSE)', '06/22/2017', '05/17/2018', 'Jun-2017', 'May-2018', '', '2017-10-31 ', '2017-10-31 16:53:54', 'admin', '::1', 'HYD', 'LOC-1'),
(3, '2017-18(SCH)', '06/01/2017', '05/31/2018', 'Jun-2017', 'May-2018', '', '2017-11-01 ', '2017-11-01 10:18:36', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(4, '2017-18(COL)', '08/01/2017', '07/31/2018', 'Aug-2017', 'Jul-2018', '', '2017-11-01 ', '2017-11-01 10:18:57', 'admin', '192.168.1.8', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_accesspermission`
--

CREATE TABLE `master_accesspermission` (
  `auto_number` int(255) NOT NULL,
  `designation_autonumber` int(255) NOT NULL,
  `designation` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `module_autonumber` int(255) NOT NULL,
  `module` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `hyperlink_autonumber` int(255) NOT NULL,
  `hyplerlink` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_accesspermission`
--

INSERT INTO `master_accesspermission` (`auto_number`, `designation_autonumber`, `designation`, `module_autonumber`, `module`, `hyperlink_autonumber`, `hyplerlink`, `updatedate`, `ipaddress`) VALUES
(116, 20, 'Administrator', 7, 'Time Table', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(3, 9, 'Principal', 11, 'Administration', 0, '', '2009-05-16 14:30:44', '192.168.1.15'),
(4, 9, 'Principal', 1, 'Applications', 0, '', '2009-05-16 14:30:44', '192.168.1.15'),
(5, 9, 'Principal', 9, 'Class', 0, '', '2009-05-16 14:30:44', '192.168.1.15'),
(6, 9, 'Principal', 6, 'Exams', 0, '', '2009-05-16 14:30:44', '192.168.1.15'),
(7, 9, 'Principal', 4, 'Library', 0, '', '2009-05-16 14:30:44', '192.168.1.15'),
(8, 9, 'Principal', 13, 'Masters', 0, '', '2009-05-16 14:30:44', '192.168.1.15'),
(115, 20, 'Administrator', 2, 'Student', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(113, 20, 'Administrator', 3, 'Staff', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(114, 20, 'Administrator', 15, 'Staff Login', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(112, 20, 'Administrator', 10, 'Payroll', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(111, 20, 'Administrator', 13, 'Masters', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(110, 20, 'Administrator', 4, 'Library', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(109, 20, 'Administrator', 5, 'Inventory', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(108, 20, 'Administrator', 12, 'Fees', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(107, 20, 'Administrator', 6, 'Exams', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(106, 20, 'Administrator', 9, 'Class', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(105, 20, 'Administrator', 14, 'Branch', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(104, 20, 'Administrator', 8, 'Attendance', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(102, 20, 'Administrator', 11, 'Administration', 0, '', '2009-05-16 16:27:30', '192.168.1.15'),
(103, 20, 'Administrator', 1, 'Applications', 0, '', '2009-05-16 16:27:30', '192.168.1.15');

-- --------------------------------------------------------

--
-- Table structure for table `master_adddocs`
--

CREATE TABLE `master_adddocs` (
  `auto_number` int(255) NOT NULL,
  `documenttype` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_adddocs`
--

INSERT INTO `master_adddocs` (`auto_number`, `documenttype`, `username`, `status`, `ipaddress`, `locationname`, `locationcode`, `updatedatetime`, `recorddate`) VALUES
(1, 'Birth Certificate', 'admin', '', '192.168.1.21', 'HYD', 'LOC-1', '2017-10-11 12:35:31', '2017-10-11'),
(2, 'Bonafide Certificate', 'admin', '', '192.168.1.21', 'HYD', 'LOC-1', '2017-10-11 12:36:16', '2017-10-11'),
(3, 'Transfer Certificate', 'admin', '', '192.168.1.21', 'HYD', 'LOC-1', '2017-10-11 12:36:26', '2017-10-11');

-- --------------------------------------------------------

--
-- Table structure for table `master_admissiontype`
--

CREATE TABLE `master_admissiontype` (
  `auto_number` int(15) NOT NULL,
  `admissiontype` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_admissiontype`
--

INSERT INTO `master_admissiontype` (`auto_number`, `admissiontype`, `status`) VALUES
(1, 'GENERAL QUOTA', ''),
(2, 'MANAGEMENT QUOTA', ''),
(3, 'GOVERMENT QUOTA', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_applicationamount`
--

CREATE TABLE `master_applicationamount` (
  `auto_number` int(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `amount` decimal(13,2) NOT NULL,
  `status` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_applicationamount`
--

INSERT INTO `master_applicationamount` (`auto_number`, `class`, `amount`, `status`, `username`, `ipaddress`, `updatedatetime`) VALUES
(1, 'nursery', '100.00', 'deleted', 'admin', '127.0.0.1', '2014-09-28 18:02:08'),
(2, 'lkg', '150.00', '', 'admin', '127.0.0.1', '2014-09-28 18:02:14'),
(3, 'ukg', '150.00', '', 'admin', '127.0.0.1', '2014-09-28 18:02:18'),
(4, '1', '200.00', '', 'admin', '127.0.0.1', '2014-09-28 18:02:23'),
(5, '2', '200.00', '', 'admin', '127.0.0.1', '2014-09-28 18:02:28'),
(6, '3', '200.00', '', 'admin', '127.0.0.1', '2014-09-28 18:02:33'),
(7, '4', '200.00', '', 'admin', '127.0.0.1', '2014-09-28 18:02:39'),
(8, '5', '200.00', '', 'admin', '127.0.0.1', '2014-09-28 18:02:44'),
(9, '6', '250.00', '', 'admin', '127.0.0.1', '2014-09-28 18:02:49'),
(10, '7', '250.00', '', 'admin', '127.0.0.1', '2014-09-28 18:02:53'),
(11, '8', '250.00', '', 'admin', '127.0.0.1', '2014-09-28 18:03:01'),
(12, '9', '300.00', '', 'admin', '127.0.0.1', '2014-09-28 18:03:07'),
(13, '10', '300.00', '', 'admin', '127.0.0.1', '2014-09-28 18:03:13'),
(14, '11', '400.00', '', 'admin', '127.0.0.1', '2014-09-28 18:03:19'),
(15, '12', '400.00', '', 'admin', '127.0.0.1', '2014-09-28 18:03:24'),
(16, 'others', '500.00', 'deleted', 'admin', '127.0.0.1', '2014-09-28 18:03:30'),
(17, 'Nursery', '100.00', '', 'admin', '127.0.0.1', '2014-10-07 10:48:20');

-- --------------------------------------------------------

--
-- Table structure for table `master_application_issued`
--

CREATE TABLE `master_application_issued` (
  `auto_number` int(255) NOT NULL,
  `applicationnumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `enquirynumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `enquirydate` date NOT NULL,
  `branch` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `admissionforclass` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `gender` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `dob` date NOT NULL,
  `studentmobile` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentemail` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `category` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `transport` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fathername` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fathermobile` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fatheremail` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `issuedate` date NOT NULL,
  `issuedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `amount` decimal(13,2) NOT NULL,
  `paymentmode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `bankname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ddnumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `dddate` date NOT NULL,
  `totalamount` decimal(13,2) NOT NULL,
  `extracharge` decimal(13,2) NOT NULL,
  `extraactivities` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `academicyear` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `academicfrom` int(255) NOT NULL,
  `academicto` int(255) NOT NULL,
  `chequenumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `chequebankname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `chequedate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_application_issued`
--

INSERT INTO `master_application_issued` (`auto_number`, `applicationnumber`, `enquirynumber`, `enquirydate`, `branch`, `admissionforclass`, `studentname`, `gender`, `dob`, `studentmobile`, `studentemail`, `category`, `transport`, `fathername`, `fathermobile`, `fatheremail`, `issuedate`, `issuedby`, `amount`, `paymentmode`, `bankname`, `ddnumber`, `dddate`, `totalamount`, `extracharge`, `extraactivities`, `username`, `ipaddress`, `updatedate`, `academicyear`, `academicfrom`, `academicto`, `chequenumber`, `chequebankname`, `chequedate`) VALUES
(1, 'APP/2017-18/1000', 'ENQ/1000/2017-18', '2017-05-01', 'Neredmet', 'Nursery', 'Vignesh', 'male', '2016-10-03', '', '', 'Dayscholar', 'yes', 'Krishna', '9966275057', 'cskkrishna@gmail.com', '2017-05-11', 'admin', '100.00', 'Cash', '', '', '0000-00-00', '125.00', '25.00', '', 'admin', '192.168.1.21', '2017-10-11 11:21:16', '2017-18', 2017, 2018, '', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `master_application_received`
--

CREATE TABLE `master_application_received` (
  `auto_number` int(255) NOT NULL,
  `applicationnumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `receivedate` date NOT NULL,
  `receiveby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `interviewcalldate` date NOT NULL,
  `applicationstatus` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `enquirynumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `enquirydate` date NOT NULL,
  `branch` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `admissionforclass` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `section` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `gender` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `dob` date NOT NULL,
  `studentmobile` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentemail` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `category` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `transport` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fathername` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fathermobile` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fatheremail` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `correspondenceaddress` text COLLATE latin1_general_ci NOT NULL,
  `permanentaddress` text COLLATE latin1_general_ci NOT NULL,
  `issuedate` date NOT NULL,
  `issuedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `academicyear` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_application_received`
--

INSERT INTO `master_application_received` (`auto_number`, `applicationnumber`, `receivedate`, `receiveby`, `interviewcalldate`, `applicationstatus`, `enquirynumber`, `enquirydate`, `branch`, `admissionforclass`, `section`, `studentname`, `gender`, `dob`, `studentmobile`, `studentemail`, `category`, `transport`, `fathername`, `fathermobile`, `fatheremail`, `correspondenceaddress`, `permanentaddress`, `issuedate`, `issuedby`, `username`, `ipaddress`, `updatedate`, `academicyear`) VALUES
(1, 'APP/2017-18/1000 ', '2017-05-25', 'admin', '2017-05-26', 'selected', 'ENQ/1000/2017-18', '2017-05-01', 'Neredmet', 'Nursery', '', 'Vignesh', 'male', '2016-10-03', '', '', 'Dayscholar', 'yes', 'Krishna', '9966275057', 'cskkrishna@gmail.com', 'Flat No 304, Pakshi Raj Apts, Sainathapuram, Dr.A.S.Rao Nagar,\r\nsecbad - 062', 'Flat No 304, Pakshi Raj Apts, Sainathapuram, Dr.A.S.Rao Nagar,\r\nsecbad - 062', '2017-10-11', 'admin', 'admin', '192.168.1.21', '2017-10-11 11:32:19', '2017-18'),
(2, '', '2017-10-11', 'admin', '2017-10-18', '', '', '0000-00-00', '', 'ukg', '', 'aa', 'male', '2017-10-31', '', '', 'Dayscholar', 'yes', '', '', '', '', '', '0000-00-00', '', 'admin', '192.168.1.9', '2017-10-11 16:15:45', '2017-18');

-- --------------------------------------------------------

--
-- Table structure for table `master_application_received1`
--

CREATE TABLE `master_application_received1` (
  `auto_number` int(255) NOT NULL,
  `applicationnumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `receiveddate` datetime NOT NULL,
  `receivedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_attendance`
--

CREATE TABLE `master_attendance` (
  `auto_number` int(255) NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchyear` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchsection` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `daynumber` int(255) NOT NULL,
  `sessionnumber` int(255) NOT NULL,
  `attendancedate` date NOT NULL,
  `starttimehour` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `starttimeminute` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `endtimehour` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `endtimeminute` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `classname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `department` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subject` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `staffid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `staff` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_attendance`
--

INSERT INTO `master_attendance` (`auto_number`, `course`, `batchyear`, `exam`, `batchsection`, `daynumber`, `sessionnumber`, `attendancedate`, `starttimehour`, `starttimeminute`, `endtimehour`, `endtimeminute`, `classname`, `department`, `subject`, `staffid`, `staff`, `updatedby`, `updatedate`, `ipaddress`) VALUES
(14, 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 1, '2009-05-26', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF4', 'Sivanesan', 'admin', '2009-05-26 16:28:47', '192.168.1.15'),
(15, 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 1, '2009-06-07', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF4', 'Sivanesan', 'admin', '2009-06-07 19:06:59', '192.168.1.15'),
(16, 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 2, 1, '2009-06-07', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF3', 'Venkatesan', 'admin', '2009-06-07 19:07:32', '192.168.1.15'),
(17, 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 1, '2009-06-05', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF4', 'Sivanesan', 'admin', '2009-06-09 15:24:10', '192.168.1.15'),
(18, 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 2, 1, '2009-06-05', '01', '00', '01', '05', 'THEORY', 'INFORMATION TECHNOLOGY ', 'ELECTRONICS COMMERCE', 'STF3', 'Venkatesan', 'admin', '2009-06-09 15:24:26', '192.168.1.15'),
(19, 'INFORMATION TECHNOLGOY', '2009', 'SEMESTER I', 'SECTION A', 1, 2, '2009-06-05', '02', '10', '02', '15', '', '', '', '', '', 'admin', '2009-06-09 15:25:25', '192.168.1.15');

-- --------------------------------------------------------

--
-- Table structure for table `master_attendancestaff`
--

CREATE TABLE `master_attendancestaff` (
  `auto_number` int(255) NOT NULL,
  `departmentanum` int(255) NOT NULL,
  `department` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `attendancedate` date NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_attendancestaff`
--

INSERT INTO `master_attendancestaff` (`auto_number`, `departmentanum`, `department`, `attendancedate`, `updatedby`, `updatedate`, `ipaddress`) VALUES
(1, 15, 'INFORMATION TECHNOLOGY ', '2009-05-27', 'admin', '2009-05-27 18:16:46', '192.168.1.15'),
(2, 10, 'BIO-TECHNOLOGY ', '2012-03-05', 'admin', '2012-03-31 12:33:30', '59.92.74.105');

-- --------------------------------------------------------

--
-- Table structure for table `master_autonumber`
--

CREATE TABLE `master_autonumber` (
  `auto_number` int(255) NOT NULL,
  `modulename` varchar(255) NOT NULL,
  `prefix` varchar(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `startsfrom` varchar(255) NOT NULL,
  `format` int(255) NOT NULL,
  `preview` varchar(255) NOT NULL,
  `fromdate` date NOT NULL,
  `todate` date NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_autonumber`
--

INSERT INTO `master_autonumber` (`auto_number`, `modulename`, `prefix`, `academicyear`, `startsfrom`, `format`, `preview`, `fromdate`, `todate`, `status`, `ipaddress`, `updatedatetime`) VALUES
(33, 'Transport', 'TRN', '2017-18', '1000', 3, 'TRN/2017-18/1000', '2014-04-01', '2015-03-31', '', '127.0.0.1', '2017-10-11 05:43:21'),
(32, 'Hostel', 'HSL', '2017-18', '1000', 3, 'HSL/2017-18/1000', '2014-04-01', '2015-03-31', '', '127.0.0.1', '2017-10-11 05:43:28'),
(31, 'Fees', 'FEE', '2017-18', '1000', 3, 'FEE/2017-18/1000', '2014-04-01', '2015-03-31', '', '127.0.0.1', '2017-10-11 05:43:35'),
(36, 'Admission', 'ADM', '2015-16', '1000', 2, 'ADM/1000/2015-16', '2017-10-12', '2017-10-14', '', '::1', '2017-10-31 07:20:50'),
(28, 'Applications', 'APP', '2017-18', '1000', 3, 'APP/2017-18/1000', '2014-04-01', '2015-03-31', '', '127.0.0.1', '2017-10-11 05:43:53'),
(34, 'Enquiry', 'ENQ', '2017-18', '1000', 2, 'ENQ/1000/', '2017-10-01', '2018-10-01', '', '192.168.1.2', '2017-10-16 06:44:27');

-- --------------------------------------------------------

--
-- Table structure for table `master_batchsection`
--

CREATE TABLE `master_batchsection` (
  `auto_number` int(15) NOT NULL,
  `batchsection` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_batchsection`
--

INSERT INTO `master_batchsection` (`auto_number`, `batchsection`, `status`) VALUES
(4, 'SECTION B', ''),
(3, 'SECTION A', ''),
(5, 'SECTION C', ''),
(6, 'B1', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_block`
--

CREATE TABLE `master_block` (
  `auto_number` int(255) NOT NULL,
  `blockname` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_block`
--

INSERT INTO `master_block` (`auto_number`, `blockname`, `status`, `ipaddress`, `username`, `updatedatetime`, `locationname`, `locationcode`, `recorddate`) VALUES
(1, 'BLOCK1', 'deleted', '192.168.1.6', '', '2017-10-24 11:01:04', '', '', ''),
(2, 'BLOK2', 'deleted', '192.168.1.6', '', '2017-10-24 11:01:18', '', '', ''),
(3, '2BLOK2', '', '192.168.1.6', 'admin', '2017-10-24 11:16:12', '', '', ''),
(4, 'BLOCK1 2', 'deleted', '192.168.1.6', 'admin', '2017-10-24 11:19:19', 'HYD', 'LOC-1', '2017-10-24');

-- --------------------------------------------------------

--
-- Table structure for table `master_bloodgroup`
--

CREATE TABLE `master_bloodgroup` (
  `auto_number` int(255) NOT NULL,
  `bloodgroup` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_bloodgroup`
--

INSERT INTO `master_bloodgroup` (`auto_number`, `bloodgroup`, `status`, `username`, `ipaddress`, `recorddate`, `updatedatetime`, `locationname`, `locationcode`) VALUES
(1, 'A', '', 'admin', '192.168.1.7', '2017-10-16', '2017-10-16 11:30:35', 'HYD', 'LOC-1'),
(2, 'B', '', 'admin', '192.168.1.7', '2017-10-16', '2017-10-16 11:41:05', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_book`
--

CREATE TABLE `master_book` (
  `auto_number` int(255) NOT NULL,
  `bookname` text COLLATE latin1_general_ci NOT NULL,
  `bookcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `isbncode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `category` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subcategory` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `publishername` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `authorname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `price` decimal(13,2) NOT NULL,
  `stock` int(255) NOT NULL,
  `bookfor` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `remarks` text COLLATE latin1_general_ci NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_book`
--

INSERT INTO `master_book` (`auto_number`, `bookname`, `bookcode`, `isbncode`, `category`, `subcategory`, `publishername`, `authorname`, `price`, `stock`, `bookfor`, `status`, `remarks`, `updatedby`, `updatedate`, `ipaddress`) VALUES
(1, 'BOOK NAME', 'BKC00000006', '', '', '', 'PUBLISHER', 'AUTHOR', '100.00', 10, 'ISSUE', '', 'REMARKS', 'admin', '2009-05-31 20:19:19', '192.168.1.15'),
(2, 'ENGINEERING MATHEMATICS', 'BKC00000005', '', '', '', 'PUBLISHER', 'AUTHOR', '255.00', 20, 'ISSUE', '', 'REMARKS', 'admin', '2009-05-31 20:33:52', '192.168.1.15'),
(3, 'VISUAL BASIC .NET', 'BKC00000004', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER', 'AUTHOR', '650.00', 20, 'ISSUE', '', 'REMARKS', 'admin', '2009-05-31 20:57:27', '192.168.1.15'),
(4, 'PROGRAMMING FUNDAMENTALS2', 'BKC00000001', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER2', 'AUTHOR2', '6402.00', 1, 'ISSUE', '', 'REMARKS2', 'admin', '2009-05-31 21:53:17', '192.168.1.15'),
(7, 'FUNDAMENTALS OF COMPUTERS', 'BKC00000002', '', 'COMPUTER', 'SOFTWARE', 'ABC PUBLICATIONS', 'GEORGE', '500.00', 9, 'REFERENCE', '', '', 'admin', '2014-09-16 18:08:07', '115.98.112.238'),
(13, 'C BASICS', 'BKC00000003', 'ISBN4545', 'COMPUTER', 'PROGRAMMING', 'PUBLISHER', 'AUTHOR', '1500.00', 15, 'ISSUE', '', '', 'admin', '2014-10-30 11:09:35', '192.168.1.14');

-- --------------------------------------------------------

--
-- Table structure for table `master_bookcategory`
--

CREATE TABLE `master_bookcategory` (
  `auto_number` int(15) NOT NULL,
  `bookcategory` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_bookcategory`
--

INSERT INTO `master_bookcategory` (`auto_number`, `bookcategory`, `status`, `ipaddress`, `updatedatetime`) VALUES
(1, 'COMPUTER', 'deleted', '', '0000-00-00 00:00:00'),
(2, 'ENGINEERING', 'deleted', '', '0000-00-00 00:00:00'),
(3, 'LANGUAGE', 'deleted', '', '0000-00-00 00:00:00'),
(4, 'MANAGEMENT', 'deleted', '', '0000-00-00 00:00:00'),
(5, 'MATHS', 'deleted', '', '0000-00-00 00:00:00'),
(6, 'COMMERCE', 'deleted', '', '0000-00-00 00:00:00'),
(7, 'ECONOMICS', 'deleted', '', '0000-00-00 00:00:00'),
(11, 'COMMERCE', 'deleted', '127.0.0.1', '2014-10-02 18:03:26'),
(12, 'COMPUTER', 'deleted', '127.0.0.1', '2014-10-02 18:03:34'),
(13, 'COMMERCE', 'deleted', '127.0.0.1', '2014-10-02 18:07:00'),
(14, 'COMPUTER', 'deleted', '127.0.0.1', '2014-10-02 18:07:06'),
(15, 'ECONOMICS', 'deleted', '192.168.1.16', '2017-10-13 15:04:02'),
(16, 'SCIENCE', 'deleted', '192.168.1.16', '2017-10-13 15:28:29'),
(17, 'ENGLISH', 'deleted', '::1', '2017-10-13 15:57:07'),
(18, 'TELUGU', 'deleted', '192.168.1.16', '2017-10-13 15:57:28'),
(19, '1', '', '::1', '2017-10-13 17:04:44'),
(20, '2', '', '192.168.1.7', '2017-10-16 10:55:29'),
(21, 'ENGLISH', 'deleted', '::1', '2017-10-28 12:18:15');

-- --------------------------------------------------------

--
-- Table structure for table `master_bookissue`
--

CREATE TABLE `master_bookissue` (
  `auto_number` int(255) NOT NULL,
  `issueno` int(255) NOT NULL,
  `admissionnumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `rollnumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `class` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `section` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `issuedate` date NOT NULL,
  `issuedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `renewaldate` date NOT NULL,
  `renewalby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `returndate` date NOT NULL,
  `entryby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `bookname` text COLLATE latin1_general_ci NOT NULL,
  `bookcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `isbncode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `category` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subcategory` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `publishername` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `authorname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `price` decimal(13,2) NOT NULL,
  `quantity` int(255) NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `remarks` text COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_bookissue`
--

INSERT INTO `master_bookissue` (`auto_number`, `issueno`, `admissionnumber`, `rollnumber`, `studentcode`, `studentname`, `class`, `section`, `issuedate`, `issuedby`, `renewaldate`, `renewalby`, `returndate`, `entryby`, `bookname`, `bookcode`, `isbncode`, `category`, `subcategory`, `publishername`, `authorname`, `price`, `quantity`, `status`, `remarks`, `ipaddress`, `username`, `updatedatetime`) VALUES
(1, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'ENGINEERING MATHEMATICS', 'BKC00000005', '', '', '', 'PUBLISHER', 'AUTHOR', '255.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 15:45:28'),
(2, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'C BASICS', 'BKC00000003', 'ISBN4545', 'COMPUTER', 'PROGRAMMING', 'PUBLISHER', 'AUTHOR', '1500.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 15:45:28'),
(3, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'BOOK NAME', 'BKC00000006', '', '', '', 'PUBLISHER', 'AUTHOR', '100.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 15:45:28'),
(4, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'PROGRAMMING FUNDAMENTALS2', 'BKC00000001', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER2', 'AUTHOR2', '6402.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 15:45:28'),
(5, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'VISUAL BASIC .NET', 'BKC00000004', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER', 'AUTHOR', '650.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 15:45:28'),
(6, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-12-30', '', '2014-10-31', 'admin', 'C BASICS', 'BKC00000003', 'ISBN4545', 'COMPUTER', 'PROGRAMMING', 'PUBLISHER', 'AUTHOR', '1500.00', 1, 'RETURN', '', '192.168.1.14', 'admin', '2014-10-31 11:15:39'),
(7, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'VISUAL BASIC .NET', 'BKC00000004', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER', 'AUTHOR', '650.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:21:44'),
(8, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'VISUAL BASIC .NET', 'BKC00000004', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER', 'AUTHOR', '650.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:21:50'),
(9, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'VISUAL BASIC .NET', 'BKC00000004', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER', 'AUTHOR', '650.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:21:52'),
(10, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'VISUAL BASIC .NET', 'BKC00000004', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER', 'AUTHOR', '650.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:21:52'),
(11, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'VISUAL BASIC .NET', 'BKC00000004', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER', 'AUTHOR', '650.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:21:53'),
(12, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'VISUAL BASIC .NET', 'BKC00000004', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER', 'AUTHOR', '650.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:21:53'),
(13, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'VISUAL BASIC .NET', 'BKC00000004', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER', 'AUTHOR', '650.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:21:53'),
(14, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'VISUAL BASIC .NET', 'BKC00000004', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER', 'AUTHOR', '650.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:21:54'),
(15, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2015-08-27', '', '2014-10-31', 'admin', 'VISUAL BASIC .NET', 'BKC00000004', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER', 'AUTHOR', '650.00', 1, 'RETURN', '', '192.168.1.14', 'admin', '2014-10-31 11:21:54'),
(16, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'ENGINEERING MATHEMATICS', 'BKC00000005', '', '', '', 'PUBLISHER', 'AUTHOR', '255.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:22:06'),
(17, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'BOOK NAME', 'BKC00000006', '', '', '', 'PUBLISHER', 'AUTHOR', '100.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:22:07'),
(18, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'PROGRAMMING FUNDAMENTALS2', 'BKC00000001', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER2', 'AUTHOR2', '6402.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:22:08'),
(19, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'PROGRAMMING FUNDAMENTALS2', 'BKC00000001', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER2', 'AUTHOR2', '6402.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:24:10'),
(20, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'PROGRAMMING FUNDAMENTALS2', 'BKC00000001', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER2', 'AUTHOR2', '6402.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:25:10'),
(21, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'PROGRAMMING FUNDAMENTALS2', 'BKC00000001', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER2', 'AUTHOR2', '6402.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:25:15'),
(22, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2015-04-29', '', '0000-00-00', '', 'PROGRAMMING FUNDAMENTALS2', 'BKC00000001', '', 'COMPUTER', 'SOFTWARE', 'PUBLISHER2', 'AUTHOR2', '6402.00', 1, 'ISSUE', '', '192.168.1.14', 'admin', '2014-10-31 11:28:41'),
(23, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2014-10-31', 'admin', '0000-00-00', '', 'BOOK NAME', 'BKC00000006', '', '', '', 'PUBLISHER', 'AUTHOR', '100.00', 1, 'RENEWAL', '', '192.168.1.14', 'admin', '2014-10-31 11:28:45'),
(24, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2015-01-29', '', '0000-00-00', '', 'ENGINEERING MATHEMATICS', 'BKC00000005', '', '', '', 'PUBLISHER', 'AUTHOR', '255.00', 1, 'ISSUE', '', '192.168.1.14', 'admin', '2014-10-31 11:28:46'),
(25, 1, 'ADM/2014-15/1001', '12NUR32', 'STU00000002', 'Vasudevan  ', 'Nursery', 'A', '2014-10-31', 'admin', '2015-02-28', '', '0000-00-00', '', 'BOOK NAME', 'BKC00000006', '', '', '', 'PUBLISHER', 'AUTHOR', '100.00', 1, 'ISSUE', '', '192.168.1.14', 'admin', '2014-10-31 12:44:56');

-- --------------------------------------------------------

--
-- Table structure for table `master_booksubcategory`
--

CREATE TABLE `master_booksubcategory` (
  `auto_number` int(255) NOT NULL,
  `booksubcategory` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `category` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_booksubcategory`
--

INSERT INTO `master_booksubcategory` (`auto_number`, `booksubcategory`, `category`, `status`) VALUES
(1, 'HARDWARE', 'COMPUTER', 'deleted'),
(2, 'SOFTWARE', 'COMPUTER', ''),
(3, 'CIVIL', 'ENGINEERING', 'deleted'),
(4, 'MECHANICAL', 'ENGINEERING', ''),
(5, 'ELECTRONICS', 'ENGINEERING', ''),
(6, 'HUMAN RESOURCES', 'MANAGEMENT', ''),
(7, 'INFORMATION SYSTEMS', 'MANAGEMENT', ''),
(8, 'PROGRAMMING', 'COMPUTER', ''),
(9, 'SOFTWARE ', 'ECONOMICS', 'deleted');

-- --------------------------------------------------------

--
-- Table structure for table `master_caste`
--

CREATE TABLE `master_caste` (
  `auto_number` int(15) NOT NULL,
  `caste` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_caste`
--

INSERT INTO `master_caste` (`auto_number`, `caste`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, 'SC', '', '2017-10-30 ', '2017-10-30 13:17:12', 'admin', '::1', 'HYD', 'LOC-1'),
(2, 'ST', '', '2017-10-30 ', '2017-10-30 13:17:21', 'admin', '::1', 'HYD', 'LOC-1'),
(3, 'OBC', '', '2017-10-30 ', '2017-10-30 13:17:26', 'admin', '::1', 'HYD', 'LOC-1'),
(4, 'OC', '', '2017-10-30 ', '2017-10-30 13:17:39', 'admin', '::1', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_city`
--

CREATE TABLE `master_city` (
  `auto_number` int(15) NOT NULL,
  `city` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_city`
--

INSERT INTO `master_city` (`auto_number`, `city`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(13, 'Coimbatore', '', '', '', '', '', '', ''),
(12, 'Kolkata', '', '', '', '', '', '', ''),
(11, 'Mumbai', '', '', '', '', '', '', ''),
(10, 'Hyderabad', '', '', '', '', '', '', ''),
(8, 'Chennai', '', '', '', '', '', '', ''),
(9, 'Bangalore', '', '', '', '', '', '', ''),
(14, 'Kochi', '', '', '', '', '', '', ''),
(15, 'Trivandrum', '', '', '', '', '', '', ''),
(16, 'New Delhi', '', '', '', '', '', '', ''),
(17, 'Pune', '', '', '', '', '', '', ''),
(18, 'Madurai', '', '', '', '', '', '', ''),
(19, 'Delhi', '', '', '', '', '', '', ''),
(20, 'Telengana', 'deleted', '2017-10-05', '2017-10-05 14:46:36', 'admin', '::1', 'HYD', 'LOC-1'),
(21, 'ANDHRA', '', '2017-10-05', '2017-10-05 14:46:59', 'admin', '::1', 'HYD', 'LOC-1'),
(22, 'Rrrrt', 'deleted', '2017-10-10', '2017-10-10 13:50:12', 'admin', '::1', 'HYD', 'LOC-1'),
(23, 'Gova', '', '2017-10-13', '2017-10-13 12:15:29', 'admin', '::1', 'HYD', 'LOC-1'),
(24, 'Uti', '', '2017-10-13', '2017-10-13 12:15:43', 'admin', '::1', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_class`
--

CREATE TABLE `master_class` (
  `auto_number` int(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL,
  `username` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `locationcode` varchar(225) NOT NULL,
  `locationname` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_class`
--

INSERT INTO `master_class` (`auto_number`, `class`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationcode`, `locationname`) VALUES
(1, 'NURSERY', '', '2017-10-27 ', '2017-10-27 11:32:54', 'admin', '::1', 'LOC-1', 'HYD'),
(2, 'LKG', '', '2017-10-27 ', '2017-10-27 11:33:02', 'admin', '::1', 'LOC-1', 'HYD'),
(3, 'UKG', '', '2017-10-27 ', '2017-10-27 11:33:09', 'admin', '::1', 'LOC-1', 'HYD'),
(4, 'I', '', '2017-10-27 ', '2017-10-27 11:33:32', 'admin', '::1', 'LOC-1', 'HYD'),
(5, 'II', '', '2017-10-27 ', '2017-10-27 11:33:38', 'admin', '::1', 'LOC-1', 'HYD'),
(6, 'III', '', '2017-10-27 ', '2017-10-27 11:33:42', 'admin', '::1', 'LOC-1', 'HYD'),
(7, 'IV', '', '2017-10-27 ', '2017-10-27 11:33:56', 'admin', '::1', 'LOC-1', 'HYD'),
(8, 'V', '', '2017-10-27 ', '2017-10-27 11:33:59', 'admin', '::1', 'LOC-1', 'HYD'),
(9, 'VI', '', '2017-10-27 ', '2017-10-27 11:34:04', 'admin', '::1', 'LOC-1', 'HYD'),
(10, 'VII', '', '2017-10-27 ', '2017-10-27 11:34:16', 'admin', '::1', 'LOC-1', 'HYD'),
(11, 'VIII', '', '2017-10-27 ', '2017-10-27 11:34:27', 'admin', '::1', 'LOC-1', 'HYD'),
(12, 'IX', '', '2017-10-27 ', '2017-10-27 11:34:34', 'admin', '::1', 'LOC-1', 'HYD'),
(13, 'X', '', '2017-10-27 ', '2017-10-27 11:34:38', 'admin', '::1', 'LOC-1', 'HYD'),
(14, 'XI', '', '2017-10-27 ', '2017-10-27 11:34:42', 'admin', '::1', 'LOC-1', 'HYD'),
(15, 'XII', '', '2017-10-27 ', '2017-10-27 11:34:47', 'admin', '::1', 'LOC-1', 'HYD');

-- --------------------------------------------------------

--
-- Table structure for table `master_classallotment`
--

CREATE TABLE `master_classallotment` (
  `auto_number` int(255) NOT NULL,
  `classanum` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `length` varchar(255) NOT NULL,
  `session` varchar(255) NOT NULL,
  `totalsession` varchar(255) NOT NULL,
  `classgroup` varchar(255) NOT NULL,
  `teachers` varchar(255) NOT NULL,
  `recordstatus` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL,
  `academicyear` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_classallotment`
--

INSERT INTO `master_classallotment` (`auto_number`, `classanum`, `class`, `subject`, `length`, `session`, `totalsession`, `classgroup`, `teachers`, `recordstatus`, `username`, `ipaddress`, `updatedatetime`, `academicyear`) VALUES
(1, '', 'Nursery-B', 'Maths', '1', '1', '1', 'GIRLS', 'Deborah,Florance', '', 'admin', '192.168.1.10', '2017-10-25 16:05:39', '2017'),
(2, '', 'Nursery-C', 'Maths', '1', '1', '1', 'GIRLS', 'Deborah,Florance', '', 'admin', '192.168.1.10', '2017-10-25 16:05:39', '2017'),
(3, '', 'LKG-ROSE', 'Maths', '1', '1', '1', 'GIRLS', 'Deborah,Florance', '', 'admin', '192.168.1.10', '2017-10-25 16:05:39', '2017'),
(4, '', 'LKG-A', 'Maths', '2', '1', '2', 'ENTIRE CLASS', 'Vasudevan,Venkatesan', '', 'admin', '192.168.1.10', '2017-10-25 16:05:39', '2017'),
(5, '', 'UKG-A', 'Maths', '2', '1', '2', 'ENTIRE CLASS', 'Vasudevan,Venkatesan', '', 'admin', '192.168.1.10', '2017-10-25 16:05:39', '2017'),
(6, '', 'Nursery-B', 'Maths', '1', '1', '1', 'GIRLS', 'Deborah,Florance', '', 'admin', '192.168.1.10', '2017-10-25 18:05:29', '2017'),
(7, '', 'Nursery-C', 'Maths', '1', '1', '1', 'GIRLS', 'Deborah,Florance', '', 'admin', '192.168.1.10', '2017-10-25 18:05:29', '2017'),
(8, '', 'LKG-ROSE', 'Maths', '1', '1', '1', 'GIRLS', 'Deborah,Florance', '', 'admin', '192.168.1.10', '2017-10-25 18:05:29', '2017'),
(9, '', 'LKG-A', 'Maths', '2', '1', '2', 'ENTIRE CLASS', 'Vasudevan,Venkatesan', '', 'admin', '192.168.1.10', '2017-10-25 18:05:29', '2017'),
(10, '', 'UKG-A', 'Maths', '2', '1', '2', 'ENTIRE CLASS', 'Vasudevan,Venkatesan', '', 'admin', '192.168.1.10', '2017-10-25 18:05:29', '2017');

-- --------------------------------------------------------

--
-- Table structure for table `master_classgroup`
--

CREATE TABLE `master_classgroup` (
  `auto_number` int(255) NOT NULL,
  `groupname` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_classgroup`
--

INSERT INTO `master_classgroup` (`auto_number`, `groupname`, `status`, `ipaddress`, `username`, `updatedatetime`) VALUES
(1, 'ENTIRE CLASS', '', '127.0.0.1', 'admin', '2014-09-23 16:58:53'),
(2, 'BOYS', '', '127.0.0.1', 'admin', '2014-09-23 16:58:57'),
(3, 'GIRLS', '', '127.0.0.1', 'admin', '2014-09-23 16:59:00'),
(4, 'GROUP 1', '', '127.0.0.1', 'admin', '2014-09-23 16:59:06'),
(5, 'GROUP 2', '', '127.0.0.1', 'admin', '2014-09-23 16:59:10'),
(6, 'GROUP 3', '', '127.0.0.1', 'admin', '2014-09-23 16:59:14');

-- --------------------------------------------------------

--
-- Table structure for table `master_classname`
--

CREATE TABLE `master_classname` (
  `auto_number` int(15) NOT NULL,
  `classname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `sectionname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ordernumber` int(255) NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_classname`
--

INSERT INTO `master_classname` (`auto_number`, `classname`, `sectionname`, `ordernumber`, `status`) VALUES
(46, '5', 'GIRLS', 9, ''),
(44, '10', 'A', 14, ''),
(45, '5', 'BOYS', 9, ''),
(43, 'LKG', 'ROSE', 2, ''),
(42, 'LKG', 'LILY', 2, ''),
(41, '7', 'A', 11, ''),
(40, '1', 'A', 5, ''),
(39, 'UKG', 'A', 3, ''),
(38, 'LKG', 'A', 2, ''),
(35, 'Nursery', 'A', 1, ''),
(36, 'Nursery', 'B', 1, ''),
(37, 'Nursery', 'C', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `master_community`
--

CREATE TABLE `master_community` (
  `auto_number` int(15) NOT NULL,
  `community` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_community`
--

INSERT INTO `master_community` (`auto_number`, `community`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, 'bc', '', '2017-10-05 ', '2017-10-05 14:43:50', 'admin', '::1', 'HYD', 'LOC-1'),
(2, 'Sc', 'deleted', '2017-10-05 ', '2017-10-05 15:40:14', 'admin', '::1', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_country`
--

CREATE TABLE `master_country` (
  `auto_number` int(15) NOT NULL,
  `country` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_country`
--

INSERT INTO `master_country` (`auto_number`, `country`, `status`) VALUES
(1, 'United States', ''),
(2, 'Canada', ''),
(3, 'Mexico', ''),
(4, 'Afghanistan', ''),
(5, 'Albania', ''),
(6, 'American Samoa', ''),
(7, 'Andorra', ''),
(8, 'Angola', ''),
(9, 'Anguilla', ''),
(10, 'Antarctica', ''),
(11, 'Antigua and Barbuda', ''),
(12, 'Argentina', ''),
(13, 'Armenia', ''),
(14, 'Aruba', ''),
(15, 'Australia', ''),
(16, 'Austria', ''),
(17, 'Azerbaijan', ''),
(18, 'Bahamas', ''),
(19, 'Bahrain', ''),
(20, 'Bangladesh', ''),
(21, 'Barbados', ''),
(22, 'Belarus', ''),
(23, 'Belgium', ''),
(24, 'Belize', ''),
(25, 'Benin', ''),
(26, 'Bermuda', ''),
(27, 'Bhutan', ''),
(28, 'Bolivia', ''),
(29, 'Bhutan', ''),
(30, 'Bolivia', ''),
(31, 'Bosnia and Herzegowina', ''),
(32, 'Botswana', ''),
(33, 'Bouvet Island', ''),
(34, 'Brazil', ''),
(35, 'British Indian Ocean Terr.', ''),
(36, 'Brunei Darussalam', ''),
(37, 'Bulgaria', ''),
(38, 'Burkina Faso', ''),
(39, 'Burundi', ''),
(40, 'Cambodia', ''),
(41, 'Cameroon', ''),
(42, 'Cape Verde', ''),
(43, 'Cayman Islands', ''),
(44, 'Central African Republic', ''),
(45, 'Chad', ''),
(46, 'Chile', ''),
(47, 'China', ''),
(48, 'Cocos (Keeling) Islands', ''),
(49, 'Colombia', ''),
(50, 'Comoros', ''),
(51, 'Congo', ''),
(52, 'Cook Islands', ''),
(53, 'Costa Rica', ''),
(54, 'Cote dIvoire', ''),
(55, 'Croatia (Hrvatska)', ''),
(56, 'Cuba', ''),
(57, 'Cyprus', ''),
(58, 'Czech Republic', ''),
(59, 'Denmark', ''),
(60, 'Djibouti', ''),
(61, 'Dominica', ''),
(62, 'Dominican Republic', ''),
(63, 'East Timor', ''),
(64, 'Ecuador', ''),
(65, 'Egypt', ''),
(66, 'El Salvador', ''),
(67, 'Equatorial Guinea', ''),
(68, 'Eritrea', ''),
(69, 'Estonia', ''),
(70, 'Ethiopia', ''),
(71, 'Falkland Islands/Malvinas', ''),
(72, 'Faroe Islands', ''),
(73, 'Fiji', ''),
(74, 'Finland', ''),
(75, 'France', ''),
(76, 'France, Metropolitan', ''),
(77, 'French Guiana', ''),
(78, 'French Polynesia', ''),
(79, 'French Southern Terr.', ''),
(80, 'Gabon', ''),
(81, 'Gambia', ''),
(82, 'Georgia', ''),
(83, 'Germany', ''),
(84, 'Ghana', ''),
(85, 'Gibraltar', ''),
(86, 'Greece', ''),
(87, 'Greenland', ''),
(88, 'Grenada', ''),
(89, 'Guadeloupe', ''),
(90, 'Guam', ''),
(91, 'Guatemala', ''),
(92, 'Guinea', ''),
(93, 'Guinea-Bissau', ''),
(94, 'Guyana', ''),
(95, 'Haiti', ''),
(96, 'Heard McDonald Is.', ''),
(97, 'Honduras', ''),
(98, 'Hong Kong', ''),
(99, 'Hungary', ''),
(100, 'Iceland', ''),
(101, 'India', ''),
(102, 'Indonesia', ''),
(103, 'Iran', ''),
(104, 'Iraq', ''),
(105, 'Ireland', ''),
(106, 'Israel', ''),
(107, 'Italy', ''),
(108, 'Jamaica', ''),
(109, 'Japan', ''),
(110, 'Jordan', ''),
(111, 'Kazakhstan', ''),
(112, 'Kenya', ''),
(113, 'Kiribati', ''),
(114, 'Korea, North', ''),
(115, 'Korea, South', ''),
(116, 'Kuwait', ''),
(117, 'Kyrgyzstan', ''),
(118, 'Lao Peoples Dem. Rep.', ''),
(119, 'Latvia', ''),
(120, 'Lebanon', ''),
(121, 'Lesotho', ''),
(122, 'Liberia', ''),
(123, 'Libyan Arab Jamahiriya', ''),
(124, 'Liechtenstein', ''),
(125, 'Lithuania', ''),
(126, 'Luxembourg', ''),
(127, 'Macau', ''),
(128, 'Macedonia', ''),
(129, 'Madagascar', ''),
(130, 'Malawi', ''),
(131, 'Malaysia', ''),
(132, 'Maldives', ''),
(133, 'Mali', ''),
(134, 'Malta', ''),
(135, 'Marshall Islands', ''),
(136, 'Martinique', ''),
(137, 'Mauritius', ''),
(138, 'Mayotte', ''),
(139, 'Micronesia', ''),
(140, 'Moldova', ''),
(141, 'Monaco', ''),
(142, 'Mongolia', ''),
(143, 'Montserrat', ''),
(144, 'Morocco', ''),
(145, 'Mozambique', ''),
(146, 'Myanmar', ''),
(147, 'Namibia', ''),
(148, 'Nauru', ''),
(149, 'Nepal', ''),
(150, 'Netherlands', ''),
(151, 'Netherlands Antilles', ''),
(152, 'New Caledonia', ''),
(153, 'New Zealand', ''),
(154, 'Nicaragua', ''),
(155, 'Niger', ''),
(156, 'Nigeria', ''),
(157, 'Niue', ''),
(158, 'Norfolk Island', ''),
(159, 'Northern Mariana Is.', ''),
(160, 'Norway', ''),
(161, 'Oman', ''),
(162, 'Pakistan', ''),
(163, 'Palau', ''),
(164, 'Panama', ''),
(165, 'Papua New Guinea', ''),
(166, 'Paraguay', ''),
(167, 'Peru', ''),
(168, 'Philippines', ''),
(169, 'Pitcairn', ''),
(170, 'Poland', ''),
(171, 'Portugal', ''),
(172, 'Puerto Rico', ''),
(173, 'Qatar', ''),
(174, 'Reunion', ''),
(175, 'Romania', ''),
(176, 'Russian Federation', ''),
(177, 'Rwanda', ''),
(178, 'Saint Kitts and Nevis', ''),
(179, 'Saint Lucia', ''),
(180, 'St. Vincent Grenadines', ''),
(181, 'Samoa', ''),
(182, 'San Marino', ''),
(183, 'Sao Tome Principe', ''),
(184, 'Saudi Arabia', ''),
(185, 'Senegal', ''),
(186, 'Seychelles', ''),
(187, 'Sierra Leone', ''),
(188, 'Singapore', ''),
(189, 'Slovakia (Slovak Republic)', ''),
(190, 'Slovenia', ''),
(191, 'Solomon Islands', ''),
(192, 'Somalia', ''),
(193, 'South Africa', ''),
(194, 'S.Georgia S.Sandwich Is.', ''),
(195, 'Spain', ''),
(196, 'Sri Lanka', ''),
(197, 'St. Helena', ''),
(198, 'St. Pierre Miquelon', ''),
(199, 'Sudan', ''),
(200, 'Suriname', ''),
(201, 'Svalbard Jan Mayen Is.', ''),
(202, 'Swaziland', ''),
(203, 'Sweden', ''),
(204, 'Switzerland', ''),
(205, 'Syrian Arab Republic', ''),
(206, 'Taiwan', ''),
(207, 'Tajikistan', ''),
(208, 'Tanzania', ''),
(209, 'Thailand', ''),
(210, 'Togo', ''),
(211, 'Tokelau', ''),
(212, 'Tonga', ''),
(213, 'Trinidad and Tobago', ''),
(214, 'Tunisia', ''),
(215, 'Turkey', ''),
(216, 'Turkmenistan', ''),
(217, 'Turks Caicos Islands', ''),
(218, 'Tuvalu', ''),
(219, 'Uganda', ''),
(220, 'Ukraine', ''),
(221, 'United Arab Emirates', ''),
(222, 'United Kingdom', ''),
(223, 'U.S. Minor Outlying Is.', ''),
(224, 'Uruguay', ''),
(225, 'Uzbekistan', ''),
(226, 'Vanuatu', ''),
(227, 'Vatican (Holy See)', ''),
(228, 'Venezuela', ''),
(229, 'Viet Nam', ''),
(230, 'Virgin Islands (British)', ''),
(231, 'Virgin Islands (U.S.)', ''),
(232, 'Virgin Islands (U.S.)', ''),
(233, 'Western Sahara', ''),
(234, 'Yemen', ''),
(235, 'Yugoslavia', ''),
(236, 'Zaire', ''),
(237, 'Zambia', ''),
(238, 'Zimbabwe', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_course`
--

CREATE TABLE `master_course` (
  `auto_number` int(255) NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `degree` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_course`
--

INSERT INTO `master_course` (`auto_number`, `course`, `degree`, `status`) VALUES
(1, 'INFORMATION TECHNOLGOY', 'BE', ''),
(2, 'FOOD TECHNOLGOY', 'BE', ''),
(3, 'CIVIL ENGINEERING', 'BE', ''),
(4, 'MECHANICAL ENGINEERING', 'BE', ''),
(5, 'COMPUTER SCIENCE', 'BE', ''),
(6, 'LEATHER TECHNOLOGY', 'BTECH', ''),
(7, 'PRINTING TECHNOLOGY', 'BTECH', ''),
(9, 'HUMAN RESOURCES', 'MBA', 'deleted');

-- --------------------------------------------------------

--
-- Table structure for table `master_daystructure`
--

CREATE TABLE `master_daystructure` (
  `auto_number` int(255) NOT NULL,
  `dayspercycle` int(255) NOT NULL,
  `sessionsperday` int(255) NOT NULL,
  `zeroperiod` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `totalsessions` int(255) NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_daystructure`
--

INSERT INTO `master_daystructure` (`auto_number`, `dayspercycle`, `sessionsperday`, `zeroperiod`, `totalsessions`, `updatedby`, `updatedate`, `ipaddress`) VALUES
(1, 5, 10, 'yes', 11, 'admin', '2014-10-05 09:43:21', '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `master_degree`
--

CREATE TABLE `master_degree` (
  `auto_number` int(15) NOT NULL,
  `degree` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `programme` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_degree`
--

INSERT INTO `master_degree` (`auto_number`, `degree`, `programme`, `status`) VALUES
(25, 'BARCH', 'UG', ''),
(24, 'MBA', 'PG', ''),
(23, 'MCA', 'PG', ''),
(22, 'MTECH', 'PG', ''),
(21, 'BTECH', 'UG', ''),
(20, 'ME', 'PG', ''),
(19, 'BE', 'UG', ''),
(26, 'BPHARM', 'UG', ''),
(27, 'BDS', 'UG', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_department`
--

CREATE TABLE `master_department` (
  `auto_number` int(15) NOT NULL,
  `department` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_department`
--

INSERT INTO `master_department` (`auto_number`, `department`, `status`) VALUES
(11, 'ARCHITECTURE AND PLANNING', 'deleted'),
(10, 'BIO-TECHNOLOGY ', 'deleted'),
(9, 'TEXTILE TECHNOLOGY ', ''),
(8, 'CHEMICAL ENGINEERING', 'deleted'),
(12, 'MEDIA SCIENCES ', ''),
(13, 'ELECTRONICS ENGINEERING', ''),
(14, 'ELECTRONICS & INSTRUMENTATION ENGINEERING', ''),
(15, 'INFORMATION TECHNOLOGY ', ''),
(16, 'COMPUTER SCIENCE AND ENGINEERING ', ''),
(17, 'ELECTRONICS AND COMMUNICATION ENGINEERING ', ''),
(18, 'ELECTRICAL ENGINEERING', ''),
(19, 'RUBBER AND PLASTIC TECHNOLOGY ENGINEERING ', ''),
(20, 'PRODUCTION TECHNOLOGY ', ''),
(21, 'AUTOMOBILE ENGINEERING', 'deleted'),
(22, 'AEROSPACE ENGINNERING', 'deleted'),
(23, 'INDUSTRIAL ENGINEERING', ''),
(24, 'MANUFACTURING ENGINEERING ', ''),
(25, 'PRINTING TECHNOLOGY', ''),
(26, 'MECHANICAL ENGINEERING ', ''),
(27, 'CIVIL ENGINEERING', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_designation`
--

CREATE TABLE `master_designation` (
  `auto_number` int(15) NOT NULL,
  `designation` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_designation`
--

INSERT INTO `master_designation` (`auto_number`, `designation`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(14, 'Lecturer', '', '', '', '', '', '', ''),
(20, 'Administrator', '', '', '', '', '', '', ''),
(12, 'Senior Professor', '', '', '', '', '', '', ''),
(11, 'Professor', '', '', '', '', '', '', ''),
(10, 'Senior Principal', '', '', '', '', '', '', ''),
(9, 'Principal', '', '', '', '', '', '', ''),
(15, 'Lab Demonstrator', '', '', '', '', '', '', ''),
(16, 'Lab Assistant', '', '', '', '', '', '', ''),
(17, 'Librarian', '', '', '', '', '', '', ''),
(18, 'Accountant', 'deleted', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_documents`
--

CREATE TABLE `master_documents` (
  `auto_number` int(255) NOT NULL,
  `studentcode` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedate` varchar(255) NOT NULL,
  `documenttype` varchar(255) NOT NULL,
  `copiesnu` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_documents`
--

INSERT INTO `master_documents` (`auto_number`, `studentcode`, `status`, `ipaddress`, `updatedate`, `documenttype`, `copiesnu`, `username`, `locationname`, `locationcode`, `recorddate`) VALUES
(1, '', '', '::1', '2017-10-25 17:51:35', 'Birth Certificate', '1', 'admin', 'HYD', 'LOC-1', '2017-10-25'),
(2, '', '', '::1', '2017-10-25 17:51:35', 'Bonafide Certificate', '2', 'admin', 'HYD', 'LOC-1', '2017-10-25'),
(3, 'STU00000005', '', '192.168.1.10', '2017-10-25 18:06:30', 'Birth Certificate', '3', 'admin', 'HYD', 'LOC-1', '2017-10-25'),
(4, 'STU00000005', '', '192.168.1.10', '2017-10-25 18:06:30', 'Transfer Certificate', '2', 'admin', 'HYD', 'LOC-1', '2017-10-25'),
(5, '', '', '::1', '2017-10-30 11:36:58', 'Transfer Certificate', '6', 'admin', 'HYD', 'LOC-1', '2017-10-30'),
(6, '', '', '::1', '2017-10-30 11:36:58', 'Transfer Certificate', '8', 'admin', 'HYD', 'LOC-1', '2017-10-30'),
(7, '', '', '::1', '2017-10-30 15:44:16', 'Bonafide Certificate', '5', 'admin', 'HYD', 'LOC-1', '2017-10-30'),
(8, '', '', '::1', '2017-10-30 15:45:09', 'Birth Certificate', '10', 'admin', 'HYD', 'LOC-1', '2017-10-30'),
(9, 'STU00000001', '', '192.168.1.25', '2017-10-31 11:42:39', 'Birth Certificate', '2', 'admin', 'HYD', 'LOC-1', '2017-10-31'),
(10, 'STU00000001', '', '192.168.1.25', '2017-10-31 11:42:39', 'Bonafide Certificate', '3', 'admin', 'HYD', 'LOC-1', '2017-10-31'),
(11, 'STU00000001', '', '192.168.1.25', '2017-10-31 11:42:39', 'Transfer Certificate', '2', 'admin', 'HYD', 'LOC-1', '2017-10-31');

-- --------------------------------------------------------

--
-- Table structure for table `master_edition`
--

CREATE TABLE `master_edition` (
  `auto_number` int(255) NOT NULL,
  `productcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `edition` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `allowed` int(255) NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `users` int(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_edition`
--

INSERT INTO `master_edition` (`auto_number`, `productcode`, `edition`, `allowed`, `status`, `updatedate`, `users`) VALUES
(3, '1229132420132913', 'FREE', 30, '', '2013-12-13 04:56:44', 2),
(4, '1229132420132913', 'PAID', 30000, 'ACTIVE', '2013-12-13 04:56:44', 5);

-- --------------------------------------------------------

--
-- Table structure for table `master_employee`
--

CREATE TABLE `master_employee` (
  `auto_number` int(255) NOT NULL,
  `employeecode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `employeename` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdate` datetime NOT NULL,
  `lastupdateusername` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdateipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_employee`
--

INSERT INTO `master_employee` (`auto_number`, `employeecode`, `employeename`, `username`, `password`, `status`, `lastupdate`, `lastupdateusername`, `lastupdateipaddress`) VALUES
(1, 'EMP00000001', 'ADMINISTRATOR', 'admin', 'admin', 'Active', '2014-05-12 10:53:51', 'admin', '192.168.1.14'),
(2, 'EMP00000002', 'USER', 'user', 'user', 'Active', '2013-05-18 13:39:15', 'ADMIN', '192.168.1.15');

-- --------------------------------------------------------

--
-- Table structure for table `master_employeerights`
--

CREATE TABLE `master_employeerights` (
  `auto_number` int(255) NOT NULL,
  `employeecode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `mainmenuid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `submenuid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lastupdateipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastupdateusername` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_employeerights`
--

INSERT INTO `master_employeerights` (`auto_number`, `employeecode`, `username`, `mainmenuid`, `submenuid`, `lastupdate`, `lastupdateipaddress`, `lastupdateusername`) VALUES
(4031, 'EMP00000001', 'admin', '', 'SM202', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4030, 'EMP00000001', 'admin', '', 'SM201', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4029, 'EMP00000001', 'admin', '', 'SM239', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4028, 'EMP00000001', 'admin', '', 'SM238', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4027, 'EMP00000001', 'admin', '', 'SM236', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4026, 'EMP00000001', 'admin', '', 'SM235', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4025, 'EMP00000001', 'admin', '', 'SM234', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4024, 'EMP00000001', 'admin', '', 'SM233', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4023, 'EMP00000001', 'admin', '', 'SM178', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4022, 'EMP00000001', 'admin', '', 'SM177', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4021, 'EMP00000001', 'admin', '', 'SM176', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4020, 'EMP00000001', 'admin', '', 'SM175', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4019, 'EMP00000001', 'admin', '', 'SM174', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4018, 'EMP00000001', 'admin', '', 'SM173', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4017, 'EMP00000001', 'admin', '', 'SM172', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4016, 'EMP00000001', 'admin', '', 'SM171', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4015, 'EMP00000001', 'admin', '', 'SM170', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4014, 'EMP00000001', 'admin', '', 'SM169', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4013, 'EMP00000001', 'admin', '', 'SM168', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4012, 'EMP00000001', 'admin', '', 'SM167', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4011, 'EMP00000001', 'admin', '', 'SM166', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4010, 'EMP00000001', 'admin', '', 'SM165', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4009, 'EMP00000001', 'admin', '', 'SM164', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4008, 'EMP00000001', 'admin', '', 'SM163', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4007, 'EMP00000001', 'admin', '', 'SM162', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4006, 'EMP00000001', 'admin', '', 'SM161', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4005, 'EMP00000001', 'admin', '', 'SM160', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4004, 'EMP00000001', 'admin', '', 'SM159', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4003, 'EMP00000001', 'admin', '', 'SM158', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4002, 'EMP00000001', 'admin', '', 'SM157', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4001, 'EMP00000001', 'admin', '', 'SM156', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4000, 'EMP00000001', 'admin', '', 'SM155', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3999, 'EMP00000001', 'admin', '', 'SM154', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3998, 'EMP00000001', 'admin', '', 'SM153', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3997, 'EMP00000001', 'admin', '', 'SM152', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3996, 'EMP00000001', 'admin', '', 'SM151', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3995, 'EMP00000001', 'admin', '', 'SM150', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3994, 'EMP00000001', 'admin', '', 'SM149', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3993, 'EMP00000001', 'admin', '', 'SM148', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3992, 'EMP00000001', 'admin', '', 'SM147', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3991, 'EMP00000001', 'admin', '', 'SM146', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3990, 'EMP00000001', 'admin', '', 'SM145', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(1999, 'EMP00000003', 'user2', '', 'SM017', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1998, 'EMP00000003', 'user2', '', 'SM013', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1997, 'EMP00000003', 'user2', '', 'SM012', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1996, 'EMP00000003', 'user2', '', 'SM010', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1995, 'EMP00000003', 'user2', '', 'SM009', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1994, 'EMP00000003', 'user2', '', 'SM004', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1993, 'EMP00000003', 'user2', '', 'SM003', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1992, 'EMP00000003', 'user2', '', 'SM001', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1991, 'EMP00000003', 'user2', 'MM011', '', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1990, 'EMP00000003', 'user2', 'MM005', '', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1989, 'EMP00000003', 'user2', 'MM002', '', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1988, 'EMP00000003', 'user2', 'MM010', '', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1987, 'EMP00000003', 'user2', 'MM009', '', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1986, 'EMP00000003', 'user2', 'MM000', '', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1985, 'EMP00000003', 'user2', 'MM008', '', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1984, 'EMP00000003', 'user2', 'MM007', '', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1983, 'EMP00000003', 'user2', 'MM006', '', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1982, 'EMP00000003', 'user2', 'MM004', '', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1981, 'EMP00000003', 'user2', 'MM003', '', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1980, 'EMP00000003', 'user2', 'MM001', '', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(1979, 'EMP00000002', 'user', '', 'SM127', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1978, 'EMP00000002', 'user', '', 'SM126', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1977, 'EMP00000002', 'user', '', 'SM125', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1976, 'EMP00000002', 'user', '', 'SM124', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1975, 'EMP00000002', 'user', '', 'SM123', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1974, 'EMP00000002', 'user', '', 'SM114', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1973, 'EMP00000002', 'user', '', 'SM112', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1972, 'EMP00000002', 'user', '', 'SM111', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1971, 'EMP00000002', 'user', '', 'SM110', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1970, 'EMP00000002', 'user', '', 'SM109', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1969, 'EMP00000002', 'user', '', 'SM108', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1968, 'EMP00000002', 'user', '', 'SM107', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1967, 'EMP00000002', 'user', '', 'SM106', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1966, 'EMP00000002', 'user', '', 'SM105', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1965, 'EMP00000002', 'user', '', 'SM104', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1964, 'EMP00000002', 'user', '', 'SM103', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1963, 'EMP00000002', 'user', '', 'SM102', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1962, 'EMP00000002', 'user', '', 'SM101', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1961, 'EMP00000002', 'user', '', 'SM099', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1960, 'EMP00000002', 'user', '', 'SM096', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1959, 'EMP00000002', 'user', '', 'SM095', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1958, 'EMP00000002', 'user', '', 'SM094', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1957, 'EMP00000002', 'user', '', 'SM093', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1956, 'EMP00000002', 'user', '', 'SM092', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1955, 'EMP00000002', 'user', '', 'SM091', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1954, 'EMP00000002', 'user', '', 'SM090', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1953, 'EMP00000002', 'user', '', 'SM089', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1952, 'EMP00000002', 'user', '', 'SM088', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1951, 'EMP00000002', 'user', '', 'SM087', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1950, 'EMP00000002', 'user', '', 'SM086', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1949, 'EMP00000002', 'user', '', 'SM085', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1948, 'EMP00000002', 'user', '', 'SM084', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1947, 'EMP00000002', 'user', '', 'SM083', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1946, 'EMP00000002', 'user', '', 'SM082', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1945, 'EMP00000002', 'user', '', 'SM078', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1944, 'EMP00000002', 'user', '', 'SM070', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1943, 'EMP00000002', 'user', '', 'SM069', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1942, 'EMP00000002', 'user', '', 'SM043', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1941, 'EMP00000002', 'user', '', 'SM042', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1940, 'EMP00000002', 'user', '', 'SM043', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1939, 'EMP00000002', 'user', '', 'SM042', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1938, 'EMP00000002', 'user', '', 'SM041', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1937, 'EMP00000002', 'user', '', 'SM040', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1936, 'EMP00000002', 'user', '', 'SM039', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1935, 'EMP00000002', 'user', '', 'SM056', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1934, 'EMP00000002', 'user', '', 'SM055', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1933, 'EMP00000002', 'user', '', 'SM081', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1932, 'EMP00000002', 'user', '', 'SM080', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1931, 'EMP00000002', 'user', '', 'SM036', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1930, 'EMP00000002', 'user', '', 'SM035', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1929, 'EMP00000002', 'user', '', 'SM067', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1928, 'EMP00000002', 'user', '', 'SM067', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1927, 'EMP00000002', 'user', '', 'SM038', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1926, 'EMP00000002', 'user', '', 'SM066', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1925, 'EMP00000002', 'user', '', 'SM060', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1924, 'EMP00000002', 'user', '', 'SM056', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1923, 'EMP00000002', 'user', '', 'SM079', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1922, 'EMP00000002', 'user', '', 'SM075', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1921, 'EMP00000002', 'user', '', 'SM023', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1920, 'EMP00000002', 'user', '', 'SM079', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1919, 'EMP00000002', 'user', '', 'SM078', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1918, 'EMP00000002', 'user', '', 'SM024', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1917, 'EMP00000002', 'user', '', 'SM056', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1916, 'EMP00000002', 'user', '', 'SM034', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1915, 'EMP00000002', 'user', '', 'SM068', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1914, 'EMP00000002', 'user', '', 'SM077', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1913, 'EMP00000002', 'user', '', 'SM033', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1912, 'EMP00000002', 'user', '', 'SM074', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1911, 'EMP00000002', 'user', '', 'SM068', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1910, 'EMP00000002', 'user', '', 'SM027', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1909, 'EMP00000002', 'user', '', 'SM032', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1908, 'EMP00000002', 'user', '', 'SM037', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1907, 'EMP00000002', 'user', '', 'SM026', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1906, 'EMP00000002', 'user', '', 'SM076', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1905, 'EMP00000002', 'user', '', 'SM071', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1904, 'EMP00000002', 'user', '', 'SM075', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1903, 'EMP00000002', 'user', '', 'SM023', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1902, 'EMP00000002', 'user', '', 'SM022', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1901, 'EMP00000002', 'user', '', 'SM021', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1900, 'EMP00000002', 'user', '', 'SM002', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1899, 'EMP00000002', 'user', '', 'SM074', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1898, 'EMP00000002', 'user', '', 'SM073', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1897, 'EMP00000002', 'user', '', 'SM072', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1896, 'EMP00000002', 'user', '', 'SM067', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1895, 'EMP00000002', 'user', '', 'SM066', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1894, 'EMP00000002', 'user', '', 'SM058', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1893, 'EMP00000002', 'user', '', 'SM055', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1892, 'EMP00000002', 'user', '', 'SM031', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1891, 'EMP00000002', 'user', '', 'SM018', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1890, 'EMP00000002', 'user', '', 'SM017', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1889, 'EMP00000002', 'user', '', 'SM010', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1888, 'EMP00000002', 'user', '', 'SM009', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1887, 'EMP00000002', 'user', '', 'SM004', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1886, 'EMP00000002', 'user', '', 'SM003', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1885, 'EMP00000002', 'user', '', 'SM001', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1884, 'EMP00000002', 'user', 'MM000', '', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1883, 'EMP00000002', 'user', 'MM008', '', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(1882, 'EMP00000002', 'user', 'MM003', '', '2013-05-18 08:09:15', '192.168.1.15', 'ADMIN'),
(3989, 'EMP00000001', 'admin', '', 'SM144', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3988, 'EMP00000001', 'admin', '', 'SM143', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3987, 'EMP00000001', 'admin', '', 'SM142', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3986, 'EMP00000001', 'admin', '', 'SM141', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(2000, 'EMP00000003', 'user2', '', 'SM018', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2001, 'EMP00000003', 'user2', '', 'SM020', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2002, 'EMP00000003', 'user2', '', 'SM031', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2003, 'EMP00000003', 'user2', '', 'SM055', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2004, 'EMP00000003', 'user2', '', 'SM058', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2005, 'EMP00000003', 'user2', '', 'SM066', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2006, 'EMP00000003', 'user2', '', 'SM067', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2007, 'EMP00000003', 'user2', '', 'SM072', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2008, 'EMP00000003', 'user2', '', 'SM073', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2009, 'EMP00000003', 'user2', '', 'SM074', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2010, 'EMP00000003', 'user2', '', 'SM002', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2011, 'EMP00000003', 'user2', '', 'SM021', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2012, 'EMP00000003', 'user2', '', 'SM022', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2013, 'EMP00000003', 'user2', '', 'SM023', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2014, 'EMP00000003', 'user2', '', 'SM075', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2015, 'EMP00000003', 'user2', '', 'SM071', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2016, 'EMP00000003', 'user2', '', 'SM076', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2017, 'EMP00000003', 'user2', '', 'SM026', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2018, 'EMP00000003', 'user2', '', 'SM037', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2019, 'EMP00000003', 'user2', '', 'SM032', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2020, 'EMP00000003', 'user2', '', 'SM027', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2021, 'EMP00000003', 'user2', '', 'SM068', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2022, 'EMP00000003', 'user2', '', 'SM074', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2023, 'EMP00000003', 'user2', '', 'SM033', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2024, 'EMP00000003', 'user2', '', 'SM077', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2025, 'EMP00000003', 'user2', '', 'SM068', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2026, 'EMP00000003', 'user2', '', 'SM075', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2027, 'EMP00000003', 'user2', '', 'SM034', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2028, 'EMP00000003', 'user2', '', 'SM056', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2029, 'EMP00000003', 'user2', '', 'SM024', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2030, 'EMP00000003', 'user2', '', 'SM078', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2031, 'EMP00000003', 'user2', '', 'SM079', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2032, 'EMP00000003', 'user2', '', 'SM023', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2033, 'EMP00000003', 'user2', '', 'SM075', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2034, 'EMP00000003', 'user2', '', 'SM079', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2035, 'EMP00000003', 'user2', '', 'SM056', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2036, 'EMP00000003', 'user2', '', 'SM060', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2037, 'EMP00000003', 'user2', '', 'SM066', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2038, 'EMP00000003', 'user2', '', 'SM038', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2039, 'EMP00000003', 'user2', '', 'SM067', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2040, 'EMP00000003', 'user2', '', 'SM067', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2041, 'EMP00000003', 'user2', '', 'SM035', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2042, 'EMP00000003', 'user2', '', 'SM036', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2043, 'EMP00000003', 'user2', '', 'SM080', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2044, 'EMP00000003', 'user2', '', 'SM081', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2045, 'EMP00000003', 'user2', '', 'SM055', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2046, 'EMP00000003', 'user2', '', 'SM056', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2047, 'EMP00000003', 'user2', '', 'SM039', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2048, 'EMP00000003', 'user2', '', 'SM040', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2049, 'EMP00000003', 'user2', '', 'SM041', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2050, 'EMP00000003', 'user2', '', 'SM042', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2051, 'EMP00000003', 'user2', '', 'SM043', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2052, 'EMP00000003', 'user2', '', 'SM042', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2053, 'EMP00000003', 'user2', '', 'SM043', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2054, 'EMP00000003', 'user2', '', 'SM069', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2055, 'EMP00000003', 'user2', '', 'SM070', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2056, 'EMP00000003', 'user2', '', 'SM078', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2057, 'EMP00000003', 'user2', '', 'SM082', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2058, 'EMP00000003', 'user2', '', 'SM083', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2059, 'EMP00000003', 'user2', '', 'SM084', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2060, 'EMP00000003', 'user2', '', 'SM085', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2061, 'EMP00000003', 'user2', '', 'SM086', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2062, 'EMP00000003', 'user2', '', 'SM087', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2063, 'EMP00000003', 'user2', '', 'SM088', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2064, 'EMP00000003', 'user2', '', 'SM089', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2065, 'EMP00000003', 'user2', '', 'SM090', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2066, 'EMP00000003', 'user2', '', 'SM091', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2067, 'EMP00000003', 'user2', '', 'SM092', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2068, 'EMP00000003', 'user2', '', 'SM093', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2069, 'EMP00000003', 'user2', '', 'SM094', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2070, 'EMP00000003', 'user2', '', 'SM095', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2071, 'EMP00000003', 'user2', '', 'SM096', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2072, 'EMP00000003', 'user2', '', 'SM099', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2073, 'EMP00000003', 'user2', '', 'SM101', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2074, 'EMP00000003', 'user2', '', 'SM102', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2075, 'EMP00000003', 'user2', '', 'SM103', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2076, 'EMP00000003', 'user2', '', 'SM104', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2077, 'EMP00000003', 'user2', '', 'SM105', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2078, 'EMP00000003', 'user2', '', 'SM106', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2079, 'EMP00000003', 'user2', '', 'SM107', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2080, 'EMP00000003', 'user2', '', 'SM108', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2081, 'EMP00000003', 'user2', '', 'SM109', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2082, 'EMP00000003', 'user2', '', 'SM110', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2083, 'EMP00000003', 'user2', '', 'SM111', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2084, 'EMP00000003', 'user2', '', 'SM112', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2085, 'EMP00000003', 'user2', '', 'SM114', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2086, 'EMP00000003', 'user2', '', 'SM115', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2087, 'EMP00000003', 'user2', '', 'SM116', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2088, 'EMP00000003', 'user2', '', 'SM117', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2089, 'EMP00000003', 'user2', '', 'SM118', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2090, 'EMP00000003', 'user2', '', 'SM119', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2091, 'EMP00000003', 'user2', '', 'SM120', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2092, 'EMP00000003', 'user2', '', 'SM121', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2093, 'EMP00000003', 'user2', '', 'SM122', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2094, 'EMP00000003', 'user2', '', 'SM123', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2095, 'EMP00000003', 'user2', '', 'SM124', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2096, 'EMP00000003', 'user2', '', 'SM125', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2097, 'EMP00000003', 'user2', '', 'SM126', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2098, 'EMP00000003', 'user2', '', 'SM127', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2099, 'EMP00000003', 'user2', '', 'SM128', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2100, 'EMP00000003', 'user2', '', 'SM129', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2101, 'EMP00000003', 'user2', '', 'SM130', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2102, 'EMP00000003', 'user2', '', 'SM131', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2103, 'EMP00000003', 'user2', '', 'SM132', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2104, 'EMP00000003', 'user2', '', 'SM133', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2105, 'EMP00000003', 'user2', '', 'SM134', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2106, 'EMP00000003', 'user2', '', 'SM135', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2107, 'EMP00000003', 'user2', '', 'SM136', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2108, 'EMP00000003', 'user2', '', 'SM137', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2109, 'EMP00000003', 'user2', '', 'SM138', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2110, 'EMP00000003', 'user2', '', 'SM139', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2111, 'EMP00000003', 'user2', '', 'SM140', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2112, 'EMP00000003', 'user2', '', 'SM141', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2113, 'EMP00000003', 'user2', '', 'SM142', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(2114, 'EMP00000003', 'user2', '', 'SM143', '2013-05-18 09:17:02', '192.168.1.15', 'admin'),
(3985, 'EMP00000001', 'admin', '', 'SM140', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3984, 'EMP00000001', 'admin', '', 'SM139', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3983, 'EMP00000001', 'admin', '', 'SM138', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3982, 'EMP00000001', 'admin', '', 'SM137', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3981, 'EMP00000001', 'admin', '', 'SM136', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3980, 'EMP00000001', 'admin', '', 'SM135', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3979, 'EMP00000001', 'admin', '', 'SM134', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3978, 'EMP00000001', 'admin', '', 'SM133', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3977, 'EMP00000001', 'admin', '', 'SM132', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3976, 'EMP00000001', 'admin', '', 'SM130', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3975, 'EMP00000001', 'admin', '', 'SM129', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3974, 'EMP00000001', 'admin', '', 'SM128', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3973, 'EMP00000001', 'admin', '', 'SM127', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3972, 'EMP00000001', 'admin', '', 'SM126', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3971, 'EMP00000001', 'admin', '', 'SM125', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3970, 'EMP00000001', 'admin', '', 'SM124', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3969, 'EMP00000001', 'admin', '', 'SM123', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3968, 'EMP00000001', 'admin', '', 'SM114', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3967, 'EMP00000001', 'admin', '', 'SM112', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3966, 'EMP00000001', 'admin', '', 'SM111', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3965, 'EMP00000001', 'admin', '', 'SM110', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3964, 'EMP00000001', 'admin', '', 'SM109', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3963, 'EMP00000001', 'admin', '', 'SM108', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3962, 'EMP00000001', 'admin', '', 'SM107', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3961, 'EMP00000001', 'admin', '', 'SM106', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3960, 'EMP00000001', 'admin', '', 'SM105', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3959, 'EMP00000001', 'admin', '', 'SM104', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3958, 'EMP00000001', 'admin', '', 'SM103', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3957, 'EMP00000001', 'admin', '', 'SM102', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3956, 'EMP00000001', 'admin', '', 'SM101', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3955, 'EMP00000001', 'admin', '', 'SM099', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3954, 'EMP00000001', 'admin', '', 'SM096', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3953, 'EMP00000001', 'admin', '', 'SM095', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3952, 'EMP00000001', 'admin', '', 'SM094', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3951, 'EMP00000001', 'admin', '', 'SM093', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3950, 'EMP00000001', 'admin', '', 'SM092', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3949, 'EMP00000001', 'admin', '', 'SM091', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3948, 'EMP00000001', 'admin', '', 'SM090', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3947, 'EMP00000001', 'admin', '', 'SM089', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3946, 'EMP00000001', 'admin', '', 'SM088', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3945, 'EMP00000001', 'admin', '', 'SM087', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3944, 'EMP00000001', 'admin', '', 'SM086', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3943, 'EMP00000001', 'admin', '', 'SM085', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3942, 'EMP00000001', 'admin', '', 'SM084', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3941, 'EMP00000001', 'admin', '', 'SM083', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3940, 'EMP00000001', 'admin', '', 'SM082', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3939, 'EMP00000001', 'admin', '', 'SM078', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3938, 'EMP00000001', 'admin', '', 'SM070', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3937, 'EMP00000001', 'admin', '', 'SM069', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3936, 'EMP00000001', 'admin', '', 'SM043', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3935, 'EMP00000001', 'admin', '', 'SM042', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3934, 'EMP00000001', 'admin', '', 'SM043', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3933, 'EMP00000001', 'admin', '', 'SM042', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3932, 'EMP00000001', 'admin', '', 'SM041', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3931, 'EMP00000001', 'admin', '', 'SM040', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3930, 'EMP00000001', 'admin', '', 'SM039', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3929, 'EMP00000001', 'admin', '', 'SM056', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3928, 'EMP00000001', 'admin', '', 'SM055', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3927, 'EMP00000001', 'admin', '', 'SM081', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3926, 'EMP00000001', 'admin', '', 'SM080', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3925, 'EMP00000001', 'admin', '', 'SM036', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3924, 'EMP00000001', 'admin', '', 'SM035', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3923, 'EMP00000001', 'admin', '', 'SM067', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3922, 'EMP00000001', 'admin', '', 'SM067', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3921, 'EMP00000001', 'admin', '', 'SM038', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3920, 'EMP00000001', 'admin', '', 'SM066', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3919, 'EMP00000001', 'admin', '', 'SM060', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3918, 'EMP00000001', 'admin', '', 'SM056', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3917, 'EMP00000001', 'admin', '', 'SM079', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3916, 'EMP00000001', 'admin', '', 'SM075', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3915, 'EMP00000001', 'admin', '', 'SM079', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3914, 'EMP00000001', 'admin', '', 'SM078', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3913, 'EMP00000001', 'admin', '', 'SM024', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3912, 'EMP00000001', 'admin', '', 'SM056', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3911, 'EMP00000001', 'admin', '', 'SM034', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3910, 'EMP00000001', 'admin', '', 'SM068', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3909, 'EMP00000001', 'admin', '', 'SM077', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3908, 'EMP00000001', 'admin', '', 'SM033', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3907, 'EMP00000001', 'admin', '', 'SM074', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3906, 'EMP00000001', 'admin', '', 'SM068', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3905, 'EMP00000001', 'admin', '', 'SM027', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3904, 'EMP00000001', 'admin', '', 'SM032', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3903, 'EMP00000001', 'admin', '', 'SM037', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3902, 'EMP00000001', 'admin', '', 'SM026', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3901, 'EMP00000001', 'admin', '', 'SM076', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3900, 'EMP00000001', 'admin', '', 'SM071', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3899, 'EMP00000001', 'admin', '', 'SM075', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3898, 'EMP00000001', 'admin', '', 'SM022', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3897, 'EMP00000001', 'admin', '', 'SM021', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3896, 'EMP00000001', 'admin', '', 'SM002', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3895, 'EMP00000001', 'admin', '', 'SM074', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3894, 'EMP00000001', 'admin', '', 'SM073', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3893, 'EMP00000001', 'admin', '', 'SM072', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3892, 'EMP00000001', 'admin', '', 'SM067', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3891, 'EMP00000001', 'admin', '', 'SM066', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3890, 'EMP00000001', 'admin', '', 'SM058', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3889, 'EMP00000001', 'admin', '', 'SM055', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3888, 'EMP00000001', 'admin', '', 'SM031', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3887, 'EMP00000001', 'admin', '', 'SM018', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3886, 'EMP00000001', 'admin', '', 'SM017', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3885, 'EMP00000001', 'admin', '', 'SM010', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3884, 'EMP00000001', 'admin', '', 'SM009', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3883, 'EMP00000001', 'admin', '', 'SM004', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3882, 'EMP00000001', 'admin', '', 'SM003', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3881, 'EMP00000001', 'admin', '', 'SM001', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3880, 'EMP00000001', 'admin', 'MM014', '', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3879, 'EMP00000001', 'admin', 'MM012', '', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3878, 'EMP00000001', 'admin', 'MM011', '', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3877, 'EMP00000001', 'admin', 'MM010', '', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3876, 'EMP00000001', 'admin', 'MM009', '', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3875, 'EMP00000001', 'admin', 'MM000', '', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3874, 'EMP00000001', 'admin', 'MM008', '', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3873, 'EMP00000001', 'admin', 'MM007', '', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3872, 'EMP00000001', 'admin', 'MM006', '', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3871, 'EMP00000001', 'admin', 'MM004', '', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3870, 'EMP00000001', 'admin', 'MM003', '', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(3869, 'EMP00000001', 'admin', 'MM001', '', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4032, 'EMP00000001', 'admin', '', 'SM205', '2014-05-12 05:23:51', '192.168.1.14', 'admin'),
(4033, 'EMP00000001', 'admin', '', 'SM206', '2014-05-12 05:23:51', '192.168.1.14', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `master_enquiry`
--

CREATE TABLE `master_enquiry` (
  `auto_number` int(255) NOT NULL,
  `enquirynumber` varchar(255) NOT NULL,
  `enquirydate` date NOT NULL,
  `branch` varchar(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `issuedby` varchar(255) NOT NULL,
  `admissionforclass` varchar(255) NOT NULL,
  `studentname` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `studentmobile` varchar(255) NOT NULL,
  `studentemail` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `transport` varchar(255) NOT NULL,
  `fathername` varchar(255) NOT NULL,
  `fathermobile` varchar(255) NOT NULL,
  `fatheremail` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_enquiry`
--

INSERT INTO `master_enquiry` (`auto_number`, `enquirynumber`, `enquirydate`, `branch`, `academicyear`, `issuedby`, `admissionforclass`, `studentname`, `gender`, `dob`, `studentmobile`, `studentemail`, `category`, `transport`, `fathername`, `fathermobile`, `fatheremail`, `username`, `ipaddress`, `updatedatetime`) VALUES
(1, 'ENQ/1000/2017-18', '2017-05-01', 'Neredmet', '2017-18', 'admin', 'Nursery', 'Vignesh', 'male', '2016-10-03', '', '', 'Dayscholar', 'yes', 'Krishna', '9966275057', 'cskkrishna@gmail.com', 'admin', '192.168.1.21', '2017-10-11 11:19:36');

-- --------------------------------------------------------

--
-- Table structure for table `master_exam`
--

CREATE TABLE `master_exam` (
  `auto_number` int(15) NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_exam`
--

INSERT INTO `master_exam` (`auto_number`, `exam`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, 'Unit Test 1', '', '2017-10-31 ', '2017-10-31 11:24:09', 'admin', '192.168.1.25', 'HYD', 'LOC-1'),
(2, 'Unit Test 2', '', '2017-10-31 ', '2017-10-31 11:24:16', 'admin', '192.168.1.25', 'HYD', 'LOC-1'),
(3, 'Quarterly', '', '2017-10-31 ', '2017-10-31 11:24:23', 'admin', '192.168.1.25', 'HYD', 'LOC-1'),
(4, 'Half Yearly', '', '2017-10-31 ', '2017-10-31 11:24:48', 'admin', '192.168.1.25', 'HYD', 'LOC-1'),
(5, 'Annual Exam', '', '2017-10-31 ', '2017-10-31 11:24:55', 'admin', '192.168.1.25', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_exam1`
--

CREATE TABLE `master_exam1` (
  `auto_number` int(30) NOT NULL,
  `exam` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `master_feeassign`
--

CREATE TABLE `master_feeassign` (
  `auto_number` int(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `feecategoryanum` int(255) NOT NULL,
  `feecategory` varchar(255) NOT NULL,
  `feeheadanum` int(255) NOT NULL,
  `feehead` varchar(255) NOT NULL,
  `noofinstall` varchar(255) NOT NULL,
  `installdate` date NOT NULL,
  `oldadmission` varchar(255) NOT NULL,
  `newadmission` varchar(255) NOT NULL,
  `amount` decimal(13,2) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_feeassign`
--

INSERT INTO `master_feeassign` (`auto_number`, `class`, `feecategoryanum`, `feecategory`, `feeheadanum`, `feehead`, `noofinstall`, `installdate`, `oldadmission`, `newadmission`, `amount`, `status`, `ipaddress`, `username`, `updatedatetime`) VALUES
(1, 'NURSERY', 0, 'All', 1, 'BUILDING FEE', '2', '0000-00-00', '0', '2500', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(2, 'NURSERY', 0, 'All', 2, 'TUTION FEE', '10', '0000-00-00', '2000', '2000', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(3, 'NURSERY', 0, 'All', 3, 'UNIFORM FEE', '1', '0000-00-00', '1500', '1500', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(4, 'NURSERY', 0, 'All', 4, 'BOOK FEES', '1', '0000-00-00', '5000', '5000', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(5, 'NURSERY', 0, 'All', 5, 'EXAM FEES', '1', '0000-00-00', '3000', '3000', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(6, 'NURSERY', 0, 'Hosteler', 6, 'HOSTEL DEPOSIT', '1', '0000-00-00', '', '10000', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(7, 'LKG', 0, 'All', 1, 'BUILDING FEE', '2', '0000-00-00', '0', '2500', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(8, 'LKG', 0, 'All', 2, 'TUTION FEE', '10', '0000-00-00', '2000', '2000', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(9, 'LKG', 0, 'All', 3, 'UNIFORM FEE', '1', '0000-00-00', '1500', '1500', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(10, 'LKG', 0, 'All', 4, 'BOOK FEES', '1', '0000-00-00', '5000', '5000', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(11, 'LKG', 0, 'All', 5, 'EXAM FEES', '1', '0000-00-00', '3000', '3000', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(12, 'LKG', 0, 'Hosteler', 6, 'HOSTEL DEPOSIT', '1', '0000-00-00', '', '10000', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(13, 'UKG', 0, 'All', 1, 'BUILDING FEE', '2', '0000-00-00', '0', '2500', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(14, 'UKG', 0, 'All', 2, 'TUTION FEE', '10', '0000-00-00', '2000', '2000', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(15, 'UKG', 0, 'All', 3, 'UNIFORM FEE', '1', '0000-00-00', '1500', '1500', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(16, 'UKG', 0, 'All', 4, 'BOOK FEES', '1', '0000-00-00', '5000', '5000', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(17, 'UKG', 0, 'All', 5, 'EXAM FEES', '1', '0000-00-00', '3000', '3000', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04'),
(18, 'UKG', 0, 'Hosteler', 6, 'HOSTEL DEPOSIT', '1', '0000-00-00', '', '10000', '0.00', '', '192.168.1.9', 'admin', '2017-10-20 11:46:04');

-- --------------------------------------------------------

--
-- Table structure for table `master_feecategory`
--

CREATE TABLE `master_feecategory` (
  `auto_number` int(255) NOT NULL,
  `ordernumber` int(255) NOT NULL,
  `feecategory` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_feecategory`
--

INSERT INTO `master_feecategory` (`auto_number`, `ordernumber`, `feecategory`, `status`, `ipaddress`, `updatedatetime`) VALUES
(1, 2, 'New Admission', '', '127.0.0.1', '2014-10-06 11:14:00'),
(2, 3, 'Old Admission', '', '127.0.0.1', '2014-10-06 11:14:20'),
(3, 6, 'Hostel New', '', '127.0.0.1', '2014-10-06 11:14:34'),
(4, 7, 'Hostel Old', '', '127.0.0.1', '2014-10-06 11:14:42'),
(6, 1, 'All', 'deleted', '127.0.0.1', '2014-10-06 11:25:19'),
(7, 4, 'Dayscholar', 'deleted', '127.0.0.1', '2014-10-06 12:17:04'),
(8, 5, 'Residential', 'deleted', '127.0.0.1', '2014-10-06 12:17:12');

-- --------------------------------------------------------

--
-- Table structure for table `master_feehead`
--

CREATE TABLE `master_feehead` (
  `auto_number` int(255) NOT NULL,
  `feehead` varchar(255) NOT NULL,
  `duedate` date NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_feehead`
--

INSERT INTO `master_feehead` (`auto_number`, `feehead`, `duedate`, `status`, `ipaddress`, `username`, `updatedatetime`) VALUES
(1, 'NEW ADMISSION FEE', '2017-06-10', '', '192.168.1.9', 'admin', '2017-10-20 11:34:23'),
(2, 'FIRST TERM FEE', '2017-06-25', '', '192.168.1.9', 'admin', '2017-10-20 11:35:21'),
(3, 'SECOND TERM FEE', '2017-09-10', '', '192.168.1.9', 'admin', '2017-10-20 11:35:37'),
(4, 'THIRD TERM FEE', '2017-12-10', '', '192.168.1.9', 'admin', '2017-10-20 11:36:03'),
(5, 'FOURTH TERM FEE', '2018-03-10', '', '192.168.1.9', 'admin', '2017-10-20 11:36:24');

-- --------------------------------------------------------

--
-- Table structure for table `master_feepayment`
--

CREATE TABLE `master_feepayment` (
  `auto_number` int(255) NOT NULL,
  `receiptnumber` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `feeupto` date NOT NULL,
  `applicationnumber` varchar(255) NOT NULL,
  `admissionnumber` varchar(255) NOT NULL,
  `studentcode` varchar(255) NOT NULL,
  `studentname` varchar(255) NOT NULL,
  `rollnumber` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `fathername` varchar(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `subtotal` decimal(13,2) NOT NULL,
  `subtotaldiscamount` decimal(13,2) NOT NULL,
  `subtotaldiscpercent` decimal(13,2) NOT NULL,
  `discountamount` decimal(13,2) NOT NULL,
  `totalafterdiscount` decimal(13,2) NOT NULL,
  `roundoff` varchar(255) NOT NULL,
  `totalamount` decimal(13,2) NOT NULL,
  `paymentmode` varchar(255) NOT NULL,
  `cashamount` decimal(13,2) NOT NULL,
  `cashreceived` decimal(13,2) NOT NULL,
  `cashreturned` decimal(13,2) NOT NULL,
  `chequeamount` decimal(13,2) NOT NULL,
  `chequebank` varchar(255) NOT NULL,
  `chequenumber` varchar(255) NOT NULL,
  `chequedate` date NOT NULL,
  `ddamount` decimal(13,2) NOT NULL,
  `ddbank` varchar(255) NOT NULL,
  `ddnumber` varchar(255) NOT NULL,
  `dddate` date NOT NULL,
  `recordstatus` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_feepayment`
--

INSERT INTO `master_feepayment` (`auto_number`, `receiptnumber`, `receiptdate`, `feeupto`, `applicationnumber`, `admissionnumber`, `studentcode`, `studentname`, `rollnumber`, `class`, `section`, `category`, `fathername`, `academicyear`, `subtotal`, `subtotaldiscamount`, `subtotaldiscpercent`, `discountamount`, `totalafterdiscount`, `roundoff`, `totalamount`, `paymentmode`, `cashamount`, `cashreceived`, `cashreturned`, `chequeamount`, `chequebank`, `chequenumber`, `chequedate`, `ddamount`, `ddbank`, `ddnumber`, `dddate`, `recordstatus`, `ipaddress`, `username`, `updatedatetime`) VALUES
(1, 'FEE/2017-18/1000', '2017-10-21', '2017-10-21', '', 'ADM/2017-18/1002', 'STU00000003', 'dc  ', 'undefined', 'LKG', 'male', '', '2005-01', '2005-01', '21000.00', '0.00', '10.00', '2100.00', '18900.00', '0.00', '18900.00', '', '0.00', '0.00', '0.00', '0.00', '', '', '0000-00-00', '0.00', '', '', '0000-00-00', '', '192.168.1.6', 'admin', '2017-10-21 16:29:49');

-- --------------------------------------------------------

--
-- Table structure for table `master_fees`
--

CREATE TABLE `master_fees` (
  `auto_number` int(15) NOT NULL,
  `feecategoryanum` int(255) NOT NULL,
  `feecategory` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orderno` int(255) NOT NULL,
  `feesanum` int(255) NOT NULL,
  `fees` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `amount` decimal(13,2) NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_fees`
--

INSERT INTO `master_fees` (`auto_number`, `feecategoryanum`, `feecategory`, `orderno`, `feesanum`, `fees`, `amount`, `status`, `updatedby`, `updatedate`, `ipaddress`) VALUES
(1, 1, 'New Admission', 1, 1, 'BUILDING FEE', '0.00', '', 'admin', '2017-10-20 11:40:32', '192.168.1.9'),
(2, 3, 'Hostel New', 1, 1, 'BUILDING FEE', '0.00', '', 'admin', '2017-10-20 11:40:32', '192.168.1.9'),
(3, 1, 'New Admission', 2, 2, 'TUTION FEE', '0.00', '', 'admin', '2017-10-20 11:40:44', '192.168.1.9'),
(4, 2, 'Old Admission', 2, 2, 'TUTION FEE', '0.00', '', 'admin', '2017-10-20 11:40:44', '192.168.1.9'),
(5, 3, 'Hostel New', 2, 2, 'TUTION FEE', '0.00', '', 'admin', '2017-10-20 11:40:44', '192.168.1.9'),
(6, 4, 'Hostel Old', 2, 2, 'TUTION FEE', '0.00', '', 'admin', '2017-10-20 11:40:44', '192.168.1.9'),
(7, 1, 'New Admission', 3, 3, 'UNIFORM FEE', '0.00', '', 'admin', '2017-10-20 11:41:00', '192.168.1.9'),
(8, 3, 'Hostel New', 3, 3, 'UNIFORM FEE', '0.00', '', 'admin', '2017-10-20 11:41:00', '192.168.1.9'),
(9, 1, 'New Admission', 4, 4, 'BOOK FEES', '0.00', '', 'admin', '2017-10-20 11:41:09', '192.168.1.9'),
(10, 2, 'Old Admission', 4, 4, 'BOOK FEES', '0.00', '', 'admin', '2017-10-20 11:41:09', '192.168.1.9'),
(11, 3, 'Hostel New', 4, 4, 'BOOK FEES', '0.00', '', 'admin', '2017-10-20 11:41:09', '192.168.1.9'),
(12, 4, 'Hostel Old', 4, 4, 'BOOK FEES', '0.00', '', 'admin', '2017-10-20 11:41:09', '192.168.1.9'),
(13, 1, 'New Admission', 5, 5, 'EXAM FEES', '0.00', '', 'admin', '2017-10-20 11:41:32', '192.168.1.9'),
(14, 2, 'Old Admission', 5, 5, 'EXAM FEES', '0.00', '', 'admin', '2017-10-20 11:41:32', '192.168.1.9'),
(15, 3, 'Hostel New', 5, 5, 'EXAM FEES', '0.00', '', 'admin', '2017-10-20 11:41:32', '192.168.1.9'),
(16, 4, 'Hostel Old', 5, 5, 'EXAM FEES', '0.00', '', 'admin', '2017-10-20 11:41:32', '192.168.1.9'),
(17, 3, 'Hostel New', 6, 6, 'HOSTEL DEPOSIT', '0.00', '', 'admin', '2017-10-20 11:41:49', '192.168.1.9');

-- --------------------------------------------------------

--
-- Table structure for table `master_feesubhead`
--

CREATE TABLE `master_feesubhead` (
  `auto_number` int(255) NOT NULL,
  `feesubhead` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_feesubhead`
--

INSERT INTO `master_feesubhead` (`auto_number`, `feesubhead`, `status`, `ipaddress`, `username`, `updatedatetime`) VALUES
(1, 'BUILDING FEE', '', '192.168.1.9', 'admin', '2017-10-20 11:40:32'),
(2, 'TUTION FEE', '', '192.168.1.9', 'admin', '2017-10-20 11:40:44'),
(3, 'UNIFORM FEE', '', '192.168.1.9', 'admin', '2017-10-20 11:41:00'),
(4, 'BOOK FEES', '', '192.168.1.9', 'admin', '2017-10-20 11:41:09'),
(5, 'EXAM FEES', '', '192.168.1.9', 'admin', '2017-10-20 11:41:32'),
(6, 'HOSTEL DEPOSIT', '', '192.168.1.9', 'admin', '2017-10-20 11:41:49');

-- --------------------------------------------------------

--
-- Table structure for table `master_hostelbed`
--

CREATE TABLE `master_hostelbed` (
  `auto_number` int(255) NOT NULL,
  `blockanum` int(255) NOT NULL,
  `blockname` varchar(255) NOT NULL,
  `roomanum` int(255) NOT NULL,
  `roomnumber` varchar(255) NOT NULL,
  `bednumber` varchar(255) NOT NULL,
  `amount` decimal(13,2) NOT NULL,
  `studentcode` varchar(255) NOT NULL,
  `studentname` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_hostelbed`
--

INSERT INTO `master_hostelbed` (`auto_number`, `blockanum`, `blockname`, `roomanum`, `roomnumber`, `bednumber`, `amount`, `studentcode`, `studentname`, `class`, `section`, `status`, `ipaddress`, `username`, `updatedatetime`) VALUES
(6, 0, 'BLOCK 1', 2, 'R-002', 'B-001', '100.00', '', '', '', '', '', '127.0.0.1', 'admin', '2014-10-08 16:55:45'),
(5, 0, 'BLOCK 1', 1, 'R-001', 'B-001', '100.00', '', '', '', '', '', '127.0.0.1', 'admin', '2014-10-08 16:55:45'),
(7, 0, 'BLOCK 1', 9, 'R-003', 'B-001', '100.00', '', '', '', '', '', '127.0.0.1', 'admin', '2014-10-08 16:55:45'),
(8, 0, 'BLOCK 1', 10, 'R-004', 'B-001', '100.00', '', '', '', '', '', '127.0.0.1', 'admin', '2014-10-08 16:55:45'),
(9, 0, 'BLOCK 1', 1, 'R-001', 'B-002', '100.00', '', '', '', '', '', '127.0.0.1', 'admin', '2014-10-08 16:56:45'),
(10, 0, 'BLOCK 1', 2, 'R-002', 'B-002', '100.00', '', '', '', '', '', '127.0.0.1', 'admin', '2014-10-08 16:56:45'),
(11, 0, 'BLOCK 1', 9, 'R-003', 'B-002', '100.00', '', '', '', '', '', '127.0.0.1', 'admin', '2014-10-08 16:56:45'),
(12, 0, 'BLOCK 1', 10, 'R-004', 'B-002', '100.00', '', '', '', '', '', '127.0.0.1', 'admin', '2014-10-08 16:56:45'),
(13, 0, 'BLOCK 2', 3, 'R-001', 'B-001', '100.00', '', '', '', '', '', '127.0.0.1', 'admin', '2014-10-08 17:22:17'),
(14, 0, 'BLOCK 2', 11, 'R-003', 'B-001', '100.00', '', '', '', '', '', '127.0.0.1', 'admin', '2014-10-08 17:22:17'),
(15, 0, 'BLOCK 5', 13, 'R-001', 'SB-001', '500.00', 'STU00000006', 'studentname', '9', 'G', '', '127.0.0.1', 'admin', '2014-10-11 14:59:14'),
(16, 0, 'BLOCK 5', 14, 'R-002', 'SB-001', '500.00', 'STU00000006', 'Raja  ', '9', 'G', '', '127.0.0.1', 'admin', '2014-10-11 14:59:14'),
(17, 0, 'BLOCK 5', 13, 'R-001', 'SB-002', '500.00', 'STU00000006', 'Raja  ', '9', 'G', '', '127.0.0.1', 'admin', '2014-10-11 14:59:37'),
(18, 0, 'BLOCK 5', 14, 'R-002', 'SB-002', '500.00', 'STU00000009', 'Naresh  ', '8', 'B', '', '127.0.0.1', 'admin', '2014-10-11 14:59:37'),
(19, 6, 'BLOCK 5', 13, 'R-001', 'SB-003', '500.00', 'STU00000005', 'Bharath', 'LKG', 'A', '', '127.0.0.1', 'admin', '2014-10-11 18:08:29'),
(21, 6, 'BLOCK 5', 15, 'ROOM 3', 'BED 1', '750.00', '', '', '', '', '', '127.0.0.1', 'admin', '2014-10-11 19:10:18');

-- --------------------------------------------------------

--
-- Table structure for table `master_hostelroom`
--

CREATE TABLE `master_hostelroom` (
  `auto_number` int(255) NOT NULL,
  `blockanum` int(255) NOT NULL,
  `blockname` varchar(255) NOT NULL,
  `roomnumber` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_hostelroom`
--

INSERT INTO `master_hostelroom` (`auto_number`, `blockanum`, `blockname`, `roomnumber`, `status`, `ipaddress`, `username`, `updatedatetime`) VALUES
(1, 2, 'BLOCK 1', 'R-001', '', '127.0.0.1', '', '2014-10-08 15:43:38'),
(2, 2, 'BLOCK 1', 'R-002', '', '127.0.0.1', '', '2014-10-08 15:43:54'),
(3, 3, 'BLOCK 2', 'R-001', '', '127.0.0.1', '', '2014-10-08 15:44:06'),
(4, 3, 'BLOCK 2', 'R-002', '', '127.0.0.1', '', '2014-10-08 15:44:12'),
(5, 4, 'BLOCK 3', 'R-001', '', '127.0.0.1', '', '2014-10-08 15:44:18'),
(6, 4, 'BLOCK 3', 'R-002', '', '127.0.0.1', '', '2014-10-08 15:44:22'),
(7, 5, 'BLOCK 4', 'R-001', '', '127.0.0.1', '', '2014-10-08 15:44:28'),
(8, 5, 'BLOCK 4', 'R-002', 'deleted', '127.0.0.1', '', '2014-10-08 15:44:33'),
(9, 2, 'BLOCK 1', 'R-003', '', '127.0.0.1', 'admin', '2014-10-08 15:45:28'),
(10, 2, 'BLOCK 1', 'R-004', '', '127.0.0.1', 'admin', '2014-10-08 15:45:38'),
(11, 3, 'BLOCK 2', 'R-003', '', '127.0.0.1', 'admin', '2014-10-08 15:55:19'),
(12, 3, 'BLOCK 2', 'R-004', '', '127.0.0.1', 'admin', '2014-10-08 15:55:40'),
(13, 6, 'BLOCK 5', 'R-001', 'deleted', '127.0.0.1', 'admin', '2014-10-11 14:58:41'),
(14, 6, 'BLOCK 5', 'R-002', 'deleted', '127.0.0.1', 'admin', '2014-10-11 14:58:51'),
(15, 6, 'BLOCK 5', 'ROOM 3', 'deleted', '127.0.0.1', 'admin', '2014-10-11 19:08:31');

-- --------------------------------------------------------

--
-- Table structure for table `master_hyperlink`
--

CREATE TABLE `master_hyperlink` (
  `auto_number` int(255) NOT NULL,
  `hyperlink` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_internalmarks`
--

CREATE TABLE `master_internalmarks` (
  `auto_number` int(255) NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchyear` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchsection` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `internal` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subjectcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subject` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `maximummarks` int(255) NOT NULL,
  `minimummarks` int(255) NOT NULL,
  `marksscored` int(255) NOT NULL,
  `attendance` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_internalmarks`
--

INSERT INTO `master_internalmarks` (`auto_number`, `course`, `batchyear`, `batchsection`, `exam`, `internal`, `subjectcode`, `subject`, `studentid`, `studentname`, `maximummarks`, `minimummarks`, `marksscored`, `attendance`, `updatedby`, `ipaddress`, `updatedate`) VALUES
(10, 'INFORMATION TECHNOLGOY', '2009', 'SECTION A', 'SEMESTER I', 'INTERNAL', 'IT1007', 'ELECTRONICS COMMERCE', 'STD6', 'vinoth', 20, 10, 11, 'PRESENT', 'admin', '192.168.1.15', '2009-05-24 17:34:47'),
(9, 'INFORMATION TECHNOLGOY', '2009', 'SECTION A', 'SEMESTER I', 'INTERNAL', 'IT1007', 'ELECTRONICS COMMERCE', 'STD4', 'Vijay', 20, 10, 10, 'PRESENT', 'admin', '192.168.1.15', '2009-05-24 17:34:47');

-- --------------------------------------------------------

--
-- Table structure for table `master_interviewquestions`
--

CREATE TABLE `master_interviewquestions` (
  `auto_number` int(255) NOT NULL,
  `questionnumber` int(255) NOT NULL,
  `question` text NOT NULL,
  `answertype` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_interviewquestions`
--

INSERT INTO `master_interviewquestions` (`auto_number`, `questionnumber`, `question`, `answertype`, `status`, `username`, `academicyear`, `ipaddress`, `updatedatetime`) VALUES
(1, 1, 'Tell me about yourself.', 'anstext', '', 'admin', '2014', '127.0.0.1', '2014-10-04 07:59:44'),
(2, 2, 'What do you like to do in your free time?', 'anstext', '', 'admin', '2014', '127.0.0.1', '2014-10-04 08:19:36'),
(3, 3, 'What is your favorite subject in school? Why?', 'anstext', '', 'admin', '2014', '127.0.0.1', '2014-10-04 08:20:04'),
(4, 4, 'What is your least favorite subject in school? Why?', 'anstext', '', 'admin', '2014', '127.0.0.1', '2014-10-04 08:20:19'),
(16, 9, 'If yes, their name and class', 'anstext', '', 'admin', '2014', '127.0.0.1', '2014-10-05 04:21:56'),
(15, 8, 'Do you have siblings study here?', 'ansoptions', '', 'admin', '2014', '127.0.0.1', '2014-10-05 04:21:39'),
(14, 7, 'Do you take any medicine?', 'ansoptions', '', 'admin', '2014', '127.0.0.1', '2014-10-05 04:20:43'),
(13, 6, 'If yes, reason', 'anstext', '', 'admin', '2014', '127.0.0.1', '2014-10-05 04:20:21'),
(12, 5, 'Do you have break in study?', 'ansoptions', '', 'admin', '2014', '127.0.0.1', '2014-10-05 04:20:06'),
(17, 10, 'Your favorite sport ', 'anstext', '', 'admin', '2014', '127.0.0.1', '2014-10-05 04:23:31');

-- --------------------------------------------------------

--
-- Table structure for table `master_labcategory`
--

CREATE TABLE `master_labcategory` (
  `auto_number` int(15) NOT NULL,
  `labcategory` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_labcategory`
--

INSERT INTO `master_labcategory` (`auto_number`, `labcategory`, `status`) VALUES
(10, 'ROUTER', ''),
(9, 'SERVER', 'deleted'),
(8, 'COMPUTER', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_labitem`
--

CREATE TABLE `master_labitem` (
  `auto_number` int(255) NOT NULL,
  `labitem` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `labcategoryanum` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `labcategory` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_labitem`
--

INSERT INTO `master_labitem` (`auto_number`, `labitem`, `labcategoryanum`, `labcategory`, `status`) VALUES
(5, 'KEY BOARD', '8', 'COMPUTER', ''),
(11, 'MOUSE', '8', 'COMPUTER', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_labitemissue`
--

CREATE TABLE `master_labitemissue` (
  `auto_number` int(255) NOT NULL,
  `issuedepartment` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `issuedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `issuedate` date NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchyear` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchsection` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `labcategory` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `labitem` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `returncondition` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_labitemissue`
--

INSERT INTO `master_labitemissue` (`auto_number`, `issuedepartment`, `issuedby`, `issuedate`, `course`, `exam`, `batchyear`, `batchsection`, `studentid`, `studentname`, `labcategory`, `labitem`, `returncondition`, `updatedby`, `updatedate`, `ipaddress`) VALUES
(1, 'INFORMATION TECHNOLOGY ', 'admin', '2009-05-28', 'INFORMATION TECHNOLGOY', 'SEMESTER I', '2009', 'SECTION A', 'STD8', 'Sowmiya', 'COMPUTER', 'KEY BOARD', 'GOOD', 'admin', '2009-05-28 20:19:26', '192.168.1.15'),
(2, 'INFORMATION TECHNOLOGY ', 'admin', '2009-05-28', 'INFORMATION TECHNOLGOY', 'SEMESTER I', '2009', 'SECTION A', 'STD4', 'Vijay', 'COMPUTER', 'MOUSE', 'NO RETURN', 'admin', '2009-05-28 20:19:26', '192.168.1.15'),
(3, 'INFORMATION TECHNOLOGY ', 'admin', '2009-05-28', 'INFORMATION TECHNOLGOY', 'SEMESTER I', '2009', 'SECTION A', 'STD6', 'vinoth', 'COMPUTER', 'KEY BOARD', 'BROKEN', 'admin', '2009-05-28 20:19:26', '192.168.1.15'),
(18, 'INFORMATION TECHNOLOGY ', 'admin', '2009-05-27', 'INFORMATION TECHNOLGOY', 'SEMESTER I', '2009', 'SECTION A', 'STD6', 'vinoth', 'COMPUTER', 'KEY BOARD', 'NO RETURN', 'admin', '2009-05-28 21:42:39', '192.168.1.15'),
(17, 'INFORMATION TECHNOLOGY ', 'admin', '2009-05-27', 'INFORMATION TECHNOLGOY', 'SEMESTER I', '2009', 'SECTION A', 'STD4', 'Vijay', 'COMPUTER', 'KEY BOARD', 'BROKEN', 'admin', '2009-05-28 21:42:39', '192.168.1.15'),
(16, 'INFORMATION TECHNOLOGY ', 'admin', '2009-05-27', 'INFORMATION TECHNOLGOY', 'SEMESTER I', '2009', 'SECTION A', 'STD8', 'Sowmiya', 'COMPUTER', 'KEY BOARD', 'GOOD', 'admin', '2009-05-28 21:42:39', '192.168.1.15'),
(19, 'INFORMATION TECHNOLOGY ', 'admin', '2009-07-16', 'INFORMATION TECHNOLGOY', 'SEMESTER I', '2009', 'SECTION A', 'STD8', 'Sowmiya', 'COMPUTER', 'KEY BOARD', '', 'admin', '2009-08-15 12:47:23', '122.164.160.119'),
(20, 'INFORMATION TECHNOLOGY ', 'admin', '2009-07-16', 'INFORMATION TECHNOLGOY', 'SEMESTER I', '2009', 'SECTION A', 'STD4', 'Vijay', 'COMPUTER', 'MOUSE', '', 'admin', '2009-08-15 12:47:23', '122.164.160.119'),
(21, 'INFORMATION TECHNOLOGY ', 'admin', '2009-07-16', 'INFORMATION TECHNOLGOY', 'SEMESTER I', '2009', 'SECTION A', 'STD6', 'vinoth', 'COMPUTER', 'MOUSE', '', 'admin', '2009-08-15 12:47:23', '122.164.160.119');

-- --------------------------------------------------------

--
-- Table structure for table `master_lendingperiod`
--

CREATE TABLE `master_lendingperiod` (
  `auto_number` int(255) NOT NULL,
  `periodname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `daysallowed` int(255) NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_lendingperiod`
--

INSERT INTO `master_lendingperiod` (`auto_number`, `periodname`, `daysallowed`, `status`) VALUES
(1, 'WEEKLY', 7, 'deleted'),
(2, 'MONTHLY', 30, 'deleted');

-- --------------------------------------------------------

--
-- Table structure for table `master_menumain`
--

CREATE TABLE `master_menumain` (
  `auto_number` int(255) NOT NULL,
  `mainmenuid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `mainmenuorder` decimal(13,2) NOT NULL,
  `mainmenutext` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `mainmenulink` text COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_menumain`
--

INSERT INTO `master_menumain` (`auto_number`, `mainmenuid`, `mainmenuorder`, `mainmenutext`, `mainmenulink`, `status`, `datetime`) VALUES
(1, 'MM01', '1.00', 'school', '#', '', '2017-10-16 09:54:30'),
(2, 'MM02', '2.00', 'student', '#', 'deleted', '2017-10-16 10:36:18'),
(3, 'MM03', '2.00', 'student', '#', '', '2017-10-16 12:24:46');

-- --------------------------------------------------------

--
-- Table structure for table `master_menusub`
--

CREATE TABLE `master_menusub` (
  `auto_number` int(255) NOT NULL,
  `mainmenuid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `submenuid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `submenuorder` int(255) NOT NULL,
  `submenutext` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `submenulink` text COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_menusub`
--

INSERT INTO `master_menusub` (`auto_number`, `mainmenuid`, `submenuid`, `submenuorder`, `submenutext`, `submenulink`, `status`, `datetime`) VALUES
(1, 'MM01', 'SM2', 1, 'schoo info1', '##ss', '', '2017-10-16 11:18:40');

-- --------------------------------------------------------

--
-- Table structure for table `master_modelexam`
--

CREATE TABLE `master_modelexam` (
  `auto_number` int(15) NOT NULL,
  `modelexam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_modelexam`
--

INSERT INTO `master_modelexam` (`auto_number`, `modelexam`, `exam`, `status`) VALUES
(17, 'MODEL EXAM I ', '', ''),
(18, 'MODEL EXAM II ', '', ''),
(19, 'MODEL EXAM III', '', ''),
(20, 'MODEL EXAM IV', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_modelexammarks`
--

CREATE TABLE `master_modelexammarks` (
  `auto_number` int(255) NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchyear` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchsection` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `modelexam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subjectcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subject` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `maximummarks` int(255) NOT NULL,
  `minimummarks` int(255) NOT NULL,
  `marksscored` int(255) NOT NULL,
  `attendance` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_modelexammarks`
--

INSERT INTO `master_modelexammarks` (`auto_number`, `course`, `batchyear`, `batchsection`, `exam`, `modelexam`, `subjectcode`, `subject`, `studentid`, `studentname`, `maximummarks`, `minimummarks`, `marksscored`, `attendance`, `updatedby`, `ipaddress`, `updatedate`) VALUES
(14, 'INFORMATION TECHNOLGOY', '2009', 'SECTION A', 'SEMESTER I', 'MODEL EXAM I ', 'IT1007', 'ELECTRONICS COMMERCE', 'STD6', 'vinoth', 100, 40, 90, 'PRESENT', 'admin', '192.168.1.15', '2009-05-24 17:33:07'),
(13, 'INFORMATION TECHNOLGOY', '2009', 'SECTION A', 'SEMESTER I', 'MODEL EXAM I ', 'IT1007', 'ELECTRONICS COMMERCE', 'STD4', 'Vijay', 100, 40, 80, 'PRESENT', 'admin', '192.168.1.15', '2009-05-24 17:33:07');

-- --------------------------------------------------------

--
-- Table structure for table `master_module`
--

CREATE TABLE `master_module` (
  `auto_number` int(255) NOT NULL,
  `modulename` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_module`
--

INSERT INTO `master_module` (`auto_number`, `modulename`, `status`, `updatedate`) VALUES
(1, 'Applications', '', '2009-05-15 18:54:33'),
(2, 'Student', 'deleted', '2009-05-15 18:54:33'),
(3, 'Staff', 'deleted', '2009-05-15 18:54:33'),
(4, 'Library', 'deleted', '2009-05-15 18:54:33'),
(5, 'Hostel', '', '2009-05-15 18:54:33'),
(7, 'Transport', '', '2009-05-15 18:54:33'),
(8, 'Attendance', 'deleted', '2009-05-15 18:54:33'),
(10, 'Payroll', 'deleted', '2009-05-15 18:54:33'),
(11, 'Admission', '', '2009-05-15 18:54:33'),
(12, 'Fees', '', '2009-05-15 18:54:33'),
(13, 'Masters', 'deleted', '2009-05-15 18:54:33'),
(15, 'Staff Login', 'deleted', '2009-05-15 18:54:33'),
(17, 'Enquiry', '', '2014-09-30 10:38:52');

-- --------------------------------------------------------

--
-- Table structure for table `master_nextteacher`
--

CREATE TABLE `master_nextteacher` (
  `auto_number` int(255) NOT NULL,
  `nextteacherid` varchar(255) NOT NULL,
  `mainteacherid` varchar(255) NOT NULL,
  `mainteacher` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `nextteacher` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `master_otherinfo`
--

CREATE TABLE `master_otherinfo` (
  `auto_number` int(255) NOT NULL,
  `studentcode` varchar(255) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `birthcountry` varchar(255) NOT NULL,
  `tcno` varchar(255) NOT NULL,
  `tcdate` varchar(255) NOT NULL,
  `permanentaddress` varchar(255) NOT NULL,
  `documentsmissing` varchar(255) NOT NULL,
  `bloodgroup` varchar(255) NOT NULL,
  `teacherschildren` varchar(255) NOT NULL,
  `aadharno` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `validfrom` varchar(255) NOT NULL,
  `expiry` varchar(255) NOT NULL,
  `passportnu` varchar(255) NOT NULL,
  `passissuedate` varchar(255) NOT NULL,
  `passportexpiry` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedate` varchar(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_otherinfo`
--

INSERT INTO `master_otherinfo` (`auto_number`, `studentcode`, `nationality`, `birthcountry`, `tcno`, `tcdate`, `permanentaddress`, `documentsmissing`, `bloodgroup`, `teacherschildren`, `aadharno`, `status`, `validfrom`, `expiry`, `passportnu`, `passissuedate`, `passportexpiry`, `ipaddress`, `updatedate`, `academicyear`, `username`, `locationname`, `locationcode`, `recorddate`) VALUES
(1, 'STU00000001', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.23', '2017-10-24 16:15:08', '2005-01', 'admin', 'HYD', 'LOC-1', '2017-10-24'),
(2, 'STU00000002', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.10', '2017-10-25 15:24:30', '2017-18', 'admin', 'HYD', 'LOC-1', '2017-10-25'),
(3, 'STU00000003', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.10', '2017-10-25 18:01:05', '2017-18', 'admin', 'HYD', 'LOC-1', '2017-10-25'),
(4, 'STU00000004', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.10', '2017-10-25 18:03:23', '2017-18', 'admin', 'HYD', 'LOC-1', '2017-10-25'),
(5, 'STU00000005', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.10', '2017-10-25 18:06:13', '2017-18', 'admin', 'HYD', 'LOC-1', '2017-10-25'),
(6, 'STU00000001', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.25', '2017-10-31 11:42:01', '2017-18(CBSE)', 'admin', 'HYD', 'LOC-1', '2017-10-31');

-- --------------------------------------------------------

--
-- Table structure for table `master_parent`
--

CREATE TABLE `master_parent` (
  `auto_number` int(255) NOT NULL,
  `studentcode` varchar(255) NOT NULL,
  `fathername` varchar(255) NOT NULL,
  `fatherincome` varchar(255) NOT NULL,
  `fatheroccupation` varchar(255) NOT NULL,
  `fathequa` varchar(255) NOT NULL,
  `famobilenumber` varchar(255) NOT NULL,
  `femailid` varchar(255) NOT NULL,
  `fbld` varchar(255) NOT NULL,
  `mothername` varchar(255) NOT NULL,
  `motherincome` varchar(255) NOT NULL,
  `motheroccupation` varchar(255) NOT NULL,
  `motherqua` varchar(255) NOT NULL,
  `mobilenumbermother` varchar(255) NOT NULL,
  `memailid` varchar(255) NOT NULL,
  `mbld` varchar(255) NOT NULL,
  `guardianname` varchar(255) NOT NULL,
  `relation` varchar(255) NOT NULL,
  `gaurdianoccupation` varchar(255) NOT NULL,
  `guardianqua` varchar(255) NOT NULL,
  `mobilenumber` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedate` varchar(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_parent`
--

INSERT INTO `master_parent` (`auto_number`, `studentcode`, `fathername`, `fatherincome`, `fatheroccupation`, `fathequa`, `famobilenumber`, `femailid`, `fbld`, `mothername`, `motherincome`, `motheroccupation`, `motherqua`, `mobilenumbermother`, `memailid`, `mbld`, `guardianname`, `relation`, `gaurdianoccupation`, `guardianqua`, `mobilenumber`, `ipaddress`, `updatedate`, `academicyear`, `username`, `locationname`, `locationcode`, `recorddate`, `status`) VALUES
(1, 'STU00000001', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.23', '2017-10-24 16:14:56', '2005-01', 'admin', 'HYD', 'LOC-1', '2017-10-24', ''),
(2, 'STU00000002', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.10', '2017-10-25 15:24:28', '2017-18', 'admin', 'HYD', 'LOC-1', '2017-10-25', ''),
(3, 'STU00000003', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.10', '2017-10-25 18:01:03', '2017-18', 'admin', 'HYD', 'LOC-1', '2017-10-25', ''),
(4, 'STU00000004', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.10', '2017-10-25 18:03:21', '2017-18', 'admin', 'HYD', 'LOC-1', '2017-10-25', ''),
(5, 'STU00000005', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.10', '2017-10-25 18:06:11', '2017-18', 'admin', 'HYD', 'LOC-1', '2017-10-25', ''),
(6, 'STU00000001', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.25', '2017-10-31 11:41:54', '2017-18(CBSE)', 'admin', 'HYD', 'LOC-1', '2017-10-31', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_point`
--

CREATE TABLE `master_point` (
  `auto_number` int(255) NOT NULL,
  `routeanum` varchar(255) NOT NULL,
  `routename` varchar(255) NOT NULL,
  `pointnumber` varchar(255) NOT NULL,
  `pointname` varchar(255) NOT NULL,
  `pointamount` decimal(13,2) NOT NULL,
  `pickuphour` varchar(255) NOT NULL,
  `pickupmin` varchar(255) NOT NULL,
  `pickupformat` varchar(255) NOT NULL,
  `drophour` varchar(255) NOT NULL,
  `dropmin` varchar(255) NOT NULL,
  `dropformat` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_point`
--

INSERT INTO `master_point` (`auto_number`, `routeanum`, `routename`, `pointnumber`, `pointname`, `pointamount`, `pickuphour`, `pickupmin`, `pickupformat`, `drophour`, `dropmin`, `dropformat`, `status`, `ipaddress`, `username`, `updatedatetime`) VALUES
(1, '1', 'S R Nagar Route', '1', 'Patny', '1000.00', '07', '45', 'AM', '03', '55', 'PM', '', '192.168.1.13', 'admin', '2017-10-17 10:16:37'),
(2, '1', 'S R Nagar Route', '2', 'Begumpet - Airport', '1500.00', '07', '55', 'AM', '04', '05', 'PM', '', '192.168.1.13', 'admin', '2017-10-17 10:17:22'),
(3, '1', 'S R Nagar Route', '3', 'Begumpet - Lifestyle', '2000.00', '08', '10', 'AM', '04', '15', 'PM', '', '192.168.1.13', 'admin', '2017-10-17 10:18:03'),
(4, '1', 'S R Nagar Route', '4', 'Ameerpet', '2250.00', '08', '20', 'AM', '04', '30', 'PM', '', '192.168.1.13', 'admin', '2017-10-17 10:18:40'),
(5, '2', 'Dilsuknagar', '1', 'Koti', '1000.00', '08', '00', 'AM', '04', '00', 'AM', '', '192.168.1.8', 'admin', '2017-10-17 11:08:27');

-- --------------------------------------------------------

--
-- Table structure for table `master_programme`
--

CREATE TABLE `master_programme` (
  `auto_number` int(15) NOT NULL,
  `programme` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_programme`
--

INSERT INTO `master_programme` (`auto_number`, `programme`, `status`) VALUES
(1, 'UG', ''),
(2, 'PG', ''),
(7, 'DOCTORATE', ''),
(5, 'DIPLOMA', ''),
(6, 'PG DIPLOMA', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_qualification`
--

CREATE TABLE `master_qualification` (
  `auto_number` int(255) NOT NULL,
  `qualification` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `category` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_qualification`
--

INSERT INTO `master_qualification` (`auto_number`, `qualification`, `category`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, 'BSC', 'UG', '', '', '', '', '', '', ''),
(2, 'MSC', 'PG', '', '', '', '', '', '', ''),
(3, 'BCOM', 'UG', 'deleted', '', '', '', '', '', ''),
(4, 'MCOM', 'PG', '', '', '', '', '', '', ''),
(5, 'MPHIL', 'DOCTORATE', '', '', '', '', '', '', ''),
(6, 'MBA', 'PG', '', '', '', '', '', '', ''),
(7, 'BBA', 'UG', 'deleted', '', '', '', '', '', ''),
(11, 'MA', 'PG', '', '', '', '', '', '', ''),
(8, 'BES', 'UG', '', '', '', '', '', '', ''),
(9, 'MLIS', 'PG', '', '', '', '', '', '', ''),
(12, 'BA', 'UG', '', '', '', '', '', '', ''),
(13, 'BCA', 'UG', 'deleted', '', '', '', '', '', ''),
(14, 'MED', 'PG', '', '', '', '', '', '', ''),
(15, 'DIPLOMA', 'DIPLOMA', 'deleted', '', '', '', '', '', ''),
(17, 'PG DIPLOMA', 'DIPLOMA', '', '', '', '', '', '', ''),
(18, 'BE', 'UG', 'deleted', '', '', '', '', '', ''),
(19, 'B.TECH-', 'UG', '', '', '', '', '', '', ''),
(20, 'MS', 'PG', '', '2017-10-05 ', '2017-10-05 13:37:59', 'admin', '::1', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_religion`
--

CREATE TABLE `master_religion` (
  `auto_number` int(15) NOT NULL,
  `religion` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_religion`
--

INSERT INTO `master_religion` (`auto_number`, `religion`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, 'Hindu', '', '', '', '', '', '', ''),
(2, 'Christian', '', '', '', '', '', '', ''),
(3, 'Muslim', 'deleted', '', '', '', '', '', ''),
(4, 'Sikh', 'deleted', '', '', '', '', '', ''),
(5, 'Buddhist', '', '', '', '', '', '', ''),
(6, 'hh', '', '2017-10-11 ', '2017-10-11 15:18:05', 'admin', '192.168.1.9', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_route`
--

CREATE TABLE `master_route` (
  `auto_number` int(255) NOT NULL,
  `routename` varchar(255) NOT NULL,
  `vehiclenumber` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_route`
--

INSERT INTO `master_route` (`auto_number`, `routename`, `vehiclenumber`, `status`, `ipaddress`, `updatedatetime`) VALUES
(1, 'S R Nagar Route', 'BUS 1', '', '192.168.1.13', '2017-10-17 10:15:40'),
(2, 'Dilsuknagar', 'BUS 2', '', '192.168.1.8', '2017-10-17 11:07:30');

-- --------------------------------------------------------

--
-- Table structure for table `master_school`
--

CREATE TABLE `master_school` (
  `auto_number` int(255) NOT NULL,
  `schoolcode` varchar(255) NOT NULL,
  `schoolname` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `phone1` varchar(255) NOT NULL,
  `phone2` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ipaddress` varchar(225) NOT NULL,
  `locationname` varchar(225) NOT NULL,
  `locationcode` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_school`
--

INSERT INTO `master_school` (`auto_number`, `schoolcode`, `schoolname`, `address1`, `address2`, `city`, `state`, `pincode`, `phone1`, `phone2`, `mobile`, `email`, `website`, `photo`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, 'SCH01', 'Millenium\'s Digital School', 'Hydrabad', '', 'Coimbatore', 'Tamil Nadu', '505678', '9978564381', '8567893347', '9959468513', 'exite@gmail.com', 'www.w3school.com', '', '2017-10-31 ', '2017-10-31 17:33:38', 'admin', '::1', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_section`
--

CREATE TABLE `master_section` (
  `auto_number` int(15) NOT NULL,
  `class` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_section`
--

INSERT INTO `master_section` (`auto_number`, `class`, `section`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, '', 'A', '', '2017-10-27 ', '2017-10-27 11:44:48', 'admin', '::1', 'HYD', 'LOC-1'),
(2, '', 'B', '', '2017-10-27 ', '2017-10-27 11:44:51', 'admin', '::1', 'HYD', 'LOC-1'),
(3, '', 'C', '', '2017-10-27 ', '2017-10-27 11:44:54', 'admin', '::1', 'HYD', 'LOC-1'),
(4, '', 'D', '', '2017-10-27 ', '2017-10-27 11:44:58', 'admin', '::1', 'HYD', 'LOC-1'),
(5, '', 'E', '', '2017-10-27 ', '2017-10-27 11:45:02', 'admin', '::1', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_semestermarks`
--

CREATE TABLE `master_semestermarks` (
  `auto_number` int(255) NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchyear` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchsection` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subjectcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subject` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `maximummarks` int(255) NOT NULL,
  `minimummarks` int(255) NOT NULL,
  `marksscored` int(255) NOT NULL,
  `attendance` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_semestermarks`
--

INSERT INTO `master_semestermarks` (`auto_number`, `course`, `batchyear`, `batchsection`, `exam`, `subjectcode`, `subject`, `studentid`, `studentname`, `maximummarks`, `minimummarks`, `marksscored`, `attendance`, `updatedby`, `ipaddress`, `updatedate`) VALUES
(10, 'INFORMATION TECHNOLGOY', '2009', 'SECTION A', 'SEMESTER I', 'IT1007', 'ELECTRONICS COMMERCE', 'STD6', 'vinoth', 100, 40, 60, 'PRESENT', 'admin', '192.168.1.15', '2009-05-24 17:35:48'),
(9, 'INFORMATION TECHNOLGOY', '2009', 'SECTION A', 'SEMESTER I', 'IT1007', 'ELECTRONICS COMMERCE', 'STD4', 'Vijay', 100, 40, 80, 'PRESENT', 'admin', '192.168.1.15', '2009-05-24 17:35:48');

-- --------------------------------------------------------

--
-- Table structure for table `master_specialization`
--

CREATE TABLE `master_specialization` (
  `auto_number` int(255) NOT NULL,
  `specialization_name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_specialization`
--

INSERT INTO `master_specialization` (`auto_number`, `specialization_name`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(10, 'Computer Science', '', '', '', '', '', '', ''),
(9, 'Maths', '', '', '', '', '', '', ''),
(7, 'Chemistry', '', '', '', '', '', '', ''),
(11, 'Physics', 'deleted', '', '', '', '', '', ''),
(12, 'Biology', 'deleted', '', '', '', '', '', ''),
(16, 'Computer Application', 'deleted', '', '', '', '', '', ''),
(17, 'Literature', 'deleted', '', '', '', '', '', ''),
(19, 'aa', '', '', '', '', '', '', ''),
(20, 'ttrtrttrtrt', '', '', '', '', '', '', ''),
(21, 'science', '', '2017-10-05 ', '2017-10-05 14:41:26', 'admin', '::1', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_staff`
--

CREATE TABLE `master_staff` (
  `auto_number` int(255) NOT NULL,
  `login` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fullname` text COLLATE latin1_general_ci NOT NULL,
  `gender` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `dob` date NOT NULL,
  `diploma` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `diplomamajor` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ug` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ugmajor` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `pg` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `pgmajor` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `doctorate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `doctoratemajor` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `designation` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `department` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `staffcategory` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `stafffortimetable` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `religion` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `community` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `caste` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `communicationaddress` text COLLATE latin1_general_ci NOT NULL,
  `cacity` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `capincode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `castate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `cacountry` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `permanentaddress` text COLLATE latin1_general_ci NOT NULL,
  `pacity` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `papincode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `pastate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `pacountry` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `mobilenumber1` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `mobilenumber2` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `phonenumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `emailid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `bloodgroup` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `passportnumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `remarks` text COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `photourl` text COLLATE latin1_general_ci NOT NULL,
  `doj` date NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_staff`
--

INSERT INTO `master_staff` (`auto_number`, `login`, `password`, `fullname`, `gender`, `dob`, `diploma`, `diplomamajor`, `ug`, `ugmajor`, `pg`, `pgmajor`, `doctorate`, `doctoratemajor`, `designation`, `department`, `staffcategory`, `stafffortimetable`, `religion`, `community`, `caste`, `communicationaddress`, `cacity`, `capincode`, `castate`, `cacountry`, `permanentaddress`, `pacity`, `papincode`, `pastate`, `pacountry`, `mobilenumber1`, `mobilenumber2`, `phonenumber`, `emailid`, `bloodgroup`, `passportnumber`, `remarks`, `status`, `photourl`, `doj`, `ipaddress`, `updatedate`) VALUES
(2, 'admin', 'admin', 'Administrator', 'MALE', '1950-01-01', 'DIPLOMA', 'Computer Science', 'BSC', 'Maths', 'MSC', 'Physics', 'MPHIL', 'Biology', 'Lab Assistant', 'INFORMATION TECHNOLOGY ', 'Management', '', 'Christian', 'BC', 'Adi Dravidar', 'Communication Address ', 'CA City ', 'CA Pincode ', 'CA State ', 'CA Country ', 'Permanent Address ', 'PA City ', 'PA Pincode', 'PA State ', 'PA Country ', 'Mobile Number 1', 'Mobile Number 2 ', 'Phone Number ', 'email@email.com', 'Blood Group ', 'Passport Number ', 'Remarks', 'Active', '', '1951-02-02', '192.168.1.15', '2009-05-17 18:09:35'),
(3, 'STF3', 'STF3', 'Venkatesan', 'MALE', '1951-02-02', 'PG DIPLOMA', 'Maths', 'BBA', 'Maths', 'MCOM', 'Maths', 'MPHIL', 'Maths', 'Professor', 'INFORMATION TECHNOLOGY ', 'Teaching', 'yes', 'Christian', 'FC', 'Adi Dravidar', 'fdf', 'city', 'pincode', 'Arunachal Pradesh', 'Albania', 'fdf', 'city', 'PA Pincode', 'Arunachal Pradesh', 'Albania', '98412', '35522', '424548', 'email@email.com', 'Blood Group 1', '25', 'remarks', 'Active', '', '1951-03-04', '192.168.1.15', '2009-05-24 18:10:19'),
(4, 'STF4', 'STF4', 'Sivanesan', '', '1951-03-03', 'PG DIPLOMA', 'Maths', 'BA', 'Computer Science', 'MCOM', 'Maths', 'MPHIL', 'Computer Science', 'Professor', 'INFORMATION TECHNOLOGY ', 'Teaching', 'yes', 'Hindu', 'FC', 'Chettiyar', 'ca', 'city', 'pincode', 'Arunachal Pradesh', 'Albania', 'pa', 'city', 'PA Pincode', 'Arunachal Pradesh', 'Albania', '98412', '35522', '424548', 'email@email.com', 'Blood Group 1', '25', 'remarks', 'Active', '', '1951-02-02', '192.168.1.15', '2009-05-26 15:15:03'),
(5, 'STF5', 'STF5', 'RAVI KUMAR', 'MALE', '1973-01-10', 'PG DIPLOMA', 'Computer Science', 'BSC', 'Computer Science', 'MSC', 'Computer Science', '', 'Computer Science', 'Professor', 'COMPUTER SCIENCE AND ENGINEERING ', 'Teaching', 'yes', 'Hindu', '', '', 'KJHH 23564', 'CHENNAI', '600012', 'Tamil Nadu', 'India', 'GHY 56465', '', '', '', '', '9999999999', '', '', '', '', '', '', 'Active', '', '2014-09-16', '192.168.1.14', '2014-09-17 18:45:35'),
(6, 'STF6', 'STF6', 'Vasudevan', 'MALE', '1990-04-13', 'PG DIPLOMA', 'Computer Science', 'BSC', 'Computer Science', 'MSC', 'Computer Science', 'MPHIL', 'Computer Science', 'Professor', 'COMPUTER SCIENCE AND ENGINEERING ', 'Teaching', 'yes', 'Hindu', 'MBC', 'Chettiyar', 'Chennai', 'Chennai', '600100', 'Tamil Nadu', 'India', 'Namakkal', 'Namakkal', '637019', 'Tamil Nadu', 'India', '9442144768', '', '', 'vasu@gmail.com', 'o+', '', '', 'Active', '', '2014-09-05', '127.0.0.1', '2014-09-22 15:57:59'),
(7, 'STF7', 'STF7', 'Bharath', 'MALE', '1991-07-02', 'PG DIPLOMA', '', 'BSC', 'Computer Science', '', '', '', '', 'Professor', 'COMPUTER SCIENCE AND ENGINEERING ', 'Management', 'yes', '', '', '', '', '', '', 'Tamil Nadu', 'India', '', '', '', 'Tamil Nadu', 'India', '', '', '', '', '', '', '', 'Active', '', '2001-09-10', '127.0.0.1', '2014-09-22 16:13:10'),
(8, 'STF8', 'STF8', 'Naveen', 'MALE', '1992-03-05', '', '', '', '', 'MSC', 'Computer Science', '', '', 'Lecturer', 'COMPUTER SCIENCE AND ENGINEERING ', 'Management', 'yes', '', '', '', '', '', '', 'Tamil Nadu', 'India', '', '', '', 'Tamil Nadu', 'India', '', '', '', '', '', '', '', 'Active', 'staffimages/STF8.jpg', '2000-02-03', '127.0.0.1', '2014-09-22 16:27:55'),
(9, 'STF9', 'STF9', 'Krishnan', 'MALE', '1960-04-03', 'PG DIPLOMA', 'Maths', '', '', '', '', '', '', 'Professor', 'COMPUTER SCIENCE AND ENGINEERING ', 'Teaching', 'yes', 'Hindu', '', 'Chettiyar', 'fds', 'chennai', '', 'Tamil Nadu', 'India', 'fsdf', 'chennai', '', 'Tamil Nadu', 'India', '85456465456', '', '', '', '', '', '', 'Active', '', '2014-03-03', '127.0.0.1', '2014-09-29 11:50:53'),
(10, '', '', 'Beena', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', 'yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00 00:00:00'),
(11, '', '', 'Ritu', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', 'yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00 00:00:00'),
(12, '', '', 'Deborah', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', 'yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00 00:00:00'),
(13, '', '', 'Saberi', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', 'yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00 00:00:00'),
(14, '', '', 'Florance', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', 'yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00 00:00:00'),
(15, '', '', 'Sreedevi', '', '0000-00-00', ' ', '', '', '', '', '', '', '', '', '', '', 'yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00 00:00:00'),
(16, '', '', 'Arundhati', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', 'yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00 00:00:00'),
(17, '', '', 'Nikitha', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', 'yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00 00:00:00'),
(18, 'STF18', 'STF18', 'w', 'FEMALE', '0000-00-00', '', '', '', '', '', '', '', '', 'Administrator', 'ELECTRONICS AND COMMUNICATION ENGINEERING ', 'Management', 'yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Active', '', '0000-00-00', '192.168.1.16', '2017-10-13 15:34:37'),
(19, 'STF19', 'STF19', 'c', 'FEMALE', '0000-00-00', '', '', '', '', '', '', '', '', 'Lecturer', 'ELECTRONICS AND COMMUNICATION ENGINEERING ', 'Teaching', 'yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Active', 'staffimages/STF19.jpg', '0000-00-00', '192.168.1.6', '2017-10-24 10:41:38'),
(20, 'STF20', 'STF20', 'trdg', 'FEMALE', '1952-03-04', 'PG DIPLOMA', 'Maths', 'BES', 'Computer Science', 'MCOM', 'Computer Science', '', 'Maths', 'Administrator', 'ELECTRICAL ENGINEERING', 'Teaching', 'yes', 'Buddhist', 'bc', 'FBc', 'fgggggggf', 'fgfh', 'hgh', 'Andaman & Nicobar', 'Austria', 'hgjhgj', 'gjhgj', 'gjgj', 'ANDHRA PRADESH', 'Jamaica', 'ghfhf', 'nghg', 'ghghg', 'gjg', 'gjg', 'hgjhg', 'gjhgjhg', 'Active', 'staffimages/STF20.jpg', '1961-05-10', '::1', '2017-10-26 16:02:38'),
(21, 'STF21', 'STF21', 'trdg', 'FEMALE', '1952-03-04', 'PG DIPLOMA', 'Maths', 'BES', 'Computer Science', 'MCOM', 'Computer Science', '', 'Maths', 'Administrator', 'ELECTRICAL ENGINEERING', 'Teaching', 'yes', 'Buddhist', 'bc', 'FBc', 'fgggggggf', 'fgfh', 'hgh', 'Andaman & Nicobar', 'Austria', 'hgjhgj', 'gjhgj', 'gjgj', 'ANDHRA PRADESH', 'Jamaica', 'ghfhf', 'nghg', 'ghghg', 'gjg', 'gjg', 'hgjhg', 'gjhgjhg', 'Active', 'staffimages/STF21.jpg', '1961-05-10', '::1', '2017-10-26 16:02:49');

-- --------------------------------------------------------

--
-- Table structure for table `master_staffcategory`
--

CREATE TABLE `master_staffcategory` (
  `auto_number` int(15) NOT NULL,
  `staffcategory` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_staffcategory`
--

INSERT INTO `master_staffcategory` (`auto_number`, `staffcategory`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(4, 'Stores', 'deleted', '', '', '', '', '', ''),
(5, 'Administration', 'deleted', '', '', '', '', '', ''),
(6, 'Management', '', '', '', '', '', '', ''),
(7, 'Teaching', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_state`
--

CREATE TABLE `master_state` (
  `auto_number` int(15) NOT NULL,
  `state` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_state`
--

INSERT INTO `master_state` (`auto_number`, `state`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, 'Andaman & Nicobar', '', '', '', '', '', '', ''),
(2, 'Haryana', '', '', '', '', '', '', ''),
(3, 'Mizoram', '', '', '', '', '', '', ''),
(4, 'Himachal Pradesh', '', '', '', '', '', '', ''),
(5, 'Nagaland', '', '', '', '', '', '', ''),
(6, 'Arunachal Pradesh', '', '', '', '', '', '', ''),
(7, 'Jammu and Kashmir', '', '', '', '', '', '', ''),
(8, 'Orissa', '', '', '', '', '', '', ''),
(9, 'Assam', '', '', '', '', '', '', ''),
(10, 'Jharkhand', '', '', '', '', '', '', ''),
(11, 'Pondicherry', '', '', '', '', '', '', ''),
(12, 'Bihar', '', '', '', '', '', '', ''),
(13, 'Karnataka', '', '', '', '', '', '', ''),
(14, 'Punjab', '', '', '', '', '', '', ''),
(15, 'Chandigarh', '', '', '', '', '', '', ''),
(16, 'Kerala', '', '', '', '', '', '', ''),
(17, 'Rajasthan', '', '', '', '', '', '', ''),
(18, 'Chhattisgarh', '', '', '', '', '', '', ''),
(19, 'Lakshadweep', '', '', '', '', '', '', ''),
(20, 'Dadra and Nagar', 'deleted', '', '', '', '', '', ''),
(21, 'Madhya Pradesh', '', '', '', '', '', '', ''),
(22, 'Tamil Nadu', '', '', '', '', '', '', ''),
(23, 'Daman and Diu', '', '', '', '', '', '', ''),
(24, 'Maharashtra', '', '', '', '', '', '', ''),
(25, 'Tripura', 'deleted', '', '', '', '', '', ''),
(26, 'Delhi', '', '', '', '', '', '', ''),
(27, 'Manipur', '', '', '', '', '', '', ''),
(28, 'Uttar Pradesh', 'deleted', '', '', '', '', '', ''),
(29, 'Goa', '', '', '', '', '', '', ''),
(30, 'Meghalaya', '', '', '', '', '', '', ''),
(31, 'Uttaranchal', '', '', '', '', '', '', ''),
(32, 'Gujarat', '', '', '', '', '', '', ''),
(33, 'West Bengal', 'deleted', '', '', '', '', '', ''),
(34, 'ANDHRA PRADESH', '', '', '', '', '', '', ''),
(35, 'AP\'S', '', '', '', '', '', '', ''),
(36, 'TS', '', '2017-10-05 ', '2017-10-05 15:37:09', 'admin', '::1', 'HYD', 'LOC-1'),
(37, 'GFG', '', '2017-10-10 ', '2017-10-10 13:50:53', 'admin', '::1', 'HYD', 'LOC-1'),
(38, 'Telangana', '', '2017-10-11 ', '2017-10-11 16:12:42', 'admin', '192.168.1.27', 'HYD', 'LOC-1'),
(39, 'RADHIKA', 'deleted', '2017-10-11 ', '2017-10-11 16:12:54', 'admin', '192.168.1.27', 'HYD', 'LOC-1'),
(40, 'Radhika theatre', '', '2017-10-11 ', '2017-10-11 16:13:44', 'admin', '192.168.1.27', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_student`
--

CREATE TABLE `master_student` (
  `auto_number` int(255) NOT NULL,
  `studentcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `admissionnumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `applicationnumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `rollnumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `academicyear` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `login` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `mname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `gender` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `dob` date NOT NULL,
  `class` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentmobile` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `category` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `admissiontype` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `religion` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `indctn` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `indc` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `caste` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `communicationaddress` text COLLATE latin1_general_ci NOT NULL,
  `city` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `state` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `cacountry` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `permanentaddress` text COLLATE latin1_general_ci NOT NULL,
  `phone` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `mothertng` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `firstlan` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `seconddlan` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `thirdlan` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `typeofentry` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `emailid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `doj` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastschool` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `transport` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `routename` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `pointname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `academicfrommonth` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lastclass` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `remarks` text COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_student`
--

INSERT INTO `master_student` (`auto_number`, `studentcode`, `admissionnumber`, `applicationnumber`, `rollnumber`, `academicyear`, `login`, `fname`, `mname`, `lname`, `gender`, `dob`, `class`, `studentmobile`, `category`, `admissiontype`, `religion`, `indctn`, `indc`, `caste`, `communicationaddress`, `city`, `state`, `cacountry`, `permanentaddress`, `phone`, `mothertng`, `firstlan`, `seconddlan`, `thirdlan`, `typeofentry`, `emailid`, `doj`, `lastschool`, `transport`, `routename`, `pointname`, `academicfrommonth`, `lastclass`, `ipaddress`, `updatedate`, `remarks`, `status`, `username`, `locationname`, `locationcode`, `recorddate`) VALUES
(1, 'STU00000001', 'ADM/2017-18/1000', '', '', '2017-18(SSC)', '', 'Radhika', '', 'Kashaboina', 'female', '2016-01-01', 'I', '', 'Dayscholar', 'newadmission', 'Hindu', 'a', 'b', 'OC', 'Near Radhika Theatre', 'Hyderabad', 'Telangana', 'India', 'Keesara', '', '', 'Hindhi', 'Telugu', 'English', 'Regular', '', '06/01/2017', '', 'on', 'S R Nagar Route', 'Ameerpet', 'Jun-2017', '', '192.168.1.25', '2017-10-31 11:41:41', '', '', 'admin', 'HYD', 'LOC-1', '2017-10-31'),
(2, 'STU00000002', 'ADM/2017-18/1001', '', '', '', '', 'D', '', '', 'male', '2017-10-18', 'I', '', 'Dayscholar', 'newadmission', '', '', '', '', '', 'New Delhi', 'Tamil Nadu', '', '', '', '', '', '', '', 'Regular', '', '10/10/2017', '', '', '', '', '', '', '192.168.1.3', '2017-10-31 12:30:53', '', '', 'admin', 'HYD', 'LOC-1', '2017-10-31'),
(3, 'STU00000003', 'ADM/2017-18/1002', '', '', '', '', 'F', '', '', 'male', '2017-10-12', 'I', '', 'Dayscholar', 'newadmission', '', '', '', '', '', 'New', 'Haryana', '', '', '', '', '', '', '', 'Regular', '', '10/18/2017', '', '', '', '', '', '', '192.168.1.3', '2017-10-31 12:31:55', '', '', 'admin', 'HYD', 'LOC-1', '2017-10-31'),
(4, 'STU00000004', 'ADM/2018/2015-16', '', '', '', '', 'VFDVF', '', '', 'male', '2017-10-09', 'LKG', '', 'Dayscholar', 'newadmission', '', '', '', '', '', 'New Delhi', 'Himachal Pradesh', '', '', '', '', '', '', '', 'Regular', '', '10/16/2017', '', '', '', '', '', '', '192.168.1.3', '2017-10-31 13:16:23', '', '', 'admin', 'HYD', 'LOC-1', '2017-10-31');

-- --------------------------------------------------------

--
-- Table structure for table `master_subject`
--

CREATE TABLE `master_subject` (
  `auto_number` int(255) NOT NULL,
  `subjectfull` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subjectshort` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `is_language` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(225) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_subject`
--

INSERT INTO `master_subject` (`auto_number`, `subjectfull`, `subjectshort`, `is_language`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, 'Telugu', 'TEL', 'on', '', '2017-10-26 ', '2017-10-26 10:19:49', 'admin', '::1', 'HYD', 'LOC-1'),
(2, 'English', 'ENG', 'on', '', '2017-10-26 ', '2017-10-26 10:20:14', 'admin', '::1', 'HYD', 'LOC-1'),
(3, 'Hindhi', 'HIN', 'on', '', '2017-10-26 ', '2017-10-26 10:20:24', 'admin', '::1', 'HYD', 'LOC-1'),
(10, 'Science', 'SCE', '', '', '2017-10-26 ', '2017-10-26 10:23:33', 'admin', '::1', 'HYD', 'LOC-1'),
(9, 'Socialstudies', 'SOC', '', '', '2017-10-26 ', '2017-10-26 10:23:21', 'admin', '::1', 'HYD', 'LOC-1'),
(8, 'Maths', 'MAT', '', '', '2017-10-26 ', '2017-10-26 10:23:07', 'admin', '::1', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_subject1`
--

CREATE TABLE `master_subject1` (
  `auto_number` int(255) NOT NULL,
  `subjectshort` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subjectfull` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` varchar(225) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(225) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_substitution`
--

CREATE TABLE `master_substitution` (
  `auto_number` int(255) NOT NULL,
  `subdate` date NOT NULL,
  `period` varchar(255) NOT NULL,
  `staff` varchar(255) NOT NULL,
  `day` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `substitution` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_substitution`
--

INSERT INTO `master_substitution` (`auto_number`, `subdate`, `period`, `staff`, `day`, `class`, `subject`, `substitution`, `status`, `ipaddress`, `updatedatetime`) VALUES
(1, '2014-09-30', '4', 'Beena', 'TUE', '1A', 'PHYSICS ', 'Arundhati', '', '127.0.0.1', '2014-10-01 11:51:03'),
(2, '2014-09-30', '4', 'Bharath', 'TUE', '1A', 'PHYSICS ', 'Deborah', '', '127.0.0.1', '2014-10-01 11:51:03'),
(3, '2014-09-30', '5', 'Beena', 'TUE', '1A', 'PHYSICS ', 'Florance', '', '127.0.0.1', '2014-10-01 11:51:03'),
(4, '2014-09-30', '5', 'Bharath', 'TUE', '1A', 'PHYSICS ', 'Krishnan', '', '127.0.0.1', '2014-10-01 11:51:03'),
(5, '2014-09-30', '6', 'Beena', 'TUE', '1A', 'SCIENCE ', 'Naveen', '', '127.0.0.1', '2014-10-01 11:51:03'),
(6, '2014-09-30', '6', 'Bharath', 'TUE', '1A', 'SCIENCE ', 'Nikitha', '', '127.0.0.1', '2014-10-01 11:51:03'),
(7, '2014-09-30', '7', 'Beena', 'TUE', '1A', 'SCIENCE ', 'RAVI KUMAR ', '', '127.0.0.1', '2014-10-01 11:51:03'),
(8, '2014-09-30', '7', 'Bharath', 'TUE', '1A', 'SCIENCE ', 'Sivanesan', '', '127.0.0.1', '2014-10-01 11:51:03'),
(13, '2014-10-01', '1', 'Sreedevi', 'WED', 'NURA', 'PHYSICS ', 'Naveen', '', '127.0.0.1', '2014-10-01 12:20:21'),
(14, '2014-10-01', '2', 'Sreedevi', 'WED', 'NURB', 'PHYSICS ', 'Nikitha', '', '127.0.0.1', '2014-10-01 12:20:21'),
(11, '2014-10-01', '3', 'RAVIKUMAR', 'WED', 'LKGA', 'MATHS ', 'Naveen', '', '127.0.0.1', '2014-10-01 12:15:51'),
(15, '2014-10-01', '3', 'Sreedevi', 'WED', 'NURB', 'PHYSICS ', 'RAVI KUMAR ', '', '127.0.0.1', '2014-10-01 12:20:21'),
(16, '2014-10-01', '4', 'Sreedevi', 'WED', 'NURB', 'PHYSICS ', 'Vasudevan ', '', '127.0.0.1', '2014-10-01 12:20:21'),
(17, '2014-09-30', '4', 'Beena', 'TUE', '1A', 'PHYSICS ', 'Deborah', '', '127.0.0.1', '2014-10-01 13:29:11'),
(18, '2014-09-30', '4', 'Bharath', 'TUE', '1A', 'PHYSICS ', 'Arundhati', '', '127.0.0.1', '2014-10-01 13:29:11'),
(19, '2014-09-30', '5', 'Beena', 'TUE', '1A', 'PHYSICS ', 'Florance', '', '127.0.0.1', '2014-10-01 13:29:11'),
(20, '2014-09-30', '5', 'Bharath', 'TUE', '1A', 'PHYSICS ', 'Krishnan', '', '127.0.0.1', '2014-10-01 13:29:11'),
(21, '2014-09-30', '6', 'Beena', 'TUE', '1A', 'SCIENCE ', 'Naveen', '', '127.0.0.1', '2014-10-01 13:29:11'),
(22, '2014-09-30', '6', 'Bharath', 'TUE', '1A', 'SCIENCE ', 'Nikitha', '', '127.0.0.1', '2014-10-01 13:29:11'),
(23, '2014-09-30', '7', 'Beena', 'TUE', '1A', 'SCIENCE ', 'RAVI KUMAR ', '', '127.0.0.1', '2014-10-01 13:29:11'),
(24, '2014-09-30', '7', 'Bharath', 'TUE', '1A', 'SCIENCE ', 'Sreedevi', '', '127.0.0.1', '2014-10-01 13:29:11');

-- --------------------------------------------------------

--
-- Table structure for table `master_teacherallotment`
--

CREATE TABLE `master_teacherallotment` (
  `auto_number` int(255) NOT NULL,
  `teacheranum` varchar(255) NOT NULL,
  `teacher` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `length` varchar(255) NOT NULL,
  `session` varchar(255) NOT NULL,
  `totalsession` varchar(255) NOT NULL,
  `classgroup` varchar(255) NOT NULL,
  `classes` varchar(255) NOT NULL,
  `recordstatus` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL,
  `academicyear` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_teacherallotment`
--

INSERT INTO `master_teacherallotment` (`auto_number`, `teacheranum`, `teacher`, `subject`, `length`, `session`, `totalsession`, `classgroup`, `classes`, `recordstatus`, `username`, `ipaddress`, `updatedatetime`, `academicyear`) VALUES
(1, '', 'Arundhati', 'English', '1', '1', '1', 'ENTIRE CLASS', 'Nursery-A', '', 'admin', '192.168.1.23', '2017-10-24 16:26:13', '2005'),
(2, '', 'RAVI KUMAR', 'Maths', '1', '2', '2', 'ENTIRE CLASS', 'Nursery-B', '', 'admin', '192.168.1.23', '2017-10-24 16:26:46', '2005'),
(3, '', 'Deborah', 'Maths', '1', '1', '1', 'BOYS', 'LKG-ROSE', '', 'admin', '192.168.1.6', '2017-10-24 16:35:19', '2005'),
(4, '', 'Deborah', 'Maths', '1', '1', '1', 'BOYS', 'LKG-ROSE', '', 'admin', '192.168.1.6', '2017-10-24 16:36:12', '2005'),
(5, '', 'Deborah', 'Maths', '1', '1', '1', 'BOYS', 'LKG-ROSE', '', 'admin', '192.168.1.6', '2017-10-24 16:36:29', '2005'),
(6, '', 'Deborah', 'Maths', '1', '1', '1', 'BOYS', 'LKG-ROSE', '', 'admin', '192.168.1.6', '2017-10-24 16:43:47', '2005'),
(7, '', 'Deborah', 'Maths', '1', '1', '1', 'BOYS', 'LKG-ROSE', '', 'admin', '192.168.1.6', '2017-10-24 17:10:49', '2005'),
(8, '', 'Deborah', 'Maths', '1', '1', '1', 'BOYS', 'LKG-ROSE', '', 'admin', '192.168.1.6', '2017-10-24 17:14:56', '2005'),
(9, '', 'Deborah', 'Maths', '1', '1', '1', 'BOYS', 'LKG-ROSE', '', '', '192.168.1.6', '2017-10-24 17:40:24', ''),
(10, '', 'Deborah', 'Maths', '1', '1', '1', 'GIRLS', 'Nursery-B,Nursery-C,LKG-ROSE', '', 'admin', '192.168.1.10', '2017-10-25 16:05:39', '2017'),
(11, '', 'Florance', 'Maths', '1', '1', '1', 'GIRLS', 'Nursery-B,Nursery-C,LKG-ROSE', '', 'admin', '192.168.1.10', '2017-10-25 16:05:39', '2017'),
(12, '', 'Vasudevan', 'Maths', '2', '1', '2', 'ENTIRE CLASS', 'LKG-A,UKG-A', '', 'admin', '192.168.1.10', '2017-10-25 16:05:39', '2017'),
(13, '', 'Venkatesan', 'Maths', '2', '1', '2', 'ENTIRE CLASS', 'LKG-A,UKG-A', '', 'admin', '192.168.1.10', '2017-10-25 16:05:39', '2017'),
(14, '', 'Deborah', 'Maths', '1', '1', '1', 'GIRLS', 'Nursery-B,Nursery-C,LKG-ROSE', '', 'admin', '192.168.1.10', '2017-10-25 18:05:29', '2017'),
(15, '', 'Florance', 'Maths', '1', '1', '1', 'GIRLS', 'Nursery-B,Nursery-C,LKG-ROSE', '', 'admin', '192.168.1.10', '2017-10-25 18:05:29', '2017'),
(16, '', 'Vasudevan', 'Maths', '2', '1', '2', 'ENTIRE CLASS', 'LKG-A,UKG-A', '', 'admin', '192.168.1.10', '2017-10-25 18:05:29', '2017'),
(17, '', 'Venkatesan', 'Maths', '2', '1', '2', 'ENTIRE CLASS', 'LKG-A,UKG-A', '', 'admin', '192.168.1.10', '2017-10-25 18:05:29', '2017');

-- --------------------------------------------------------

--
-- Table structure for table `master_timestructure`
--

CREATE TABLE `master_timestructure` (
  `auto_number` int(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `totaldays` int(255) NOT NULL,
  `totalsessions` int(255) NOT NULL,
  `zeroperiod` varchar(255) NOT NULL,
  `sessionname` varchar(255) NOT NULL,
  `starttimehour` varchar(255) NOT NULL,
  `starttimemin` varchar(255) NOT NULL,
  `endtimehour` varchar(255) NOT NULL,
  `endtimemin` varchar(255) NOT NULL,
  `breakstarttimehour` varchar(255) NOT NULL,
  `breakstarttimemin` varchar(255) NOT NULL,
  `breakendtimehour` varchar(255) NOT NULL,
  `breakendtimemin` varchar(255) NOT NULL,
  `recordstatus` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_timestructure`
--

INSERT INTO `master_timestructure` (`auto_number`, `academicyear`, `class`, `totaldays`, `totalsessions`, `zeroperiod`, `sessionname`, `starttimehour`, `starttimemin`, `endtimehour`, `endtimemin`, `breakstarttimehour`, `breakstarttimemin`, `breakendtimehour`, `breakendtimemin`, `recordstatus`, `ipaddress`, `username`, `updatedate`) VALUES
(1, '2014', '', 5, 10, 'yes', 'session0', '09', '00', '09', '30', '00', '00', '00', '00', '', '127.0.0.1', 'admin', '2014-09-28 10:44:29'),
(2, '2014', '', 5, 10, 'yes', 'session1', '00', '00', '00', '00', '00', '00', '00', '00', '', '127.0.0.1', 'admin', '2014-09-28 10:44:29'),
(3, '2014', '', 5, 10, 'yes', 'session2', '00', '00', '00', '00', '10', '00', '00', '00', '', '127.0.0.1', 'admin', '2014-09-28 10:44:29'),
(4, '2014', '', 5, 10, 'yes', 'session3', '00', '00', '00', '00', '00', '00', '00', '00', '', '127.0.0.1', 'admin', '2014-09-28 10:44:29'),
(5, '2014', '', 5, 10, 'yes', 'session4', '00', '00', '00', '00', '00', '00', '00', '00', '', '127.0.0.1', 'admin', '2014-09-28 10:44:29'),
(6, '2014', '', 5, 10, 'yes', 'session5', '00', '00', '00', '00', '12', '00', '00', '00', '', '127.0.0.1', 'admin', '2014-09-28 10:44:29'),
(7, '2014', '', 5, 10, 'yes', 'session6', '00', '00', '00', '00', '00', '00', '00', '00', '', '127.0.0.1', 'admin', '2014-09-28 10:44:29'),
(8, '2014', '', 5, 10, 'yes', 'session7', '00', '00', '00', '00', '00', '00', '00', '00', '', '127.0.0.1', 'admin', '2014-09-28 10:44:29'),
(9, '2014', '', 5, 10, 'yes', 'session8', '00', '00', '00', '00', '00', '00', '00', '00', '', '127.0.0.1', 'admin', '2014-09-28 10:44:29'),
(10, '2014', '', 5, 10, 'yes', 'session9', '00', '00', '00', '00', '00', '00', '00', '00', '', '127.0.0.1', 'admin', '2014-09-28 10:44:29'),
(11, '2014', '', 5, 10, 'yes', 'session10', '00', '00', '00', '00', '00', '00', '00', '00', '', '127.0.0.1', 'admin', '2014-09-28 10:44:29');

-- --------------------------------------------------------

--
-- Table structure for table `master_timestructure1`
--

CREATE TABLE `master_timestructure1` (
  `auto_number` int(255) NOT NULL,
  `sessionnumber` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `starttimehour` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `starttimeminute` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `endtimehour` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `endtimeminute` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_timestructure1`
--

INSERT INTO `master_timestructure1` (`auto_number`, `sessionnumber`, `starttimehour`, `starttimeminute`, `endtimehour`, `endtimeminute`, `updatedby`, `updatedate`, `ipaddress`) VALUES
(1, '1', '01', '00', '01', '45', 'admin', '2014-09-16 18:01:47', '115.98.112.238'),
(2, '2', '01', '45', '02', '30', 'admin', '2014-09-16 18:01:47', '115.98.112.238'),
(3, '3', '02', '30', '03', '15', 'admin', '2014-09-16 18:01:47', '115.98.112.238'),
(4, '4', '03', '30', '04', '15', 'admin', '2014-09-16 18:01:47', '115.98.112.238'),
(5, '5', '04', '15', '05', '00', 'admin', '2014-09-16 18:01:47', '115.98.112.238'),
(6, '6', '05', '00', '05', '45', 'admin', '2014-09-16 18:01:47', '115.98.112.238'),
(7, '7', '05', '45', '06', '00', 'admin', '2014-09-16 18:01:47', '115.98.112.238');

-- --------------------------------------------------------

--
-- Table structure for table `master_timetable`
--

CREATE TABLE `master_timetable` (
  `auto_number` int(255) NOT NULL,
  `classanum` int(255) NOT NULL,
  `class` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `academicyear` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `totalweekdays` int(255) NOT NULL,
  `totalsessions` int(255) NOT NULL,
  `zeroperiod` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `sessionsperday` int(255) NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_timetable1`
--

CREATE TABLE `master_timetable1` (
  `auto_number` int(255) NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchyear` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchsection` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `dayspercycle` int(255) NOT NULL,
  `sessionsperday` int(255) NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_timetable1`
--

INSERT INTO `master_timetable1` (`auto_number`, `course`, `exam`, `batchyear`, `batchsection`, `dayspercycle`, `sessionsperday`, `updatedby`, `updatedate`, `ipaddress`) VALUES
(2, 'INFORMATION TECHNOLGOY', 'SEMESTER I', '2009', 'SECTION A', 5, 7, 'admin', '2009-05-24 20:24:02', '192.168.1.15'),
(4, 'COMPUTER SCIENCE', 'SEMESTER I', '2008', 'SECTION A', 5, 7, 'admin', '2009-05-25 19:08:32', '192.168.1.15'),
(5, 'COMPUTER SCIENCE', 'SEMESTER I', '2014', 'SECTION A', 5, 7, 'admin', '2014-09-16 17:50:52', '115.98.112.238'),
(6, 'CIVIL ENGINEERING', 'SEMESTER I', '2014', 'SECTION A', 5, 7, 'admin', '2014-09-16 18:02:36', '115.98.112.238'),
(7, 'CIVIL ENGINEERING', 'SEMESTER I', '2014', 'SECTION A', 5, 7, 'admin', '2014-09-18 14:15:34', '192.168.1.14'),
(8, '', '', '2014 - 2015', '', 0, 0, 'admin', '2014-09-18 15:58:50', '192.168.1.14');

-- --------------------------------------------------------

--
-- Table structure for table `master_timetableallotment`
--

CREATE TABLE `master_timetableallotment` (
  `auto_number` int(255) NOT NULL,
  `classes` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `length` varchar(255) NOT NULL,
  `session` varchar(255) NOT NULL,
  `totalsession` varchar(255) NOT NULL,
  `classgroup` varchar(255) NOT NULL,
  `teachers` varchar(255) NOT NULL,
  `recordstatus` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL,
  `academicyear` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_timetableallotment`
--

INSERT INTO `master_timetableallotment` (`auto_number`, `classes`, `subject`, `length`, `session`, `totalsession`, `classgroup`, `teachers`, `recordstatus`, `username`, `ipaddress`, `updatedatetime`, `academicyear`) VALUES
(1, 'Nursery-A', 'English', '1', '1', '1', 'ENTIRE CLASS', 'Arundhati', '', 'admin', '192.168.1.23', '2017-10-24 16:26:13', '2005'),
(2, 'Nursery-B', 'Maths', '1', '2', '2', 'ENTIRE CLASS', 'RAVI KUMAR', '', 'admin', '192.168.1.23', '2017-10-24 16:26:46', '2005'),
(3, 'LKG-ROSE', 'Maths', '1', '1', '1', 'BOYS', 'Deborah', '', 'admin', '192.168.1.6', '2017-10-24 16:35:19', '2005'),
(4, 'LKG-ROSE', 'Maths', '1', '1', '1', 'BOYS', 'Deborah', '', 'admin', '192.168.1.6', '2017-10-24 16:36:12', '2005'),
(5, 'LKG-ROSE', 'Maths', '1', '1', '1', 'BOYS', 'Deborah', '', 'admin', '192.168.1.6', '2017-10-24 16:36:29', '2005'),
(6, 'LKG-ROSE', 'Maths', '1', '1', '1', 'BOYS', 'Deborah', '', 'admin', '192.168.1.6', '2017-10-24 16:43:47', '2005'),
(7, 'LKG-ROSE', 'Maths', '1', '1', '1', 'BOYS', 'Deborah', '', 'admin', '192.168.1.6', '2017-10-24 17:10:49', '2005'),
(8, 'LKG-ROSE', 'Maths', '1', '1', '1', 'BOYS', 'Deborah', '', 'admin', '192.168.1.6', '2017-10-24 17:14:56', '2005'),
(9, 'LKG-ROSE', 'Maths', '1', '1', '1', 'BOYS', 'Deborah', '', '', '192.168.1.6', '2017-10-24 17:40:24', ''),
(10, 'Nursery-B,Nursery-C,LKG-ROSE', 'Maths', '1', '1', '1', 'GIRLS', 'Deborah,Florance', '', 'admin', '192.168.1.10', '2017-10-25 16:05:39', '2017'),
(11, 'LKG-A,UKG-A', 'Maths', '2', '1', '2', 'ENTIRE CLASS', 'Vasudevan,Venkatesan', '', 'admin', '192.168.1.10', '2017-10-25 16:05:39', '2017'),
(12, 'Nursery-B,Nursery-C,LKG-ROSE', 'Maths', '1', '1', '1', 'GIRLS', 'Deborah,Florance', '', 'admin', '192.168.1.10', '2017-10-25 18:05:29', '2017'),
(13, 'LKG-A,UKG-A', 'Maths', '2', '1', '2', 'ENTIRE CLASS', 'Vasudevan,Venkatesan', '', 'admin', '192.168.1.10', '2017-10-25 18:05:29', '2017');

-- --------------------------------------------------------

--
-- Table structure for table `master_transport`
--

CREATE TABLE `master_transport` (
  `auto_number` int(15) NOT NULL,
  `academic_autonumber` varchar(255) NOT NULL,
  `academicyear` varchar(225) NOT NULL,
  `academicfrommonth` varchar(225) NOT NULL,
  `academictomonth` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `recorddate` varchar(255) NOT NULL,
  `updatedatetime` varchar(225) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_transport`
--

INSERT INTO `master_transport` (`auto_number`, `academic_autonumber`, `academicyear`, `academicfrommonth`, `academictomonth`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, '1', '2010-11(SSC)', 'Jun-2017', 'Jun-2017', '', '2017-10-31 ', '2017-10-31 16:53:59', 'admin', '::1', 'HYD', 'LOC-1'),
(2, '3', '2017-18(SCH)', 'Jun-2017', 'Mar-2018', '', '2017-11-01 ', '2017-11-01 10:20:30', 'admin', '192.168.1.8', 'HYD', 'LOC-1'),
(3, '4', '2017-18(COL)', 'Aug-2017', 'Jun-2018', '', '2017-11-01 ', '2017-11-01 10:20:45', 'admin', '192.168.1.8', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `master_unittest`
--

CREATE TABLE `master_unittest` (
  `auto_number` int(15) NOT NULL,
  `unittest` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `recorddate` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedatetime` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `locationcode` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_unittest`
--

INSERT INTO `master_unittest` (`auto_number`, `unittest`, `exam`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(33, 'UNIT TEST I ', '', '', '', '', '', '', '', ''),
(34, 'UNIT TEST II ', '', '', '', '', '', '', '', ''),
(35, 'UNIT TEST III ', '', '', '', '', '', '', '', ''),
(36, 'UNIT TEST IV ', '', '', '', '', '', '', '', ''),
(37, 'UNIT TEST V ', '', 'deleted', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_unittestmarks`
--

CREATE TABLE `master_unittestmarks` (
  `auto_number` int(255) NOT NULL,
  `course` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchyear` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `batchsection` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `exam` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `unittest` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subjectcode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subject` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `studentname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `maximummarks` int(255) NOT NULL,
  `minimummarks` int(255) NOT NULL,
  `marksscored` int(255) NOT NULL,
  `attendance` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedby` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_unittestmarks`
--

INSERT INTO `master_unittestmarks` (`auto_number`, `course`, `batchyear`, `batchsection`, `exam`, `unittest`, `subjectcode`, `subject`, `studentid`, `studentname`, `maximummarks`, `minimummarks`, `marksscored`, `attendance`, `updatedby`, `ipaddress`, `updatedate`) VALUES
(12, 'INFORMATION TECHNOLGOY', '2009', 'SECTION A', 'SEMESTER I', 'UNIT TEST I ', 'IT1006', 'ENTERPRISE RESOURCE PLANNING', 'STD6', 'vinoth', 100, 40, 70, 'PRESENT', 'admin', '122.164.160.119', '2009-08-15 12:53:35'),
(11, 'INFORMATION TECHNOLGOY', '2009', 'SECTION A', 'SEMESTER I', 'UNIT TEST I ', 'IT1006', 'ENTERPRISE RESOURCE PLANNING', 'STD4', 'Vijay', 100, 40, 60, 'PRESENT', 'admin', '122.164.160.119', '2009-08-15 12:53:35'),
(10, 'INFORMATION TECHNOLGOY', '2009', 'SECTION A', 'SEMESTER I', 'UNIT TEST I ', 'IT1006', 'ENTERPRISE RESOURCE PLANNING', 'STD8', 'Sowmiya', 100, 40, 50, 'PRESENT', 'admin', '122.164.160.119', '2009-08-15 12:53:35'),
(9, 'INFORMATION TECHNOLGOY', '2009', 'SECTION A', 'SEMESTER I', 'UNIT TEST I ', 'IT1007', 'ELECTRONICS COMMERCE', 'STD6', 'vinoth', 100, 40, 60, 'PRESENT', 'admin', '192.168.1.15', '2009-05-24 17:31:00'),
(8, 'INFORMATION TECHNOLGOY', '2009', 'SECTION A', 'SEMESTER I', 'UNIT TEST I ', 'IT1007', 'ELECTRONICS COMMERCE', 'STD4', 'Vijay', 100, 40, 50, 'PRESENT', 'admin', '192.168.1.15', '2009-05-24 17:31:00');

-- --------------------------------------------------------

--
-- Table structure for table `master_usercreation`
--

CREATE TABLE `master_usercreation` (
  `auto_number` int(255) NOT NULL,
  `userlogin` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `userpassword` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `confirmpassword` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `employeename` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `mobileno` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `emailid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `address` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `designation_autonumber` int(255) NOT NULL,
  `permission_setting` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `emailpassword` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `mailserver` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_usercreation`
--

INSERT INTO `master_usercreation` (`auto_number`, `userlogin`, `userpassword`, `confirmpassword`, `employeename`, `mobileno`, `emailid`, `address`, `designation_autonumber`, `permission_setting`, `updatedate`, `emailpassword`, `mailserver`) VALUES
(3, 'admin', 'admin', 'admin', 'Admin', '768795', 'prem@testing.com', 'address', 20, 'Allow', '2009-05-16 20:45:53', 'solutions', 'mail.testing.com');

-- --------------------------------------------------------

--
-- Table structure for table `master_users`
--

CREATE TABLE `master_users` (
  `auto_number` int(255) NOT NULL,
  `login` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `permissiongroup` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ipaddress` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `master_users`
--

INSERT INTO `master_users` (`auto_number`, `login`, `password`, `permissiongroup`, `status`, `createdon`, `ipaddress`) VALUES
(1, 'admin', 'admin', 'administrator', 'active', '2009-04-03 22:34:25', '122.164.212.62'),
(2, 'staff', 'staff', '', '', '2009-04-03 22:44:39', ''),
(3, 'student', 'student', '', '', '2009-04-03 22:44:39', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_vehicle`
--

CREATE TABLE `master_vehicle` (
  `auto_number` int(255) NOT NULL,
  `vehiclenumber` varchar(255) NOT NULL,
  `vehicletype` varchar(255) NOT NULL,
  `registrationnumber` varchar(255) NOT NULL,
  `modelnumber` varchar(255) NOT NULL,
  `drivername` varchar(255) NOT NULL,
  `drivermobile` varchar(255) NOT NULL,
  `licencenumber` varchar(255) NOT NULL,
  `driveremail` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `driverarea` varchar(255) NOT NULL,
  `drivercity` varchar(255) NOT NULL,
  `driverstate` varchar(255) NOT NULL,
  `driverpincode` varchar(255) NOT NULL,
  `cleanername` varchar(255) NOT NULL,
  `cleanermobile` varchar(255) NOT NULL,
  `licencenumber1` varchar(255) NOT NULL,
  `cleaneremail` varchar(255) NOT NULL,
  `address3` varchar(255) NOT NULL,
  `address4` varchar(255) NOT NULL,
  `cleanerarea` varchar(255) NOT NULL,
  `cleanercity` varchar(255) NOT NULL,
  `cleanerstate` varchar(255) NOT NULL,
  `cleanerpincode` varchar(255) NOT NULL,
  `insurancenumber` varchar(255) NOT NULL,
  `insuranceagent` varchar(255) NOT NULL,
  `expirydate` date NOT NULL,
  `status` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_vehicle`
--

INSERT INTO `master_vehicle` (`auto_number`, `vehiclenumber`, `vehicletype`, `registrationnumber`, `modelnumber`, `drivername`, `drivermobile`, `licencenumber`, `driveremail`, `address1`, `address2`, `driverarea`, `drivercity`, `driverstate`, `driverpincode`, `cleanername`, `cleanermobile`, `licencenumber1`, `cleaneremail`, `address3`, `address4`, `cleanerarea`, `cleanercity`, `cleanerstate`, `cleanerpincode`, `insurancenumber`, `insuranceagent`, `expirydate`, `status`, `username`, `ipaddress`, `updatedatetime`) VALUES
(1, 'BUS 4', 'BUS', 'TN-28 8789', '5545646566', 'Arun', '9884578568', 'TN289809809', 'arun@gmail.com', 'gfg', 'gfgh', 'gfghf', 'ghfgh', 'ghfgh', 'gfjfj', 'klhjklj', 'kljkl', 'kljklj', 'opoi', 'kjklj', 'poipoi', 'jhkjh', 'ipipoi', 'jhjkh', 'jkhjkh', '', 'kjhkjh', '1970-01-01', '', 'admin', '192.168.1.14', '2014-10-29 12:46:04'),
(2, 'BUS 3', 'BUS', 'TN-28 8782', '5545646566', 'Arun', '9884578568', 'TN289809809', 'arun@gmail.com', 'gfg', 'gfgh', 'gfghf', 'ghfgh', 'ghfgh', 'gfjfj', 'klhjklj', 'kljkl', 'kljklj', 'opoi', 'kjklj', 'poipoi', 'jhkjh', 'ipipoi', 'jhjkh', 'jkhjkh', 'jhkjhkj', 'kjhkjh', '2014-10-31', '', 'admin', '192.168.1.14', '2014-10-29 12:47:26'),
(3, 'BUS 1', 'BUS', 'TN-28 8783', '5545646566', 'Karthi', '9884578568', 'TN289809809', 'arun@gmail.com', 'gfg', 'gfgh', 'gfghf', 'ghfgh', 'ghfgh', 'gfjfj', 'klhjklj', 'kljkl', 'kljklj', 'opoi', 'kjklj', 'poipoi', 'jhkjh', 'ipipoi', 'jhjkh', 'jkhjkh', 'jhkjhkj', 'kjhkjh', '2014-10-31', '', 'admin', '192.168.1.14', '2014-10-29 12:48:18'),
(4, 'BUS 2', 'BUS', 'TN-28 8780', '5545646566', 'Kumar', '9884578568', 'TN289809809', 'arun@gmail.com', 'gfg', 'gfgh', 'gfghf', 'ghfgh', 'ghfgh', 'gfjfj', 'klhjklj', 'kljkl', 'kljklj', 'opoi', 'kjklj', 'poipoi', 'jhkjh', 'ipipoi', 'jhjkh', 'jkhjkh', 'jhkjhkj', 'kjhkjh', '2014-10-31', '', 'admin', '192.168.1.14', '2014-10-29 12:48:38'),
(5, 'BUS 5', 'BUS', 'TN-28 8756', '5545646566', 'Prem', '9884578568', 'TN289809809', 'arun@gmail.com', 'gfg', 'gfgh', 'gfghf', 'ghfgh', 'ghfgh', 'gfjfj', 'klhjklj', 'kljkl', 'kljklj', 'opoi', 'kjklj', 'poipoi', 'jhkjh', 'ipipoi', 'jhjkh', 'jkhjkh', 'jhkjhkj', 'kjhkjh', '2014-10-31', '', 'admin', '192.168.1.14', '2014-10-29 12:49:00'),
(6, 'BUS 6', 'BUS', 'TN-28 8755', '5545646566', 'Prem', '9884578568', 'TN289809809', 'arun@gmail.com', 'gfg', 'gfgh', 'gfghf', 'ghfgh', 'ghfgh', 'gfjfj', 'klhjklj', 'kljkl', 'kljklj', 'opoi', 'kjklj', 'poipoi', 'jhkjh', 'ipipoi', 'jhjkh', 'jkhjkh', 'jhkjhkj', 'kjhkjh', '2014-10-31', 'deleted', 'admin', '192.168.1.14', '2014-10-29 12:49:52'),
(7, 'BUS 7', 'BUS', 'TN-28 8733', '5545646566', 'Prem', '9884578568', 'TN289809809', 'arun@gmail.com', 'gfg', 'gfgh', 'gfghf', 'ghfgh', 'ghfgh', 'gfjfj', 'klhjklj', 'kljkl', 'kljklj', 'opoi', 'kjklj', 'poipoi', 'jhkjh', 'ipipoi', 'jhjkh', 'jkhjkh', 'jhkjhkj', 'kjhkjh', '2014-10-31', 'deleted', 'admin', '192.168.1.14', '2014-10-29 12:50:45');

-- --------------------------------------------------------

--
-- Table structure for table `medium_school`
--

CREATE TABLE `medium_school` (
  `auto_number` int(15) NOT NULL,
  `medium` varchar(225) NOT NULL,
  `status` varchar(225) NOT NULL,
  `recorddate` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL,
  `username` varchar(225) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `locationname` varchar(255) NOT NULL,
  `locationcode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medium_school`
--

INSERT INTO `medium_school` (`auto_number`, `medium`, `status`, `recorddate`, `updatedatetime`, `username`, `ipaddress`, `locationname`, `locationcode`) VALUES
(1, 'TELUGU', '', '2017-10-31 ', '2017-10-31 17:09:38', 'admin', '::1', 'HYD', 'LOC-1'),
(2, 'ENGLISH', '', '2017-10-31 ', '2017-10-31 17:26:31', 'admin', '::1', 'HYD', 'LOC-1');

-- --------------------------------------------------------

--
-- Table structure for table `set_application_number`
--

CREATE TABLE `set_application_number` (
  `auto_number` int(255) NOT NULL,
  `appno_start` int(255) NOT NULL,
  `appno_end` int(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `academicyearfrom` int(255) NOT NULL,
  `academicyearto` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `set_application_number`
--

INSERT INTO `set_application_number` (`auto_number`, `appno_start`, `appno_end`, `status`, `academicyearfrom`, `academicyearto`) VALUES
(5, 100, 200, 'deleted', 2014, 2015);

-- --------------------------------------------------------

--
-- Table structure for table `timetable_sessiontime`
--

CREATE TABLE `timetable_sessiontime` (
  `auto_number` int(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `totaldays` int(255) NOT NULL,
  `totalsessions` int(255) NOT NULL,
  `zeroperiod` varchar(255) NOT NULL,
  `sessionname` varchar(255) NOT NULL,
  `starttimehour` varchar(255) NOT NULL,
  `starttimemin` varchar(255) NOT NULL,
  `endtimehour` varchar(255) NOT NULL,
  `endtimemin` varchar(255) NOT NULL,
  `breakstarttimehour` varchar(255) NOT NULL,
  `breakstarttimemin` varchar(255) NOT NULL,
  `breakendtimehour` varchar(255) NOT NULL,
  `breakendtimemin` varchar(255) NOT NULL,
  `recordstatus` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `timetable_structure`
--

CREATE TABLE `timetable_structure` (
  `auto_number` int(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `totaldays` int(255) NOT NULL,
  `totalsessions` int(255) NOT NULL,
  `zeroperiod` varchar(255) NOT NULL,
  `weekdays` varchar(255) NOT NULL,
  `session0` varchar(255) NOT NULL,
  `session1` varchar(255) NOT NULL,
  `session2` varchar(255) NOT NULL,
  `session3` varchar(255) NOT NULL,
  `session4` varchar(255) NOT NULL,
  `session5` varchar(255) NOT NULL,
  `session6` varchar(255) NOT NULL,
  `session7` varchar(255) NOT NULL,
  `session8` varchar(255) NOT NULL,
  `session9` varchar(255) NOT NULL,
  `session10` varchar(255) NOT NULL,
  `session11` varchar(255) NOT NULL,
  `session12` varchar(255) NOT NULL,
  `session13` varchar(255) NOT NULL,
  `session14` varchar(255) NOT NULL,
  `session15` varchar(255) NOT NULL,
  `session16` varchar(255) NOT NULL,
  `session17` varchar(255) NOT NULL,
  `session18` varchar(255) NOT NULL,
  `session19` varchar(255) NOT NULL,
  `session20` varchar(255) NOT NULL,
  `session21` text NOT NULL,
  `session22` text NOT NULL,
  `session23` text NOT NULL,
  `session24` text NOT NULL,
  `session25` text NOT NULL,
  `recordstatus` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `updatedate` datetime NOT NULL,
  `username` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timetable_structure`
--

INSERT INTO `timetable_structure` (`auto_number`, `academicyear`, `class`, `totaldays`, `totalsessions`, `zeroperiod`, `weekdays`, `session0`, `session1`, `session2`, `session3`, `session4`, `session5`, `session6`, `session7`, `session8`, `session9`, `session10`, `session11`, `session12`, `session13`, `session14`, `session15`, `session16`, `session17`, `session18`, `session19`, `session20`, `session21`, `session22`, `session23`, `session24`, `session25`, `recordstatus`, `ipaddress`, `updatedate`, `username`) VALUES
(1, '2014', 'NURA', 5, 11, 'yes', 'MON', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-28 10:40:16', 'admin'),
(2, '2014', 'NURA', 5, 11, 'yes', 'TUE', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-28 10:40:16', 'admin'),
(3, '2014', 'NURA', 5, 11, 'yes', 'WED', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-28 10:40:16', 'admin'),
(4, '2014', 'NURA', 5, 11, 'yes', 'THU', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-28 10:40:16', 'admin'),
(5, '2014', 'NURA', 5, 11, 'yes', 'FRI', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-28 10:40:16', 'admin'),
(6, '2014', 'NURB', 5, 11, 'yes', 'MON', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-28 10:40:40', 'admin'),
(7, '2014', 'NURB', 5, 11, 'yes', 'TUE', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-28 10:40:40', 'admin'),
(8, '2014', 'NURB', 5, 11, 'yes', 'WED', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-28 10:40:40', 'admin'),
(9, '2014', 'NURB', 5, 11, 'yes', 'THU', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-28 10:40:40', 'admin'),
(10, '2014', 'NURB', 5, 11, 'yes', 'FRI', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-28 10:40:40', 'admin'),
(11, '2014', 'substution', 5, 11, 'yes', 'MON', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-29 12:25:13', 'admin'),
(12, '2014', 'substution', 5, 11, 'yes', 'TUE', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-29 12:25:13', 'admin'),
(13, '2014', 'substution', 5, 11, 'yes', 'WED', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-29 12:25:13', 'admin'),
(14, '2014', 'substution', 5, 11, 'yes', 'THU', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-29 12:25:13', 'admin'),
(15, '2014', 'substution', 5, 11, 'yes', 'FRI', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-29 12:25:13', 'admin'),
(16, '2014', 'NURC', 5, 11, 'yes', 'MON', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:40:39', 'admin'),
(17, '2014', 'NURC', 5, 11, 'yes', 'TUE', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:40:39', 'admin'),
(18, '2014', 'NURC', 5, 11, 'yes', 'WED', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:40:39', 'admin'),
(19, '2014', 'NURC', 5, 11, 'yes', 'THU', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:40:39', 'admin'),
(20, '2014', 'NURC', 5, 11, 'yes', 'FRI', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:40:39', 'admin'),
(21, '2014', 'LKGA', 5, 11, 'yes', 'MON', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:42:04', 'admin'),
(22, '2014', 'LKGA', 5, 11, 'yes', 'TUE', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:42:04', 'admin'),
(23, '2014', 'LKGA', 5, 11, 'yes', 'WED', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:42:04', 'admin'),
(24, '2014', 'LKGA', 5, 11, 'yes', 'THU', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:42:04', 'admin'),
(25, '2014', 'LKGA', 5, 11, 'yes', 'FRI', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:42:04', 'admin'),
(26, '2014', 'LKGB', 5, 11, 'yes', 'MON', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:42:30', 'admin'),
(27, '2014', 'LKGB', 5, 11, 'yes', 'TUE', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:42:30', 'admin'),
(28, '2014', 'LKGB', 5, 11, 'yes', 'WED', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:42:30', 'admin'),
(29, '2014', 'LKGB', 5, 11, 'yes', 'THU', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:42:30', 'admin'),
(30, '2014', 'LKGB', 5, 11, 'yes', 'FRI', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-09-30 17:42:30', 'admin'),
(31, '2014', '1A', 5, 11, 'yes', 'MON', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 14:59:56', 'admin'),
(32, '2014', '1A', 5, 11, 'yes', 'TUE', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 14:59:56', 'admin'),
(33, '2014', '1A', 5, 11, 'yes', 'WED', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 14:59:56', 'admin'),
(34, '2014', '1A', 5, 11, 'yes', 'THU', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 14:59:56', 'admin'),
(35, '2014', '1A', 5, 11, 'yes', 'FRI', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '127.0.0.1', '2014-10-01 14:59:56', 'admin'),
(36, '2014', 'Nursery-A', 5, 11, 'yes', 'MON', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.14', '2014-10-31 18:44:12', 'admin'),
(37, '2014', 'Nursery-A', 5, 11, 'yes', 'TUE', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.14', '2014-10-31 18:44:12', 'admin'),
(38, '2014', 'Nursery-A', 5, 11, 'yes', 'WED', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.14', '2014-10-31 18:44:12', 'admin'),
(39, '2014', 'Nursery-A', 5, 11, 'yes', 'THU', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.14', '2014-10-31 18:44:12', 'admin'),
(40, '2014', 'Nursery-A', 5, 11, 'yes', 'FRI', 'NOT', 'ALLOW', 'ALLOW', 'ALLOW', 'ALLOW', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', 'NOT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '192.168.1.14', '2014-10-31 18:44:12', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `transportallotment`
--

CREATE TABLE `transportallotment` (
  `auto_number` int(255) NOT NULL,
  `transportnumber` varchar(255) NOT NULL,
  `admissionnumber` varchar(255) NOT NULL,
  `rollnumber` varchar(255) NOT NULL,
  `studentcode` varchar(255) NOT NULL,
  `studentname` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(255) NOT NULL,
  `doj` date NOT NULL,
  `studentmobile` varchar(255) NOT NULL,
  `studentemail` varchar(255) NOT NULL,
  `fathername` varchar(255) NOT NULL,
  `fathermobile` varchar(255) NOT NULL,
  `fatheremail` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `pointanum` int(255) NOT NULL,
  `pointname` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `updatedatetime` datetime NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transportallotment`
--

INSERT INTO `transportallotment` (`auto_number`, `transportnumber`, `admissionnumber`, `rollnumber`, `studentcode`, `studentname`, `class`, `section`, `dob`, `gender`, `doj`, `studentmobile`, `studentemail`, `fathername`, `fathermobile`, `fatheremail`, `address`, `city`, `state`, `pincode`, `country`, `academicyear`, `pointanum`, `pointname`, `ipaddress`, `username`, `updatedatetime`, `status`) VALUES
(1, 'TRN/2014-15/1000', 'ADM/2014-15/1004', '', 'STU00000005', 'Bharath  ', 'LKG', 'A', '2004-09-04', 'male', '2014-10-12', '9952722542', '', 'Krishnasamy', '', '', '', '', '', '', '', '2014-15', 14, 'T Nagar', '127.0.0.1', 'admin', '2014-10-12 11:12:54', 'Active'),
(3, 'TRN/2014-15/1001', 'ADM/2014-15/1004', '', 'STU00000005', 'Bharath  ', 'LKG', '', '2004-09-04', 'male', '2014-10-12', '9952722542', '', 'Krishnasamy', '', '', '', '', '', '', '', '2014-15', 21, 'R 1 P1', '127.0.0.1', 'admin', '2014-10-12 11:20:55', 'Active'),
(4, 'TRN/2014-15/1002', 'ADM/2014-15/1004', '', 'STU00000005', 'Bharath  ', 'LKG', '', '2004-09-04', 'male', '2014-10-12', '9952722542', '', 'Krishnasamy', '', '', '', '', '', '', '', '2014-15', 17, 'Mambalam', '127.0.0.1', 'admin', '2014-10-12 11:49:50', 'Active'),
(5, 'TRN/2014-15/1003', 'ADM/2014-15/1007', '', 'STU00000008', 'Taman  ', '7', 'A', '2001-10-10', 'male', '2014-10-13', '', '', '', '', '', '', '', '', '', '', '2014-15', 17, 'Mambalam', '127.0.0.1', 'admin', '2014-10-13 10:53:40', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activebatch`
--
ALTER TABLE `activebatch`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `class_section`
--
ALTER TABLE `class_section`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `class_subject1`
--
ALTER TABLE `class_subject1`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `details_attendance`
--
ALTER TABLE `details_attendance`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `details_attendancestaff`
--
ALTER TABLE `details_attendancestaff`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `details_classtimetable`
--
ALTER TABLE `details_classtimetable`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `details_feepayment`
--
ALTER TABLE `details_feepayment`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `details_interview`
--
ALTER TABLE `details_interview`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `details_login`
--
ALTER TABLE `details_login`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `details_teachertimetable`
--
ALTER TABLE `details_teachertimetable`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `details_timetable`
--
ALTER TABLE `details_timetable`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `details_transport`
--
ALTER TABLE `details_transport`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `examtocourse`
--
ALTER TABLE `examtocourse`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `feeheadmapping`
--
ALTER TABLE `feeheadmapping`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `feespayment`
--
ALTER TABLE `feespayment`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `feestocourse`
--
ALTER TABLE `feestocourse`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `hostelallotment`
--
ALTER TABLE `hostelallotment`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `login_restriction`
--
ALTER TABLE `login_restriction`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_academicyear`
--
ALTER TABLE `master_academicyear`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_academicyear2`
--
ALTER TABLE `master_academicyear2`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_accesspermission`
--
ALTER TABLE `master_accesspermission`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_adddocs`
--
ALTER TABLE `master_adddocs`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_admissiontype`
--
ALTER TABLE `master_admissiontype`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_applicationamount`
--
ALTER TABLE `master_applicationamount`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_application_issued`
--
ALTER TABLE `master_application_issued`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_application_received`
--
ALTER TABLE `master_application_received`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_application_received1`
--
ALTER TABLE `master_application_received1`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_attendance`
--
ALTER TABLE `master_attendance`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_attendancestaff`
--
ALTER TABLE `master_attendancestaff`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_autonumber`
--
ALTER TABLE `master_autonumber`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_batchsection`
--
ALTER TABLE `master_batchsection`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_block`
--
ALTER TABLE `master_block`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_bloodgroup`
--
ALTER TABLE `master_bloodgroup`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_book`
--
ALTER TABLE `master_book`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_bookcategory`
--
ALTER TABLE `master_bookcategory`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_bookissue`
--
ALTER TABLE `master_bookissue`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_booksubcategory`
--
ALTER TABLE `master_booksubcategory`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_caste`
--
ALTER TABLE `master_caste`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_city`
--
ALTER TABLE `master_city`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_class`
--
ALTER TABLE `master_class`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_classallotment`
--
ALTER TABLE `master_classallotment`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_classgroup`
--
ALTER TABLE `master_classgroup`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_classname`
--
ALTER TABLE `master_classname`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_community`
--
ALTER TABLE `master_community`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_country`
--
ALTER TABLE `master_country`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_course`
--
ALTER TABLE `master_course`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_daystructure`
--
ALTER TABLE `master_daystructure`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_degree`
--
ALTER TABLE `master_degree`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_department`
--
ALTER TABLE `master_department`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_designation`
--
ALTER TABLE `master_designation`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_documents`
--
ALTER TABLE `master_documents`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_edition`
--
ALTER TABLE `master_edition`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_employee`
--
ALTER TABLE `master_employee`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_employeerights`
--
ALTER TABLE `master_employeerights`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_enquiry`
--
ALTER TABLE `master_enquiry`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_exam`
--
ALTER TABLE `master_exam`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_exam1`
--
ALTER TABLE `master_exam1`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_feeassign`
--
ALTER TABLE `master_feeassign`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_feecategory`
--
ALTER TABLE `master_feecategory`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_feehead`
--
ALTER TABLE `master_feehead`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_feepayment`
--
ALTER TABLE `master_feepayment`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_fees`
--
ALTER TABLE `master_fees`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_feesubhead`
--
ALTER TABLE `master_feesubhead`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_hostelbed`
--
ALTER TABLE `master_hostelbed`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_hostelroom`
--
ALTER TABLE `master_hostelroom`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_hyperlink`
--
ALTER TABLE `master_hyperlink`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_internalmarks`
--
ALTER TABLE `master_internalmarks`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_interviewquestions`
--
ALTER TABLE `master_interviewquestions`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_labcategory`
--
ALTER TABLE `master_labcategory`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_labitem`
--
ALTER TABLE `master_labitem`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_labitemissue`
--
ALTER TABLE `master_labitemissue`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_lendingperiod`
--
ALTER TABLE `master_lendingperiod`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_menumain`
--
ALTER TABLE `master_menumain`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_menusub`
--
ALTER TABLE `master_menusub`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_modelexam`
--
ALTER TABLE `master_modelexam`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_modelexammarks`
--
ALTER TABLE `master_modelexammarks`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_module`
--
ALTER TABLE `master_module`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_nextteacher`
--
ALTER TABLE `master_nextteacher`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_otherinfo`
--
ALTER TABLE `master_otherinfo`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_parent`
--
ALTER TABLE `master_parent`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_point`
--
ALTER TABLE `master_point`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_programme`
--
ALTER TABLE `master_programme`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_qualification`
--
ALTER TABLE `master_qualification`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_religion`
--
ALTER TABLE `master_religion`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_route`
--
ALTER TABLE `master_route`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_school`
--
ALTER TABLE `master_school`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_section`
--
ALTER TABLE `master_section`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_semestermarks`
--
ALTER TABLE `master_semestermarks`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_specialization`
--
ALTER TABLE `master_specialization`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_staff`
--
ALTER TABLE `master_staff`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_staffcategory`
--
ALTER TABLE `master_staffcategory`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_state`
--
ALTER TABLE `master_state`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_student`
--
ALTER TABLE `master_student`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_subject`
--
ALTER TABLE `master_subject`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_subject1`
--
ALTER TABLE `master_subject1`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_substitution`
--
ALTER TABLE `master_substitution`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_teacherallotment`
--
ALTER TABLE `master_teacherallotment`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_timestructure`
--
ALTER TABLE `master_timestructure`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_timestructure1`
--
ALTER TABLE `master_timestructure1`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_timetable`
--
ALTER TABLE `master_timetable`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_timetable1`
--
ALTER TABLE `master_timetable1`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_timetableallotment`
--
ALTER TABLE `master_timetableallotment`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_transport`
--
ALTER TABLE `master_transport`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_unittest`
--
ALTER TABLE `master_unittest`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_unittestmarks`
--
ALTER TABLE `master_unittestmarks`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_usercreation`
--
ALTER TABLE `master_usercreation`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_users`
--
ALTER TABLE `master_users`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `master_vehicle`
--
ALTER TABLE `master_vehicle`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `medium_school`
--
ALTER TABLE `medium_school`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `set_application_number`
--
ALTER TABLE `set_application_number`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `timetable_sessiontime`
--
ALTER TABLE `timetable_sessiontime`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `timetable_structure`
--
ALTER TABLE `timetable_structure`
  ADD PRIMARY KEY (`auto_number`);

--
-- Indexes for table `transportallotment`
--
ALTER TABLE `transportallotment`
  ADD PRIMARY KEY (`auto_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activebatch`
--
ALTER TABLE `activebatch`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `class_section`
--
ALTER TABLE `class_section`
  MODIFY `auto_number` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `class_subject1`
--
ALTER TABLE `class_subject1`
  MODIFY `auto_number` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `details_attendance`
--
ALTER TABLE `details_attendance`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `details_attendancestaff`
--
ALTER TABLE `details_attendancestaff`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `details_classtimetable`
--
ALTER TABLE `details_classtimetable`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;
--
-- AUTO_INCREMENT for table `details_feepayment`
--
ALTER TABLE `details_feepayment`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `details_interview`
--
ALTER TABLE `details_interview`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `details_login`
--
ALTER TABLE `details_login`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=413;
--
-- AUTO_INCREMENT for table `details_teachertimetable`
--
ALTER TABLE `details_teachertimetable`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;
--
-- AUTO_INCREMENT for table `details_timetable`
--
ALTER TABLE `details_timetable`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `details_transport`
--
ALTER TABLE `details_transport`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `examtocourse`
--
ALTER TABLE `examtocourse`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `feeheadmapping`
--
ALTER TABLE `feeheadmapping`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `feespayment`
--
ALTER TABLE `feespayment`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `feestocourse`
--
ALTER TABLE `feestocourse`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `hostelallotment`
--
ALTER TABLE `hostelallotment`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `login_restriction`
--
ALTER TABLE `login_restriction`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=413;
--
-- AUTO_INCREMENT for table `master_academicyear`
--
ALTER TABLE `master_academicyear`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `master_academicyear2`
--
ALTER TABLE `master_academicyear2`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `master_accesspermission`
--
ALTER TABLE `master_accesspermission`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;
--
-- AUTO_INCREMENT for table `master_adddocs`
--
ALTER TABLE `master_adddocs`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `master_admissiontype`
--
ALTER TABLE `master_admissiontype`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `master_applicationamount`
--
ALTER TABLE `master_applicationamount`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `master_application_issued`
--
ALTER TABLE `master_application_issued`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `master_application_received`
--
ALTER TABLE `master_application_received`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `master_application_received1`
--
ALTER TABLE `master_application_received1`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `master_attendance`
--
ALTER TABLE `master_attendance`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `master_attendancestaff`
--
ALTER TABLE `master_attendancestaff`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `master_autonumber`
--
ALTER TABLE `master_autonumber`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `master_batchsection`
--
ALTER TABLE `master_batchsection`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `master_block`
--
ALTER TABLE `master_block`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `master_bloodgroup`
--
ALTER TABLE `master_bloodgroup`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `master_book`
--
ALTER TABLE `master_book`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `master_bookcategory`
--
ALTER TABLE `master_bookcategory`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `master_bookissue`
--
ALTER TABLE `master_bookissue`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `master_booksubcategory`
--
ALTER TABLE `master_booksubcategory`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `master_caste`
--
ALTER TABLE `master_caste`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `master_city`
--
ALTER TABLE `master_city`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `master_class`
--
ALTER TABLE `master_class`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `master_classallotment`
--
ALTER TABLE `master_classallotment`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `master_classgroup`
--
ALTER TABLE `master_classgroup`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `master_classname`
--
ALTER TABLE `master_classname`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `master_community`
--
ALTER TABLE `master_community`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `master_country`
--
ALTER TABLE `master_country`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=239;
--
-- AUTO_INCREMENT for table `master_course`
--
ALTER TABLE `master_course`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `master_daystructure`
--
ALTER TABLE `master_daystructure`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `master_degree`
--
ALTER TABLE `master_degree`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `master_department`
--
ALTER TABLE `master_department`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `master_designation`
--
ALTER TABLE `master_designation`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `master_documents`
--
ALTER TABLE `master_documents`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `master_edition`
--
ALTER TABLE `master_edition`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `master_employee`
--
ALTER TABLE `master_employee`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `master_employeerights`
--
ALTER TABLE `master_employeerights`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4034;
--
-- AUTO_INCREMENT for table `master_enquiry`
--
ALTER TABLE `master_enquiry`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `master_exam`
--
ALTER TABLE `master_exam`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `master_exam1`
--
ALTER TABLE `master_exam1`
  MODIFY `auto_number` int(30) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `master_feeassign`
--
ALTER TABLE `master_feeassign`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `master_feecategory`
--
ALTER TABLE `master_feecategory`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `master_feehead`
--
ALTER TABLE `master_feehead`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `master_feepayment`
--
ALTER TABLE `master_feepayment`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `master_fees`
--
ALTER TABLE `master_fees`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `master_feesubhead`
--
ALTER TABLE `master_feesubhead`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `master_hostelbed`
--
ALTER TABLE `master_hostelbed`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `master_hostelroom`
--
ALTER TABLE `master_hostelroom`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `master_hyperlink`
--
ALTER TABLE `master_hyperlink`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `master_internalmarks`
--
ALTER TABLE `master_internalmarks`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `master_interviewquestions`
--
ALTER TABLE `master_interviewquestions`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `master_labcategory`
--
ALTER TABLE `master_labcategory`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `master_labitem`
--
ALTER TABLE `master_labitem`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `master_labitemissue`
--
ALTER TABLE `master_labitemissue`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `master_lendingperiod`
--
ALTER TABLE `master_lendingperiod`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `master_menumain`
--
ALTER TABLE `master_menumain`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `master_menusub`
--
ALTER TABLE `master_menusub`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `master_modelexam`
--
ALTER TABLE `master_modelexam`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `master_modelexammarks`
--
ALTER TABLE `master_modelexammarks`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `master_module`
--
ALTER TABLE `master_module`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `master_nextteacher`
--
ALTER TABLE `master_nextteacher`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `master_otherinfo`
--
ALTER TABLE `master_otherinfo`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `master_parent`
--
ALTER TABLE `master_parent`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `master_point`
--
ALTER TABLE `master_point`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `master_programme`
--
ALTER TABLE `master_programme`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `master_qualification`
--
ALTER TABLE `master_qualification`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `master_religion`
--
ALTER TABLE `master_religion`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `master_route`
--
ALTER TABLE `master_route`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `master_school`
--
ALTER TABLE `master_school`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `master_section`
--
ALTER TABLE `master_section`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `master_semestermarks`
--
ALTER TABLE `master_semestermarks`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `master_specialization`
--
ALTER TABLE `master_specialization`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `master_staff`
--
ALTER TABLE `master_staff`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `master_staffcategory`
--
ALTER TABLE `master_staffcategory`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `master_state`
--
ALTER TABLE `master_state`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `master_student`
--
ALTER TABLE `master_student`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `master_subject`
--
ALTER TABLE `master_subject`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `master_subject1`
--
ALTER TABLE `master_subject1`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `master_substitution`
--
ALTER TABLE `master_substitution`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `master_teacherallotment`
--
ALTER TABLE `master_teacherallotment`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `master_timestructure`
--
ALTER TABLE `master_timestructure`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `master_timestructure1`
--
ALTER TABLE `master_timestructure1`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `master_timetable`
--
ALTER TABLE `master_timetable`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `master_timetable1`
--
ALTER TABLE `master_timetable1`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `master_timetableallotment`
--
ALTER TABLE `master_timetableallotment`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `master_transport`
--
ALTER TABLE `master_transport`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `master_unittest`
--
ALTER TABLE `master_unittest`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `master_unittestmarks`
--
ALTER TABLE `master_unittestmarks`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `master_usercreation`
--
ALTER TABLE `master_usercreation`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `master_users`
--
ALTER TABLE `master_users`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `master_vehicle`
--
ALTER TABLE `master_vehicle`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `medium_school`
--
ALTER TABLE `medium_school`
  MODIFY `auto_number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `set_application_number`
--
ALTER TABLE `set_application_number`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `timetable_sessiontime`
--
ALTER TABLE `timetable_sessiontime`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `timetable_structure`
--
ALTER TABLE `timetable_structure`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `transportallotment`
--
ALTER TABLE `transportallotment`
  MODIFY `auto_number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
