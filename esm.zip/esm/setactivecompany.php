<?php
session_start();
//include ("includes/loginverify.php"); //to prevent indefinite loop, loginverify is disabled.
if (!isset($_SESSION["username"])) header ("location:index.php");
include ("db/db_connect.php");

$errmsg = '';
$locationname='';
$locationcode='';

$sessionid = session_id();
$ipaddress = $_SERVER["REMOTE_ADDR"];
$updatedatetime = date('Y-m-d H:i:s');
$username = $_SESSION["username"];
$usercode = $_SESSION["usercode"];
$logintime = $_SESSION["logintime"];
$docno = $_SESSION["docno"];


	$query = "select * from master_company order by auto_number limit 0, 1";
	$exec = mysql_query($query) or die ("Error in Query".mysql_error());
	$resrowcount = mysql_num_rows($exec);
	$res = mysql_fetch_array($exec);
	$companyanum = $res['auto_number'];
	
		$query1 = "select * from master_company where auto_number = '$companyanum'";
		$exec1 = mysql_query($query1) or die ("Error in Query1".mysql_error());
		$res1 = mysql_fetch_array($exec1);
		$res1companyname = $res1["companyname"];
		$res1companycode = $res1["companycode"];
		
		$_SESSION["companyanum"] = $companyanum;
		$_SESSION["companyname"] = $res1companyname;
		$_SESSION["companycode"] = $res1companycode;
		
		$query3 = "select * from master_employeelocation where employeecode='$usercode'";
		$exec3 = mysql_query($query3) or die("Error in Query3".mysql_error());
		$res3 = mysql_fetch_array($exec3);
		$rowcount3 = mysql_num_rows($exec3);
		
		if($rowcount3=='1')
		{		 	
			$query4 = "select * from master_employeelocation where employeecode = '$usercode' ";
			$exec4 = mysql_query($query4) or die ("Error in Query4".mysql_error());
			$res4 = mysql_fetch_array($exec4);
				$locationname = $res4["locationname"];    
				$locationcode = $res4["locationcode"];
							
							$_SESSION["locationname"] = $locationname;
							$_SESSION["locationcode"] = $locationcode;

							$query2 = "select * from details_login  order by auto_number desc limit 0, 1";
							$exec2 = mysql_query($query2) or die ("Error in Query2".mysql_error());
							$res2 = mysql_fetch_array($exec2);
							$billnumber = $res2["auto_number"];
							$billdigit=strlen($billnumber);
							if ($billnumber == '')
							{
								$billnumbercode ='1';
							}
							else
							{
									
								$billnumber = $res2["auto_number"];
								$billnumbercode = intval($billnumber);
								$billnumbercode = $billnumbercode + 1;
								
								$maxanum = $billnumbercode;
								$billnumbercode = $maxanum;

							}
							
							$_SESSION["timestamp"] = time();
							$_SESSION['timeout'] = time();
							setcookie('username',$username, time() + (86400 * 1));
							setcookie('usercode',$usercode, time() + (86400 * 1));
							setcookie('logintime',$updatedatetime, time() + (86400 * 1));
							setcookie('logout','login', time() + (86400 * 1));
						
						$query3 = "insert into details_login (docno,username, logintime, lastupdate, lastupdateipaddress, lastupdateusername, sessionid,locationname,locationcode,ipaddress,status) value ('$billnumbercode','$username', '$updatedatetime','$updatedatetime', '$ipaddress', '$usercode', '$sessionid', '$locationname', '$locationcode','$ipaddress', 'Active')";
						$exec3 = mysql_query($query3) or die ("Error in Query3".mysql_error());
						
						$query4 = "delete from login_restriction where username = '$username'";
						$exec4 = mysql_query($query4) or die ("Error in Query4".mysql_error());
						
						$query5 = "insert into login_restriction (username, logintime, 
						lastupdate, lastupdateipaddress, lastupdateusername, sessionid,locationname,locationcode) 
						value ('$username', '$updatedatetime', 
						'$updatedatetime', '$ipaddress', '$usercode', '$sessionid', '$locationname', '$locationcode')";
						$exec5 = mysql_query($query5) or die ("Error in Query5".mysql_error());
						
			
						$query5 = "insert into login_locationdetails (docno,username,locationname , locationcode) value ('$docno','$usercode','$locationname','$locationcode')";
						$exec5 = mysql_query($query5) or die ("Error in Query5".mysql_error());
						
						$query1 = "select count(auto_number) as countanum from login_restriction";
						$exec1 = mysql_query($query1) or die ("Error in Query1".mysql_error());
						$res1 = mysql_fetch_array($exec1);
						$logincount = $res1["countanum"];
						
						$query2 = "select * from master_edition where status = 'ACTIVE'";
						//$query2 = "select * from master_edition where status = 'ACTIVE' AND locationname='$locationname' AND locationcode='$locationcode'";
						$exec2 = mysql_query($query2) or die ("Error in Query2".mysql_error());
						$res2 = mysql_fetch_array($exec2);
						$res2usercount = $res2["users"];
						
						if ($logincount > $res2usercount)
						{
							//echo 'inside if';
							header ("location:login1.php?st=2");
							exit;
						}							
						header("location:mainmenu1.php?st=y");
		}	
		else
		{
			if (isset($_REQUEST["frm1submit1"])) { $frm1submit1 = $_REQUEST["frm1submit1"]; } else { $frm1submit1 = ""; }
				if ($frm1submit1 == 'frm1submit1')
				{
					$locationanum=$_REQUEST["location"];
					if($locationanum!='')
					{	

						$query4 = "select * from master_employeelocation where auto_number = '$locationanum' ";
						$exec4 = mysql_query($query4) or die ("Error in Query4".mysql_error());
						$res4 = mysql_fetch_array($exec4);
						
							$locationname = $res4["locationname"];    
							$locationcode = $res4["locationcode"];
							$_SESSION["locationname"] = $locationname;
							$_SESSION["locationcode"] = $locationcode;

							$query2 = "select * from details_login  order by auto_number desc limit 0, 1";
							$exec2 = mysql_query($query2) or die ("Error in Query2".mysql_error());
							$res2 = mysql_fetch_array($exec2);
							$billnumber = $res2["auto_number"];
							$billdigit=strlen($billnumber);
							if ($billnumber == '')
							{
								$billnumbercode ='1';
							}
							else
							{
									
								$billnumber = $res2["auto_number"];
								$billnumbercode = intval($billnumber);
								$billnumbercode = $billnumbercode + 1;
								
								$maxanum = $billnumbercode;
								$billnumbercode = $maxanum;

							}

							
							$_SESSION["timestamp"] = time();
							$_SESSION['timeout'] = time();
							setcookie('username',$username, time() + (86400 * 1));
							setcookie('usercode',$usercode, time() + (86400 * 1));
							setcookie('logintime',$updatedatetime, time() + (86400 * 1));
							setcookie('logout','login', time() + (86400 * 1));
						
						$query3 = "insert into details_login (docno,username, logintime, lastupdate, lastupdateipaddress, lastupdateusername, sessionid,locationname,locationcode,ipaddress,status) value ('$billnumbercode','$username', '$updatedatetime','$updatedatetime', '$ipaddress', '$usercode', '$sessionid', '$locationname', '$locationcode','$ipaddress', 'Active')";
						$exec3 = mysql_query($query3) or die ("Error in Query3".mysql_error());
						
						$query4 = "delete from login_restriction where username = '$username'";
						$exec4 = mysql_query($query4) or die ("Error in Query4".mysql_error());
						
						$query5 = "insert into login_restriction (username, logintime, 
						lastupdate, lastupdateipaddress, lastupdateusername, sessionid,locationname,locationcode) 
						value ('$username', '$updatedatetime', 
						'$updatedatetime', '$ipaddress', '$usercode', '$sessionid', '$locationname', '$locationcode')";
						$exec5 = mysql_query($query5) or die ("Error in Query5".mysql_error());


						$query5 = "insert into login_locationdetails (docno,username,locationname , locationcode) value ('$docno','$usercode','$locationname','$locationcode')";
						$exec5 = mysql_query($query5) or die ("Error in Query5".mysql_error());
						//exit;	
					
						$query1 = "select count(auto_number) as countanum from login_restriction";
						$exec1 = mysql_query($query1) or die ("Error in Query1".mysql_error());
						$res1 = mysql_fetch_array($exec1);
						$logincount = $res1["countanum"];
						
						$query2 = "select * from master_edition where status = 'ACTIVE'";
						//$query2 = "select * from master_edition where status = 'ACTIVE' AND locationname='$locationname' AND locationcode='$locationcode'";
						$exec2 = mysql_query($query2) or die ("Error in Query2".mysql_error());
						$res2 = mysql_fetch_array($exec2);
						echo $res2usercount = $res2["users"];
						
						if ($logincount > $res2usercount)
						{
							echo 'inside if';
							//header ("location:login1.php?st=2");
							exit;
						}
						header("location:mainmenu1.php?st=y");
							
					}else{
						
						header("location:setactivecompany.php");	
					}
	
				}
		}
	
?>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Exite School Management | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="css/blue.css">


    <script language="javascript">
	function process1login1()
	{
		if(document.getElementById('location').value == "")
		{
			alert("Select Location");
			document.getElementById('location').focus();
			return false;
		}
	}
	
	function setFocus()
	{
		document.getElementById("location").focus();
	}
	
	</script>
  </head>
<body class="hold-transition login-page"  onLoad="return setFocus()">
<div class="login-box">
  <div class="login-logo">
    <b>ESM </b>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Select active location </p>
  
    <form action="setactivecompany.php" method="post" onSubmit="return process1login1()" >
		<div class="form-group has-feedback">
            <select name="location" id="location" class="form-control">
						<option value="" selected="selected">Select Location</option>
						<?php
						$query1 = "select * from master_employeelocation where username='$username' group by locationcode order by locationname";
						$exec1 = mysql_query($query1) or die ("Error in Query1".mysql_error());
						while ($res1 = mysql_fetch_array($exec1))
						{
						$res1location = $res1["locationname"];
						$res1locationanum = $res1["auto_number"];
						?>
						<option value="<?php echo $res1locationanum; ?>"><?php echo $res1location; ?></option>
						<?php
						}
						?>
            </select>
			
		</div>

      <div class="row">
        <!-- /.col -->
        <div class="col-xs-4">
			<input type="hidden" name="frm1submit1" value="frm1submit1" >
			<button type="submit" name="Submit" class="btn btn-primary btn-block btn-flat">Submit</button>
        </div>
        <!-- /.col -->
      </div>
    </form>  
 </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="js/jquery.min1.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="js/icheck.min.js"></script>
    <script>
      $(function () {
        $('input').iCheck({
          checkboxClass: 'icheckbox_square-blue',
          radioClass: 'iradio_square-blue',
          increaseArea: '20%' // optional
        });
      });
    </script>
</body>
</html>
